BUILD 04 - DAPODIK -> DATA KELAS -> DATA SISWA

Perbaikan utama:
- Rombel Saat Ini Dapodik otomatis dicocokkan ke Data Kelas.
- Jika kelas belum ada, sistem otomatis membuat kelas aktif berdasarkan rombel (contoh K 5 A -> Kelas 5 A).
- Tahun ajaran aktif dipakai untuk kelas baru; jika belum ada, dibuat 2026/2027 Gasal.
- Data Siswa tetap menjadi master; siswa menyimpan id_kelas yang berasal dari Data Kelas.
- Wali kelas tetap diatur di Data Kelas dan tidak dikarang dari file Dapodik karena file Daftar Peserta Didik tidak menyediakan kolom wali kelas.
- Import ulang tetap update siswa berdasarkan NISN/NIK/NIPD.

CARA UJI:
1. Backup database.
2. Timpa source aplikasi.
3. Import ulang file Daftar Peserta Didik Dapodik.
4. Buka Data Kelas. Rombel yang ada di Dapodik harus muncul sebagai kelas.
5. Buka Data Siswa. Kolom Kelas harus terisi sesuai Rombel.
6. Atur Wali Kelas di Data Kelas.
7. Absensi/Nilai/Buku Induk harus membaca id_siswa dan id_kelas dari master.
