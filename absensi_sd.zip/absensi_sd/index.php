<?php
session_start();

require_once __DIR__ . "/config/auth.php";
wajib_login();

require_once __DIR__ . "/config/database.php";

$page_title = "Dashboard - Absensi SDN Ciburayut 01";
$menu_aktif = "dashboard";

$user_nama = $_SESSION['nama'] ?? $_SESSION['username'] ?? 'Pengguna';
$user_role = $_SESSION['role'] ?? '';

require_once __DIR__ . "/includes/header.php";
require_once __DIR__ . "/includes/sidebar.php";
?>

<main class="main-content">
    <div class="page-head" style="margin-bottom:28px;">
        <div>
            <h1>Dashboard</h1>
            <p>Selamat datang di Sistem Administrasi SDN Ciburayut 01.</p>
        </div>
    </div>

    <div class="form-card" style="padding:28px;">
        <h2 style="margin:0 0 8px;">
            Selamat Datang, <?= htmlspecialchars($user_nama, ENT_QUOTES, 'UTF-8'); ?> 👋
        </h2>
        <p style="margin:0;color:#64748b;">
            Anda login sebagai <strong><?= htmlspecialchars($user_role, ENT_QUOTES, 'UTF-8'); ?></strong>.
        </p>
    </div>
</main>

</body>
</html>
