<?php
session_start();
require_once __DIR__ . '/config/database.php';

if (isset($_SESSION['login_user'])) {
    header('Location: index.php');
    exit;
}

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function find_col($columns, $names){ foreach($names as $n){ if(isset($columns[$n])) return $n; } return null; }

$columns = [];
$res = mysqli_query($koneksi, "SHOW COLUMNS FROM users");
if ($res) {
    while ($c = mysqli_fetch_assoc($res)) $columns[$c['Field']] = $c;
}

$user_col   = find_col($columns, ['username','user','email']);
$pass_col   = find_col($columns, ['password','pass']);
$status_col = find_col($columns, ['status','aktif','is_active']);
$role_col   = find_col($columns, ['role','level']);
$name_col   = find_col($columns, ['nama','nama_user','name']);
$guru_col   = find_col($columns, ['id_guru']);
$id_col     = find_col($columns, ['id_user','id']);

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = (string)($_POST['password'] ?? '');

    if (!$user_col || !$pass_col) {
        $error = 'Struktur tabel users belum sesuai untuk login.';
    } elseif ($username === '' || $password === '') {
        $error = 'Username dan password wajib diisi.';
    } else {
        $stmt = mysqli_prepare($koneksi, "SELECT * FROM users WHERE `$user_col` = ? LIMIT 1");
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, 's', $username);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $user = $result ? mysqli_fetch_assoc($result) : null;
            mysqli_stmt_close($stmt);

            if (!$user) {
                $error = 'Username atau password salah.';
            } else {
                $status_ok = true;
                if ($status_col) {
                    $status = strtolower(trim((string)($user[$status_col] ?? '')));
                    $status_ok = in_array($status, ['', 'aktif', 'active', '1', 'ya'], true);
                }

                if (!$status_ok) {
                    $error = 'Akun sedang tidak aktif.';
                } else {
                    $password_db = (string)($user[$pass_col] ?? '');

                    // Mendukung password lama yang masih plain-text sekaligus password hash.
                    $password_ok = password_verify($password, $password_db);
                    if (!$password_ok && hash_equals($password_db, $password)) {
                        $password_ok = true;
                        // Migrasikan password lama ke hash secara otomatis.
                        $new_hash = password_hash($password, PASSWORD_DEFAULT);
                        $up = mysqli_prepare($koneksi, "UPDATE users SET `$pass_col` = ? WHERE `$id_col` = ? LIMIT 1");
                        if ($up) {
                            $uid = $user[$id_col] ?? null;
                            mysqli_stmt_bind_param($up, 'ss', $new_hash, $uid);
                            mysqli_stmt_execute($up);
                            mysqli_stmt_close($up);
                        }
                    }

                    if (!$password_ok) {
                        $error = 'Username atau password salah.';
                    } else {
                    session_regenerate_id(true);
                    $_SESSION['login_user'] = true;
                    $_SESSION['user_id'] = $id_col ? ($user[$id_col] ?? null) : null;
                    $_SESSION['username'] = $user[$user_col] ?? $username;
                    $_SESSION['nama_user'] = $name_col ? ($user[$name_col] ?? $username) : $username;
                    $role_value = $role_col ? strtolower(trim((string)($user[$role_col] ?? ''))) : '';
                    if (in_array($role_value, ['admin', 'administrator'], true)) {
                        $_SESSION['role'] = 'Admin';
                    } elseif ($role_value === 'operator') {
                        $_SESSION['role'] = 'Operator';
                    } elseif ($role_value === 'guru') {
                        $_SESSION['role'] = 'Guru';
                    } else {
                        // FIX: role tidak dikenali TIDAK BOLEH otomatis jadi Admin.
                        // Sebelumnya baris ini mengembalikan 'Admin' sehingga akun
                        // dengan nilai role kosong/typo di database mendapat akses
                        // penuh sebagai Administrator (celah keamanan).
                        $_SESSION['role'] = 'Guru';
                    }
                    $_SESSION['id_guru'] = $guru_col ? ($user[$guru_col] ?? null) : null;

                    header('Location: index.php');
                    exit;
                    }
                }
            }
        } else {
            $error = 'Login gagal: '.mysqli_error($koneksi);
        }
    }
}

$nama_sekolah = 'SDN CIBURAYUT 01';
$logo = '';
$rp = mysqli_query($koneksi, "SELECT * FROM sekolah LIMIT 1");
if ($rp && ($s = mysqli_fetch_assoc($rp))) {
    $nama_sekolah = $s['nama_sekolah'] ?? $nama_sekolah;
    foreach (['logo','logo_sekolah','path_logo'] as $lc) {
        if (isset($s[$lc]) && trim((string)$s[$lc]) !== '') { $logo = trim((string)$s[$lc]); break; }
    }
}
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login — <?=h($nama_sekolah)?></title>
<style>
*{box-sizing:border-box}
html,body{margin:0;min-height:100%;font-family:Inter,Segoe UI,Arial,sans-serif}
body{
 min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;color:#e9fbff;
 background:#020711 url('assets/images/login-cyber-blueprint.jpg') center center/cover fixed no-repeat;
 position:relative;overflow:hidden;
}
body:before{content:"";position:fixed;inset:0;background:linear-gradient(135deg,rgba(0,5,12,.78),rgba(0,16,30,.56) 48%,rgba(0,5,12,.76));z-index:0;pointer-events:none}
body:after{content:"";position:fixed;inset:0;background:radial-gradient(circle at 50% 50%,rgba(0,224,255,.10),transparent 42%);z-index:0;pointer-events:none}
.login-shell{
 position:relative;z-index:1;width:min(960px,100%);display:grid;grid-template-columns:1.05fr .95fr;
 border:1px solid rgba(105,239,255,.42);border-radius:28px;overflow:hidden;
 background:rgba(2,12,24,.34);box-shadow:0 28px 90px rgba(0,0,0,.55),0 0 45px rgba(0,212,255,.10);
 backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px)
}
.brand{
 padding:52px 46px;background:linear-gradient(155deg,rgba(2,18,34,.88),rgba(3,43,66,.70));color:#fff;
 display:flex;flex-direction:column;justify-content:center;border-right:1px solid rgba(0,234,255,.25)
}
.brand-badge{width:82px;height:82px;border-radius:22px;background:rgba(255,255,255,.92);display:flex;align-items:center;justify-content:center;overflow:hidden;margin-bottom:22px;border:1px solid rgba(0,234,255,.55);box-shadow:0 0 24px rgba(0,234,255,.20)}
.brand-badge img{width:100%;height:100%;object-fit:contain}.brand-badge span{font-size:30px}
.brand h1{margin:0 0 10px;font-size:30px;line-height:1.15;text-shadow:0 0 16px rgba(0,234,255,.18)}
.brand p{margin:0;color:rgba(224,250,255,.78);line-height:1.7}
.brand:after{content:"";display:block;width:78px;height:2px;margin-top:24px;background:linear-gradient(90deg,#00eaff,transparent);box-shadow:0 0 10px #00eaff}
.panel{
 padding:44px;background:rgba(238,250,255,.90);color:#10213f;
 border-left:1px solid rgba(255,255,255,.50);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px)
}
.panel h2{margin:0 0 8px;font-size:26px;color:#10213f}.panel .sub{margin:0 0 26px;color:#60758e}
.field{margin-bottom:17px}.field label{display:block;margin-bottom:7px;font-size:13px;font-weight:700;color:#29405d}
.field input{width:100%;padding:13px 14px;border:1px solid #c9dbe7;border-radius:12px;outline:none;font-size:15px;background:rgba(255,255,255,.82);color:#132944}
.field input:focus{border-color:#00aeda;box-shadow:0 0 0 4px rgba(0,198,235,.11),0 0 15px rgba(0,198,235,.08)}
.btn{width:100%;border:0;padding:13px 16px;border-radius:12px;background:linear-gradient(135deg,#00d9ff,#087be8);color:#00131c;font-size:15px;font-weight:800;cursor:pointer;box-shadow:0 8px 24px rgba(0,150,230,.24);transition:.2s ease}
.btn:hover{transform:translateY(-1px);box-shadow:0 12px 30px rgba(0,150,230,.32)}
.error{background:#fff1f1;border:1px solid #efb6b6;color:#a32c2c;padding:11px 13px;border-radius:11px;margin-bottom:18px;font-size:13px}
.hint{margin-top:18px;text-align:center;color:#6c8299;font-size:12px}
@media(max-width:760px){body{padding:16px}.login-shell{grid-template-columns:1fr}.brand{padding:30px;border-right:0;border-bottom:1px solid rgba(0,234,255,.25)}.brand h1{font-size:25px}.panel{padding:30px}}
@media(max-width:520px){.brand{padding:26px}.brand-badge{width:68px;height:68px}.panel{padding:26px 20px}.login-shell{border-radius:22px}}
</style>
</head>
<body>
<div class="login-shell">
    <section class="brand">
        <div class="brand-badge">
            <?php if($logo): ?>
                <img src="<?=h($logo)?>" alt="Logo Sekolah">
            <?php else: ?>
                <span>🏫</span>
            <?php endif; ?>
        </div>
        <h1><?=h($nama_sekolah)?></h1>
        <p>Sistem Administrasi & Absensi Sekolah</p>
    </section>
    <section class="panel">
        <h2>🔐 Login Aplikasi</h2>
        <p class="sub">Masuk menggunakan akun pengguna yang sudah dibuat.</p>
        <?php if($error): ?><div class="error"><?=h($error)?></div><?php endif; ?>
        <form method="post" autocomplete="on">
            <div class="field"><label>Username</label><input type="text" name="username" required autofocus autocomplete="username" value="<?=h($_POST['username'] ?? '')?>"></div>
            <div class="field"><label>Password</label><input type="password" name="password" required autocomplete="current-password"></div>
            <button class="btn" type="submit">Masuk ke Aplikasi</button>
        </form>
        <div class="hint"><?=h($nama_sekolah)?> • Sistem Administrasi Sekolah</div>
    </section>
</div>
</body>
</html>
