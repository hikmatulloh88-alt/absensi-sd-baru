# ATURAN INTEGRASI MASTER DATA SISWA

Aplikasi menggunakan **Data Siswa (`siswa`) sebagai master/rujukan utama** untuk seluruh menu yang berhubungan dengan siswa.

## Aturan wajib
1. Nama, NIS, NISN, NIK, status, foto, dan kelas siswa hanya dikelola dari **Data Siswa**.
2. Menu Absensi Siswa membaca siswa dari tabel `siswa` dan kelas dari `siswa.id_kelas`.
3. Menu Nilai membaca identitas siswa dari `siswa`; `id_kelas` nilai diturunkan dari `siswa.id_kelas`.
4. Menu Buku Induk menggunakan `siswa.id_siswa` sebagai kunci utama dan mengambil kelas/wali dari `siswa -> kelas -> guru`.
5. Laporan siswa/nilai/absensi mengambil identitas siswa dari `siswa`, bukan membuat daftar siswa kedua.
6. Import Dapodik mengisi/memperbarui master `siswa`.
7. Absensi dan penilaian **tidak boleh mengubah kelas master siswa**.
8. Wali kelas hanya dikelola di Data Kelas; hubungan siswa ke wali kelas adalah `siswa -> kelas -> id_wali_kelas -> guru`.
9. Mata pelajaran hanya dikelola di Data Mata Pelajaran; nilai hanya menyimpan `id_mapel`.
10. Tahun ajaran/semester hanya dikelola di Data Tahun Ajaran; absensi dan nilai menyimpan `id_tahun_ajaran`.

## Alur data
`Data Dapodik -> Data Siswa -> (Kelas -> Wali Kelas) -> Absensi / Nilai / Buku Induk / Laporan / Cetak`

Tidak boleh ada modul siswa kedua yang menyimpan nama siswa secara terpisah.
