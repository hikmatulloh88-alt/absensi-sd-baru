<?php
// Sidebar dengan hak akses role.
// File: includes/sidebar.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$auth_file = __DIR__ . '/../config/auth.php';
if (file_exists($auth_file)) {
    require_once $auth_file;
}

$halaman_aktif = basename($_SERVER['PHP_SELF']);
$path_aktif = $_SERVER['REQUEST_URI'] ?? '';

$user_nama = $_SESSION['nama'] ?? $_SESSION['nama_user'] ?? $_SESSION['username'] ?? 'Pengguna';
$user_role = function_exists('role_user') ? role_user() : strtolower(trim((string)($_SESSION['role'] ?? '')));

// Profil sekolah untuk header sidebar
$profil = null;
if (isset($koneksi)) {
    $q_profil = mysqli_query($koneksi, "SELECT * FROM sekolah LIMIT 1");
    if ($q_profil) {
        $profil = mysqli_fetch_assoc($q_profil);
    }
}

$nama_sekolah = $profil['nama_sekolah'] ?? 'SDN CIBURAYUT 01';

function menu_diizinkan(string $menu): bool
{
    global $user_role;

    // Admin selalu mendapatkan seluruh menu.
    if ($user_role === 'admin') {
        return true;
    }

    // Untuk Guru/Operator tetap gunakan sistem izin yang sudah ada.
    if (function_exists('izin_menu')) {
        return izin_menu($menu);
    }

    // Fallback aman bila auth belum tersedia.
    return false;
}

function menu_aktif(string $target): bool
{
    global $path_aktif;

    $target = ltrim($target, '/');
    $target_path = '/absensi_sd/' . $target;

    return strpos($path_aktif, $target_path) === 0;
}
?>

<aside class="sidebar">
    <div class="sidebar-header">
        <div class="sidebar-logo">🎓</div>
        <div>
            <h2>Absensi SD</h2>
            <p><?= htmlspecialchars($nama_sekolah); ?></p>
        </div>
    </div>

    <nav class="sidebar-menu">

        <a href="/absensi_sd/index.php"
           class="menu-item <?= menu_aktif('index.php') ? 'active' : ''; ?>">
            🏠 <span>Dashboard</span>
        </a>

        <?php if (
            menu_diizinkan('siswa') ||
            menu_diizinkan('guru') ||
            menu_diizinkan('kelas') ||
            menu_diizinkan('buku_induk') ||
            menu_diizinkan('mapel')
        ): ?>
            <div class="menu-title">MASTER DATA</div>

            <?php if (menu_diizinkan('siswa')): ?>
                <a href="/absensi_sd/modules/siswa/index.php"
                   class="menu-item <?= menu_aktif('modules/siswa/index.php/') ? 'active' : ''; ?>">
                    👨‍🎓 <span>Data Siswa</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('guru')): ?>
                <a href="/absensi_sd/modules/guru/index.php"
                   class="menu-item <?= menu_aktif('modules/guru/index.php/') ? 'active' : ''; ?>">
                    👨‍🏫 <span>Data Guru & Karyawan</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('kelas')): ?>
                <a href="/absensi_sd/modules/kelas/index.php"
                   class="menu-item <?= menu_aktif('modules/kelas/index.php/') ? 'active' : ''; ?>">
                    🏫 <span>Data Kelas</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('buku_induk')): ?>
                <a href="/absensi_sd/modules/buku_induk/index.php"
                   class="menu-item <?= menu_aktif('modules/buku_induk/index.php/') ? 'active' : ''; ?>">
                    📚 <span>Buku Induk</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('mapel')): ?>
                <a href="/absensi_sd/modules/mata_pelajaran/index.php"
                   class="menu-item <?= menu_aktif('modules/mata_pelajaran/index.php') ? 'active' : ''; ?>">
                    📖 <span>Mata Pelajaran</span>
                </a>
            <?php endif; ?>
        <?php endif; ?>


        <?php if (
            menu_diizinkan('absensi_siswa') ||
            menu_diizinkan('absensi_guru') ||
            menu_diizinkan('rekap_absensi') ||
            menu_diizinkan('kartu_absensi')
        ): ?>
            <div class="menu-title">ABSENSI</div>

            <?php if (menu_diizinkan('absensi_siswa')): ?>
                <a href="/absensi_sd/modules/absensi/index.php"
                   class="menu-item <?= menu_aktif('modules/absensi/index.php/') ? 'active' : ''; ?>">
                    🗓️ <span>Absensi Siswa</span>
                </a>
                <a href="/absensi_sd/modules/absensi/scan_qr.php"
                   class="menu-item <?= menu_aktif('modules/absensi/scan_qr.php') ? 'active' : ''; ?>" style="padding-left:34px;font-size:13px;">
                    📷 <span>Scan QR Kehadiran</span>
                </a>
                <a href="/absensi_sd/modules/absensi/riwayat.php"
                   class="menu-item <?= menu_aktif('modules/absensi/riwayat.php') ? 'active' : ''; ?>" style="padding-left:34px;font-size:13px;">
                    📋 <span>Riwayat Absensi</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('absensi_guru')): ?>
                <a href="/absensi_sd/modules/guru/absensi.php"
                   class="menu-item <?= $halaman_aktif === 'absensi.php' && strpos($path_aktif, '/modules/guru/index.php') !== false ? 'active' : ''; ?>">
                    👤 <span>Absensi Guru & Karyawan</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('rekap_absensi')): ?>
                <a href="/absensi_sd/modules/rekap/index.php"
                   class="menu-item <?= menu_aktif('modules/rekap/index.php/') ? 'active' : ''; ?>">
                    📊 <span>Rekap Absensi</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('kartu_absensi')): ?>
                <a href="/absensi_sd/modules/absensi/cetak_kartu.php"
                   class="menu-item <?= $halaman_aktif === 'cetak_kartu.php' ? 'active' : ''; ?>">
                    🪪 <span>Cetak Kartu Absensi</span>
                </a>
            <?php endif; ?>
        <?php endif; ?>


        <?php if (
            menu_diizinkan('nilai_siswa') ||
            menu_diizinkan('nilai_gasal') ||
            menu_diizinkan('nilai_genap') ||
            menu_diizinkan('upload_nilai')
        ): ?>
            <div class="menu-title">NILAI</div>

            <?php if (menu_diizinkan('nilai_siswa')): ?>
                <a href="/absensi_sd/modules/nilai/index.php"
                   class="menu-item <?= menu_aktif('modules/nilai/index.php/') && $halaman_aktif === 'index.php' ? 'active' : ''; ?>">
                    📈 <span>Nilai Siswa</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('nilai_gasal')): ?>
                <a href="/absensi_sd/modules/nilai/gasal.php"
                   class="menu-item <?= $halaman_aktif === 'gasal.php' ? 'active' : ''; ?>">
                    📝 <span>Nilai Gasal</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('nilai_genap')): ?>
                <a href="/absensi_sd/modules/nilai/genap.php"
                   class="menu-item <?= $halaman_aktif === 'genap.php' ? 'active' : ''; ?>">
                    📝 <span>Nilai Genap</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('upload_nilai')): ?>
                <a href="/absensi_sd/modules/nilai/upload.php"
                   class="menu-item <?= $halaman_aktif === 'upload.php' ? 'active' : ''; ?>">
                    📤 <span>Upload Nilai Pelajaran</span>
                </a>
            <?php endif; ?>
        <?php endif; ?>


        <?php if (
            menu_diizinkan('laporan') ||
            menu_diizinkan('buku_induk_masal')
        ): ?>
            <div class="menu-title">LAPORAN</div>

            <?php if (menu_diizinkan('laporan')): ?>
                <a href="/absensi_sd/modules/laporan/index.php"
                   class="menu-item <?= menu_aktif('modules/laporan/index.php/') && $halaman_aktif === 'index.php' ? 'active' : ''; ?>">
                    📄 <span>Laporan</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('buku_induk_masal')): ?>
                <a href="/absensi_sd/modules/buku_induk/cetak_masal.php"
                   class="menu-item <?= $halaman_aktif === 'cetak_masal.php' && strpos($path_aktif, '/modules/buku_induk/index.php') !== false ? 'active' : ''; ?>">
                    🖨️ <span>Cetak Buku Induk Masal</span>
                </a>
            <?php endif; ?>
        <?php endif; ?>


        <?php if (menu_diizinkan('pengaturan') || menu_diizinkan('pengguna')): ?>
            <div class="menu-title">PENGATURAN</div>

            <?php if (menu_diizinkan('pengaturan')): ?>
                <a href="/absensi_sd/modules/pengaturan/index.php"
                   class="menu-item <?= menu_aktif('modules/pengaturan/index.php/') ? 'active' : ''; ?>">
                    ⚙️ <span>Pengaturan</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('pengguna')): ?>
                <a href="/absensi_sd/modules/pengguna/index.php"
                   class="menu-item <?= menu_aktif('modules/pengguna/index.php') ? 'active' : ''; ?>">
                    👥 <span>Pengguna</span>
                </a>
            <?php endif; ?>
        <?php endif; ?>


        <a href="/absensi_sd/logout.php" class="menu-item logout">
            🚪 <span>Keluar</span>
        </a>

    </nav>
</aside>
