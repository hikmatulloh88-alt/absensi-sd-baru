<?php
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator');
require_once "../../config/database.php";

$menu_aktif = 'kartu_pegawai';
$page_title = 'Cetak Kartu Pegawai - SDN Ciburayut 01';

function h($v){
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

/* Cek kolom yang tersedia pada tabel guru */
$kolom_guru = [];
$q_cols = mysqli_query($koneksi, "SHOW COLUMNS FROM guru");
if ($q_cols) {
    while ($c = mysqli_fetch_assoc($q_cols)) {
        $kolom_guru[] = $c['Field'];
    }
}
$punya_foto = in_array('foto', $kolom_guru, true);
$punya_nip = in_array('nip', $kolom_guru, true);
$punya_nuptk = in_array('nuptk', $kolom_guru, true);
$punya_jabatan = in_array('jabatan', $kolom_guru, true);
$punya_jenis_ptk = in_array('jenis_ptk', $kolom_guru, true);
$kolom_nama = in_array('nama', $kolom_guru, true) ? 'nama' : (in_array('nama_guru', $kolom_guru, true) ? 'nama_guru' : null);

/* Filter */
$cari = trim($_GET['cari'] ?? '');

$where = ["status = 'Aktif'"];
if ($cari !== '' && $kolom_nama) {
    $safe = mysqli_real_escape_string($koneksi, $cari);
    $ors = ["$kolom_nama LIKE '%$safe%'"];
    if ($punya_nip) $ors[] = "nip LIKE '%$safe%'";
    if ($punya_nuptk) $ors[] = "nuptk LIKE '%$safe%'";
    $where[] = '(' . implode(' OR ', $ors) . ')';
}
$where_sql = implode(' AND ', $where);

$select = "id_guru";
if ($kolom_nama) $select .= ", $kolom_nama AS nama";
if ($punya_nip) $select .= ", nip";
if ($punya_nuptk) $select .= ", nuptk";
if ($punya_jabatan) $select .= ", jabatan";
if ($punya_jenis_ptk) $select .= ", jenis_ptk";
if ($punya_foto) $select .= ", foto";

$daftar = [];
$q_guru = mysqli_query($koneksi, "SELECT $select FROM guru WHERE $where_sql ORDER BY " . ($kolom_nama ?: 'id_guru') . " ASC");
if ($q_guru) {
    while ($r = mysqli_fetch_assoc($q_guru)) {
        $daftar[] = $r;
    }
}

/* Cari file foto dengan beberapa pola nama */
function cari_foto_guru($g) {
    $id = (int)$g['id_guru'];
    $kandidat = [];

    if (!empty($g['foto'])) {
        $foto_db = trim((string)$g['foto']);
        $kandidat[] = "../../" . ltrim($foto_db, "/\\");
        $kandidat[] = $foto_db;
    }

    $kandidat[] = "../../assets/images/guru/" . $id . ".jpg";
    $kandidat[] = "../../assets/images/guru/" . $id . ".jpeg";
    $kandidat[] = "../../assets/images/guru/" . $id . ".png";
    $kandidat[] = "../../assets/images/guru/" . $id . ".webp";

    foreach ($kandidat as $path) {
        $full = __DIR__ . DIRECTORY_SEPARATOR . str_replace("/", DIRECTORY_SEPARATOR, $path);
        $real = realpath($full);
        if ($real && is_file($real)) {
            $relative = str_replace(DIRECTORY_SEPARATOR, "/", substr($real, strlen(realpath(__DIR__ . "/../.."))));
            return "../../" . ltrim($relative, "/");
        }
    }
    return "";
}

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>

<style>
.kartu-page{max-width:1450px}
.page-head{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:24px}
.page-head h1{margin:0 0 6px}.page-head p{margin:0}
.card{background:#fff;border-radius:18px;box-shadow:0 8px 25px rgba(15,35,70,.07);padding:20px;margin-bottom:20px}
.filters{display:grid;grid-template-columns:1fr auto;gap:14px;align-items:end}
label{display:block;font-size:13px;font-weight:600;color:#334155;margin-bottom:7px}
.fc{width:100%;height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:0 11px;background:#fff;outline:none}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;border:0;border-radius:10px;padding:11px 16px;font-weight:600;text-decoration:none;cursor:pointer}
.pri{background:linear-gradient(135deg,#2388f5,#1265dc);color:#fff;box-shadow:0 8px 18px rgba(18,101,220,.18)}
.sec{background:#eef3f9;color:#334155}
.count{font-size:14px;color:#64748b;margin-bottom:12px}
.note{padding:12px 14px;background:#eef6ff;border:1px solid #d8e8fb;color:#245c9b;border-radius:10px;font-size:13px;margin-bottom:15px}
.print-area{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px}
.id-card{position:relative;width:100%;aspect-ratio:551 / 870;overflow:hidden;background:#fff url('../../assets/images/template_kartu_absensi.png') center/cover no-repeat;border-radius:14px;box-shadow:0 6px 18px rgba(15,35,70,.10);break-inside:avoid;isolation:isolate}
.photo-wrap{position:absolute;left:31%;top:24.7%;width:38%;aspect-ratio:1;border-radius:50%;background:#fff;border:5px solid rgba(255,255,255,.98);overflow:hidden;box-shadow:0 5px 16px rgba(15,35,70,.20);display:flex;align-items:center;justify-content:center}
.photo-wrap img{width:100%;height:100%;object-fit:cover;object-position:center top;display:block;background:#fff}
.photo-empty{width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:#aab4bf;font-size:38px;font-weight:700}
.student-name{position:absolute;left:7%;right:7%;top:53.2%;text-align:center;font-size:clamp(11px,1.42vw,20px);line-height:1.08;font-weight:800;color:#111827;text-transform:uppercase;letter-spacing:.1px}
.student-meta{position:absolute;left:8%;right:8%;top:57.3%;text-align:center;font-size:clamp(7px,.86vw,12px);line-height:1.35;font-weight:700;color:#374151}
.qr-box{position:absolute;width:32%;aspect-ratio:1;left:34%;bottom:7.2%;background:#fff;border-radius:10px;padding:1.6%;box-shadow:0 4px 14px rgba(15,35,70,.18)}
.qr-box img{width:100%;height:100%;display:block}
.qr-label{position:absolute;left:18%;right:18%;bottom:3.4%;text-align:center;font-size:clamp(5px,.52vw,8px);font-weight:700;color:#475569;letter-spacing:.15px}
.one-print{position:absolute;top:10px;right:10px;z-index:5;border:1px solid rgba(255,255,255,.5);background:rgba(0,0,0,.35);color:#fff;border-radius:8px;padding:6px 9px;cursor:pointer;font-size:11px}
.empty{text-align:center;color:#94a3b8;padding:55px 15px}
@media(max-width:1000px){.filters{grid-template-columns:1fr}.print-area{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:600px){.filters,.print-area{grid-template-columns:1fr}.page-head{align-items:flex-start;flex-direction:column}}
@media print{
 @page{size:A4 portrait;margin:6mm}
 html,body{background:#fff!important;margin:0!important;padding:0!important}
 .sidebar,.page-head,.filter-card,.no-print,.count,.note{display:none!important}
 .main-content{margin:0!important;padding:0!important}
 .kartu-page{max-width:none!important}
 .card{margin:0!important;padding:0!important;box-shadow:none!important;border-radius:0!important;background:transparent!important}
 .print-area{display:grid!important;grid-template-columns:repeat(3,1fr)!important;gap:4mm!important}
 .id-card{width:100%!important;aspect-ratio:551/870!important;border-radius:0!important;box-shadow:none!important;-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}
 .one-print{display:none!important}
}
</style>

<main class="main-content">
<div class="kartu-page">

<div class="page-head">
<div>
<h1>Cetak Kartu Pegawai</h1>
<p>Template portrait SDN CIBURAYUT 01 dengan foto guru/karyawan dan QR Code.</p>
</div>
<button type="button" class="btn pri no-print" onclick="window.print()">🖨️ Cetak Semua</button>
</div>

<div class="card filter-card no-print">
<form method="get">
<div class="filters">
<div>
<label>Cari Guru/Karyawan</label>
<input class="fc" type="text" name="cari" value="<?=h($cari)?>" placeholder="Nama, NIP, atau NUPTK...">
</div>
<div style="display:flex;gap:8px">
<button class="btn pri">🔎 Tampilkan</button>
<a class="btn sec" href="cetak_kartu.php">Reset</a>
</div>
</div>
</form>
</div>

<div class="note no-print">
📸 Foto akan diambil dari kolom <strong>foto</strong> pada tabel guru. Bila kolom tersebut belum ada, sistem juga mencari file foto berdasarkan ID guru di
<strong>assets/images/guru/</strong> dengan format JPG, JPEG, PNG, atau WEBP.
</div>

<div class="count no-print">
🎫 <strong><?=count($daftar)?></strong> kartu guru/karyawan tersedia
</div>

<div class="card">
<?php if($daftar): ?>

<div class="print-area">

<?php foreach($daftar as $g): ?>
<?php
$foto = cari_foto_guru($g);
$nama = $g['nama'] ?? '-';
$nip = $g['nip'] ?? '-';
$jabatan = $g['jabatan'] ?? '-';

$qr_data = 'SDN-CIBURAYUT-01|GURU:' . (int)$g['id_guru'] .
           '|NIP:' . ($nip ?: '-') .
           '|NAMA:' . $nama .
           '|JABATAN:' . ($jabatan ?: '-');

$qr_url = 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&margin=0&data=' . rawurlencode($qr_data);
?>

<div class="id-card">

<div class="one-print no-print" onclick="printOne(this)">🖨️ Cetak</div>

<div class="photo-wrap">
<?php if($foto): ?>
<img src="<?=h($foto)?>" alt="Foto <?=h($nama)?>">
<?php else: ?>
<div class="photo-empty">👤</div>
<?php endif; ?>
</div>

<div class="student-name"><?=h($nama)?></div>

<div class="student-meta">
<?=h($jabatan ?: '-')?><?= $nip && $nip!=='-' ? ' — NIP: '.h($nip) : '' ?>
</div>

<div class="qr-box">
<img src="<?=h($qr_url)?>" alt="QR Code <?=h($nama)?>">
</div>

<div class="qr-label">SCAN UNTUK IDENTITAS PEGAWAI</div>

</div>

<?php endforeach; ?>

</div>

<?php else: ?>
<div class="empty">Tidak ada guru/karyawan aktif yang sesuai dengan filter.</div>
<?php endif; ?>
</div>

</div>
</main>

<script>
function printOne(button){
    const cards=document.querySelectorAll('.id-card');
    const target=button.closest('.id-card');
    cards.forEach(function(card){
        if(card!==target) card.style.display='none';
    });
    window.print();
    cards.forEach(function(card){
        card.style.display='';
    });
}
</script>

</body>
</html>
