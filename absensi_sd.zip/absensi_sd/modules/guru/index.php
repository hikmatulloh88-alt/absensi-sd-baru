<?php
/* STEP 30: Proteksi akses Data Guru & Karyawan sesuai role */
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator', 'Guru');

require_once "../../config/database.php";

$menu_aktif = 'guru';
$page_title = 'Data Guru & Karyawan - Absensi SDN Ciburayut 01';

$pesan = '';
$tipe_pesan = '';
$mode_edit = false;

$data_edit = [
    'id_guru' => '',
    'nip' => '',
    'nuptk' => '',
    'nik' => '',
    'nama' => '',
    'jenis_kelamin' => 'L',
    'jabatan' => '',
    'jenis_ptk' => '',
    'no_hp' => '',
    'alamat' => '',
    'tanda_tangan' => '',
    'foto' => '',
    'status' => 'Aktif'
];

function h($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function clean($v) {
    $v = trim((string)$v);
    return $v === '' ? null : $v;
}

/** Simpan gambar tanda tangan dengan validasi MIME dan ukuran file. */
function simpan_foto_guru(mysqli $db, int $id_guru): array {
    if (empty($_FILES['foto_guru']) || ($_FILES['foto_guru']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return [false, 'Foto guru belum dipilih.'];
    $file = $_FILES['foto_guru'];
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'] ?? '')) return [false, 'Unggah foto guru gagal.'];
    if (($file['size'] ?? 0) <= 0 || $file['size'] > 3 * 1024 * 1024) return [false, 'Ukuran foto guru maksimal 3 MB.'];
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if (!isset($allowed[$mime])) return [false, 'Format foto guru harus JPG, PNG, atau WEBP.'];
    $dir = __DIR__ . '/../../assets/images/guru';
    if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) return [false, 'Folder penyimpanan foto guru tidak dapat dibuat.'];
    $name = 'guru_' . $id_guru . '_' . bin2hex(random_bytes(8)) . '.' . $allowed[$mime];
    $target = $dir . '/' . $name;
    if (!move_uploaded_file($file['tmp_name'], $target)) return [false, 'Foto guru gagal disimpan di server.'];
    $relative = 'assets/images/guru/' . $name;
    $old = '';
    $q = mysqli_query($db, "SELECT foto FROM guru WHERE id_guru=" . (int)$id_guru . " LIMIT 1");
    if ($q && ($r = mysqli_fetch_assoc($q))) $old = (string)($r['foto'] ?? '');
    $stmt = mysqli_prepare($db, 'UPDATE guru SET foto = ? WHERE id_guru = ?');
    if (!$stmt) return [false, 'Foto tersimpan, tetapi database gagal diperbarui.'];
    mysqli_stmt_bind_param($stmt, 'si', $relative, $id_guru);
    $ok = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    if (!$ok) return [false, 'Foto tersimpan, tetapi database gagal diperbarui.'];
    if ($old !== '' && strpos($old, 'assets/images/guru/') === 0) {
        $oldFile = __DIR__ . '/../../' . $old;
        if (is_file($oldFile) && realpath($oldFile) !== realpath($target)) @unlink($oldFile);
    }
    return [true, 'Foto guru berhasil diperbarui.'];
}

function simpan_tanda_tangan_guru(mysqli $db, int $id_guru): array {
    if (empty($_FILES['tanda_tangan']) || ($_FILES['tanda_tangan']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return [true, ''];
    $file = $_FILES['tanda_tangan'];
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'] ?? '')) return [false, 'unggah tanda tangan gagal.'];
    if (($file['size'] ?? 0) <= 0 || $file['size'] > 2 * 1024 * 1024) return [false, 'ukuran tanda tangan maksimal 2 MB.'];

    $allowed = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp'];
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if (!isset($allowed[$mime])) return [false, 'format tanda tangan harus PNG, JPG, atau WEBP.'];

    $dir = __DIR__ . '/../../assets/images/ttd_guru';
    if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) return [false, 'folder penyimpanan tanda tangan tidak dapat dibuat.'];
    $name = 'ttd_guru_' . $id_guru . '_' . bin2hex(random_bytes(8)) . '.' . $allowed[$mime];
    if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $name)) return [false, 'tanda tangan gagal disimpan di server.'];

    $relative = 'assets/images/ttd_guru/' . $name;
    $stmt = mysqli_prepare($db, 'UPDATE guru SET tanda_tangan = ? WHERE id_guru = ?');
    if (!$stmt) return [false, 'tanda tangan tersimpan, tetapi database gagal diperbarui.'];
    mysqli_stmt_bind_param($stmt, 'si', $relative, $id_guru);
    $ok = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    return $ok ? [true, ''] : [false, 'tanda tangan tersimpan, tetapi database gagal diperbarui.'];
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'upload_foto_guru') {
    if (!in_array(strtolower((string)($_SESSION['role'] ?? '')), ['admin','operator'], true)) {
        $pesan = 'Upload foto guru hanya dapat dilakukan oleh Admin/Operator.';
        $tipe_pesan = 'error';
    } else {
        $id_foto = (int)($_POST['id_guru'] ?? 0);
        if ($id_foto <= 0) {
            $pesan = 'Guru tidak ditemukan.';
            $tipe_pesan = 'error';
        } else {
            [$ok_foto, $msg_foto] = simpan_foto_guru($koneksi, $id_foto);
            $pesan = $msg_foto;
            $tipe_pesan = $ok_foto ? 'success' : 'error';
        }
    }
}

/* ==========================================================
   IMPORT DATA GURU DAPODIK (.XLSX)
   Format yang diterima mengikuti file Daftar Guru Dapodik:
   Nama, NUPTK, JK, Tempat Lahir, Tanggal Lahir, NIP,
   Status Kepegawaian, Jenis PTK, ... sampai NUKS.
   Sistem memetakan kolom penting ke MASTER DATA GURU dan
   melakukan UPDATE jika NIP/NUPTK/NIK sudah ada.
   ========================================================== */
function guru_baca_xlsx($file){
    if (!class_exists('ZipArchive')) return ['ok'=>false,'error'=>'ZipArchive PHP belum aktif.'];
    $zip = new ZipArchive();
    if ($zip->open($file) !== true) return ['ok'=>false,'error'=>'File Excel tidak dapat dibuka. Pastikan file .xlsx valid.'];

    $shared=[];
    $shared_xml=$zip->getFromName('xl/sharedStrings.xml');
    if($shared_xml!==false){
        $ss=@simplexml_load_string($shared_xml);
        if($ss){
            foreach($ss->si as $si){
                $txt='';
                if(isset($si->t)) $txt=(string)$si->t;
                else foreach($si->r as $run) $txt.=(string)$run->t;
                $shared[]=$txt;
            }
        }
    }
    $sheet=$zip->getFromName('xl/worksheets/sheet1.xml');
    if($sheet===false){$zip->close();return ['ok'=>false,'error'=>'Sheet pertama Excel tidak ditemukan.'];}
    $sx=@simplexml_load_string($sheet);
    if(!$sx){$zip->close();return ['ok'=>false,'error'=>'Isi Excel tidak dapat dibaca.'];}
    $rows=[];
    foreach($sx->sheetData->row as $rowNode){
        $row=[];
        foreach($rowNode->c as $cell){
            $ref=(string)$cell['r']; $type=(string)$cell['t']; $val='';
            if($type==='s' && isset($cell->v)){$si=(int)$cell->v;$val=$shared[$si]??'';}
            elseif($type==='inlineStr'){
                if(isset($cell->is->t)) $val=(string)$cell->is->t;
                else foreach($cell->is->r as $run) $val.=(string)$run->t;
            } elseif(isset($cell->v)) $val=(string)$cell->v;
            preg_match('/^[A-Z]+/',$ref,$m); $letters=$m[0]??''; $idx=0;
            for($i=0;$i<strlen($letters);$i++) $idx=$idx*26+(ord($letters[$i])-64);
            if($idx>0)$row[$idx]=$val;
        }
        if($row){ksort($row);$max=max(array_keys($row));$dense=[];for($i=1;$i<=$max;$i++)$dense[]=$row[$i]??'';$rows[]=$dense;}
    }
    $zip->close(); return ['ok'=>true,'rows'=>$rows];
}
function guru_norm_header($v){
    $v=mb_strtolower(trim((string)$v),'UTF-8');
    $v=str_replace(["\r","\n","\t"],' ',$v);
    return preg_replace('/\s+/u',' ',$v);
}
function guru_nilai($row,$pos,$labels){
    foreach((array)$labels as $label){
        $k=guru_norm_header($label);
        if(isset($pos[$k][0])){
            $v=trim((string)($row[$pos[$k][0]]??''));
            if($v!=='') return $v;
        }
    }
    return '';
}
function guru_clean($v){$v=trim((string)$v);return $v===''?null:$v;}
function guru_template_headers(){
    return ['No','Nama','NUPTK','JK','Tempat Lahir','Tanggal Lahir','NIP','Status Kepegawaian','Jenis PTK','Agama','Alamat Jalan','RT','RW','Nama Dusun','Desa/Kelurahan','Kecamatan','Kode Pos','Telepon','HP','Email','Tugas Tambahan','SK CPNS','Tanggal CPNS','SK Pengangkatan','TMT Pengangkatan','Lembaga Pengangkatan','Pangkat Golongan','Sumber Gaji','Nama Ibu Kandung','Status Perkawinan','Nama Suami/Istri','NIP Suami/Istri','Pekerjaan Suami/Istri','TMT PNS','Sudah Lisensi Kepala Sekolah','Pernah Diklat Kepengawasan','Keahlian Braille','Keahlian Bahasa Isyarat','NPWP','Nama Wajib Pajak','Kewarganegaraan','Bank','Nomor Rekening Bank','Rekening Atas Nama','NIK','No KK','Karpeg','Karis/Karsu','Lintang','Bujur','NUKS'];
}
function guru_buat_xlsx_sederhana($headers,$filename){
    if(!class_exists('ZipArchive')){http_response_code(500);die('ZipArchive PHP belum aktif.');}
    $tmp=tempnam(sys_get_temp_dir(),'guru_xlsx_');$zip=new ZipArchive();
    if($zip->open($tmp,ZipArchive::CREATE|ZipArchive::OVERWRITE)!==true)die('Gagal membuat template Excel.');
    $ct='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>';
    $rels='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>';
    $wrels='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>';
    $wb='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Daftar guru" sheetId="1" r:id="rId1"/></sheets></workbook>';
    $xml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1">';
    $col=1; foreach($headers as $h){$n='';$i=$col;while($i>0){$r=($i-1)%26;$n=chr(65+$r).$n;$i=intdiv($i-1,26);} $xml.='<c r="'.$n.'1" t="inlineStr"><is><t xml:space="preserve">'.htmlspecialchars($h,ENT_XML1,'UTF-8').'</t></is></c>';$col++;}
    $xml.='</row></sheetData></worksheet>';
    $zip->addFromString('[Content_Types].xml',$ct);$zip->addFromString('_rels/.rels',$rels);$zip->addFromString('xl/workbook.xml',$wb);$zip->addFromString('xl/_rels/workbook.xml.rels',$wrels);$zip->addFromString('xl/worksheets/sheet1.xml',$xml);$zip->close();
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');header('Content-Disposition: attachment; filename="'.$filename.'"');header('Content-Length: '.filesize($tmp));readfile($tmp);unlink($tmp);exit;
}

$pesan_import=''; $tipe_pesan_import='';
if(isset($_GET['unduh_template_guru'])) guru_buat_xlsx_sederhana(guru_template_headers(),'template_import_guru_dapodik.xlsx');

if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['aksi']??'')==='import_excel_guru'){
    if(!in_array(strtolower((string)($_SESSION['role']??'')),['admin','operator'],true)){
        $pesan_import='Import data guru hanya dapat dilakukan oleh Admin/Operator.';$tipe_pesan_import='error';
    } elseif(empty($_FILES['file_excel_guru']) || ($_FILES['file_excel_guru']['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK){
        $pesan_import='File Excel gagal diunggah. Coba lagi.';$tipe_pesan_import='error';
    } elseif(($_FILES['file_excel_guru']['size']??0)>10*1024*1024){
        $pesan_import='Ukuran file maksimal 10 MB.';$tipe_pesan_import='error';
    } else {
        $ext=strtolower(pathinfo($_FILES['file_excel_guru']['name'],PATHINFO_EXTENSION));
        if($ext!=='xlsx'){$pesan_import='Format harus .xlsx (Daftar Guru Dapodik).';$tipe_pesan_import='error';}
        else {
            $baca=guru_baca_xlsx($_FILES['file_excel_guru']['tmp_name']);
            if(!$baca['ok']){$pesan_import=$baca['error'];$tipe_pesan_import='error';}
            else {
                $rows=$baca['rows'];$headerIndex=-1;
                foreach($rows as $ri=>$row){$joined=mb_strtolower(implode(' | ',array_map('strval',$row)),'UTF-8');if(str_contains($joined,'nama')&&str_contains($joined,'nuptk')&&str_contains($joined,'jenis ptk')&&str_contains($joined,'nip')){$headerIndex=$ri;break;}}
                if($headerIndex<0){$pesan_import='Format tidak dikenali. Gunakan file Daftar Guru Dapodik seperti format yang Anda upload.';$tipe_pesan_import='error';}
                else {
                    $hdr=$rows[$headerIndex];$pos=[];foreach($hdr as $i=>$h){$k=guru_norm_header($h);if($k!=='')$pos[$k][]=$i;}
                    $sukses=0;$insert=0;$update=0;$gagal=0;$detail=[];
                    for($ri=$headerIndex+1;$ri<count($rows);$ri++){
                        $r=$rows[$ri];
                        $nama=guru_nilai($r,$pos,['Nama']);
                        if($nama==='') continue;
                        $nip=guru_clean(guru_nilai($r,$pos,['NIP']));$nuptk=guru_clean(guru_nilai($r,$pos,['NUPTK']));$nik=guru_clean(guru_nilai($r,$pos,['NIK']));
                        $jk=strtoupper(guru_nilai($r,$pos,['JK','Jenis Kelamin']));$jk=in_array($jk,['L','P'],true)?$jk:'L';
                        $jenis_ptk=guru_clean(guru_nilai($r,$pos,['Jenis PTK']));
                        $tugas=guru_nilai($r,$pos,['Tugas Tambahan']);
                        $jabatan=guru_clean($tugas!==''?$tugas:($jenis_ptk??''));
                        $hp=guru_clean(guru_nilai($r,$pos,['HP','Telepon']));
                        $alamat=guru_clean(guru_nilai($r,$pos,['Alamat Jalan','Alamat']));
                        $id=0;
                        // Cari berdasarkan NIP, lalu NUPTK, lalu NIK.
                        foreach([['nip',$nip],['nuptk',$nuptk],['nik',$nik]] as [$field,$val]){
                            if($val===null) continue;
                            $st=mysqli_prepare($koneksi,"SELECT id_guru FROM guru WHERE $field=? LIMIT 1");
                            if($st){mysqli_stmt_bind_param($st,'s',$val);mysqli_stmt_execute($st);$res=mysqli_stmt_get_result($st);if($res&&($rr=mysqli_fetch_assoc($res)))$id=(int)$rr['id_guru'];mysqli_stmt_close($st);}
                            if($id>0) break;
                        }
                        try{
                            if($id>0){
                                $st=mysqli_prepare($koneksi,"UPDATE guru SET nip=?,nuptk=?,nik=?,nama=?,jenis_kelamin=?,jabatan=?,jenis_ptk=?,no_hp=?,alamat=? WHERE id_guru=?");
                                if(!$st) throw new Exception('prepare update');
                                mysqli_stmt_bind_param($st,'sssssssssi',$nip,$nuptk,$nik,$nama,$jk,$jabatan,$jenis_ptk,$hp,$alamat,$id);
                                if(!mysqli_stmt_execute($st)) throw new Exception(mysqli_stmt_error($st));
                                mysqli_stmt_close($st);$update++;
                            } else {
                                $st=mysqli_prepare($koneksi,"INSERT INTO guru(nip,nuptk,nik,nama,jenis_kelamin,jabatan,jenis_ptk,no_hp,alamat,status) VALUES(?,?,?,?,?,?,?,?,?,'Aktif')");
                                if(!$st) throw new Exception('prepare insert');
                                mysqli_stmt_bind_param($st,'sssssssss',$nip,$nuptk,$nik,$nama,$jk,$jabatan,$jenis_ptk,$hp,$alamat);
                                if(!mysqli_stmt_execute($st)) throw new Exception(mysqli_stmt_error($st));
                                mysqli_stmt_close($st);$insert++;
                            }
                            $sukses++;
                        }catch(Throwable $e){$gagal++;if(count($detail)<8)$detail[]=$nama.' — '.$e->getMessage();}
                    }
                    $pesan_import="Import selesai: <strong>$sukses</strong> baris diproses, <strong>$insert</strong> data baru, <strong>$update</strong> data diperbarui, <strong>$gagal</strong> gagal.";
                    if($detail){$pesan_import.='<br><small>'.h(implode(' | ',$detail)).'</small>';}
                    $tipe_pesan_import=$gagal>0?'error':'success';
                }
            }
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? '';

    if ($aksi === 'simpan') {
        $id_guru = (int)($_POST['id_guru'] ?? 0);
        $nip = clean($_POST['nip'] ?? '');
        $nuptk = clean($_POST['nuptk'] ?? '');
        $nik = clean($_POST['nik'] ?? '');
        $nama = trim($_POST['nama'] ?? '');
        $jenis_kelamin = $_POST['jenis_kelamin'] ?? 'L';
        $jabatan = clean($_POST['jabatan'] ?? '');
        $jenis_ptk = clean($_POST['jenis_ptk'] ?? '');
        $no_hp = clean($_POST['no_hp'] ?? '');
        $alamat = clean($_POST['alamat'] ?? '');
        $status = $_POST['status'] ?? 'Aktif';

        if ($nama === '') {
            $pesan = 'Nama guru/karyawan wajib diisi.';
            $tipe_pesan = 'error';
        } elseif (!in_array($jenis_kelamin, ['L', 'P'], true)) {
            $pesan = 'Jenis kelamin tidak valid.';
            $tipe_pesan = 'error';
        } elseif (!in_array($status, ['Aktif', 'Tidak Aktif'], true)) {
            $pesan = 'Status tidak valid.';
            $tipe_pesan = 'error';
        } else {
            try {
                if ($id_guru > 0) {
                    $sql = "UPDATE guru SET
                                nip = ?, nuptk = ?, nik = ?, nama = ?, jenis_kelamin = ?,
                                jabatan = ?, jenis_ptk = ?, no_hp = ?, alamat = ?, status = ?
                            WHERE id_guru = ?";

                    $stmt = mysqli_prepare($koneksi, $sql);

                    if ($stmt) {
                        mysqli_stmt_bind_param(
                            $stmt,
                            "ssssssssssi",
                            $nip, $nuptk, $nik, $nama, $jenis_kelamin,
                            $jabatan, $jenis_ptk, $no_hp, $alamat, $status,
                            $id_guru
                        );
                    }
                } else {
                    $sql = "INSERT INTO guru
                            (nip, nuptk, nik, nama, jenis_kelamin, jabatan,
                             jenis_ptk, no_hp, alamat, status)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                    $stmt = mysqli_prepare($koneksi, $sql);

                    if ($stmt) {
                        mysqli_stmt_bind_param(
                            $stmt,
                            "ssssssssss",
                            $nip, $nuptk, $nik, $nama, $jenis_kelamin,
                            $jabatan, $jenis_ptk, $no_hp, $alamat, $status
                        );
                    }
                }

                if ($stmt && mysqli_stmt_execute($stmt)) {
                    $id_tersimpan = $id_guru > 0 ? $id_guru : (int)mysqli_insert_id($koneksi);
                    [$ttd_ok, $ttd_error] = simpan_tanda_tangan_guru($koneksi, $id_tersimpan);
                    if ($ttd_ok) {
                        header("Location: index.php?sukses=1");
                        exit;
                    }
                    $pesan = 'Data guru/karyawan tersimpan, tetapi ' . $ttd_error;
                    $tipe_pesan = 'error';
                    $mode_edit = true;
                }

                $pesan = 'Data guru/karyawan gagal disimpan. Periksa kemungkinan NIP/NUPTK/NIK sudah digunakan.';
                $tipe_pesan = 'error';

            } catch (Throwable $e) {
                $pesan = 'Data guru/karyawan gagal disimpan. Pastikan struktur tabel guru sesuai database aplikasi.';
                $tipe_pesan = 'error';
            }
        }
    }

    if ($aksi === 'hapus') {
        $id_hapus = (int)($_POST['id_guru'] ?? 0);

        if ($id_hapus > 0) {
            try {
                $stmt = mysqli_prepare($koneksi, "DELETE FROM guru WHERE id_guru = ?");
                mysqli_stmt_bind_param($stmt, "i", $id_hapus);

                if (mysqli_stmt_execute($stmt)) {
                    header("Location: index.php?hapus=1");
                    exit;
                }

                $pesan = 'Data tidak dapat dihapus. Guru mungkin masih digunakan sebagai wali kelas atau pada absensi.';
                $tipe_pesan = 'error';
            } catch (Throwable $e) {
                $pesan = 'Data tidak dapat dihapus karena masih digunakan oleh data lain.';
                $tipe_pesan = 'error';
            }
        }
    }
}

if (isset($_GET['sukses'])) {
    $pesan = 'Data guru/karyawan berhasil disimpan.';
    $tipe_pesan = 'success';
}

if (isset($_GET['hapus'])) {
    $pesan = 'Data guru/karyawan berhasil dihapus.';
    $tipe_pesan = 'success';
}

if (isset($_GET['edit'])) {
    $id_edit = (int)$_GET['edit'];

    if ($id_edit > 0) {
        $stmt = mysqli_prepare($koneksi, "SELECT * FROM guru WHERE id_guru = ?");
        mysqli_stmt_bind_param($stmt, "i", $id_edit);
        mysqli_stmt_execute($stmt);
        $hasil = mysqli_stmt_get_result($stmt);

        if ($hasil && mysqli_num_rows($hasil) === 1) {
            $data_edit = mysqli_fetch_assoc($hasil);
            $mode_edit = true;
        }
    }
}

$cari = trim($_GET['cari'] ?? '');
$cari_sql = mysqli_real_escape_string($koneksi, $cari);

$sql_guru = "SELECT
                id_guru, nip, nuptk, nik, nama, jenis_kelamin,
                jabatan, jenis_ptk, no_hp, alamat, foto, tanda_tangan, status
             FROM guru";

if ($cari !== '') {
    $sql_guru .= " WHERE
                    nama LIKE '%$cari_sql%'
                    OR nip LIKE '%$cari_sql%'
                    OR nuptk LIKE '%$cari_sql%'
                    OR nik LIKE '%$cari_sql%'
                    OR jabatan LIKE '%$cari_sql%'
                    OR jenis_ptk LIKE '%$cari_sql%'";
}

$sql_guru .= " ORDER BY nama ASC";

$q_guru = mysqli_query($koneksi, $sql_guru);
$jumlah_guru = $q_guru ? mysqli_num_rows($q_guru) : 0;

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>

<style>
.guru-page{max-width:1450px}.page-head{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:24px}.page-head h1{margin-bottom:6px}.page-head p{margin:0}
.btn-primary,.btn-secondary,.btn-danger{display:inline-flex;align-items:center;justify-content:center;gap:7px;border:0;border-radius:10px;padding:11px 16px;text-decoration:none;font-size:14px;font-weight:600;cursor:pointer}
.btn-primary{background:linear-gradient(135deg,#2388f5,#1265dc);color:#fff;box-shadow:0 8px 18px rgba(18,101,220,.22)}.btn-secondary{background:#eef3f9;color:#334155}.btn-danger{background:#fff0f1;color:#c92f47}
.alert{padding:13px 15px;border-radius:11px;margin-bottom:18px;font-size:14px}.alert-success{background:#ecfdf3;color:#18794e;border:1px solid #ccefdc}.alert-error{background:#fff1f2;color:#be123c;border:1px solid #fecdd3}
.form-card,.data-panel{background:#fff;border-radius:18px;box-shadow:0 8px 25px rgba(15,35,70,.07);padding:24px;margin-bottom:22px}
.form-title{margin:0 0 5px}.form-subtitle{margin:0 0 20px;color:#64748b;font-size:14px}
.form-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:15px}.form-group{display:flex;flex-direction:column;gap:7px}.form-label{font-size:13px;font-weight:600;color:#334155}
.form-control{width:100%;min-height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:9px 11px;outline:none;background:#fff;font:inherit}.form-control:focus{border-color:#2388f5;box-shadow:0 0 0 3px rgba(35,136,245,.1)}
.form-actions{display:flex;gap:9px;margin-top:20px}
.toolbar{display:flex;align-items:center;justify-content:space-between;gap:15px;flex-wrap:wrap;margin-bottom:16px}
.import-toggle{display:inline-flex;align-items:center;gap:8px;margin-left:8px}.import-card{background:linear-gradient(135deg,#f8fbff,#f4fff9);border:1px solid #dbe8f5;border-radius:16px;padding:18px 20px;margin-bottom:22px}.import-head{display:flex;align-items:center;justify-content:space-between;gap:15px}.import-head h3{margin:0 0 4px;font-size:17px}.import-head p{margin:0;color:#64748b;font-size:13px}.import-actions{display:flex;align-items:center;gap:9px;flex-wrap:wrap;margin-top:14px}.file-upload{display:flex;align-items:center;gap:10px;flex:1;min-width:280px}.file-upload input{width:100%}.import-note{font-size:12px;color:#64748b;margin-top:9px}
.search-form{display:flex;gap:8px;flex:1;max-width:650px}.search-form input{width:100%;height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:0 13px;outline:none}.search-form input:focus{border-color:#2388f5;box-shadow:0 0 0 3px rgba(35,136,245,.1)}
.data-count{color:#64748b;font-size:14px}.table-wrap{overflow-x:auto}.data-table{width:100%;border-collapse:collapse;min-width:1100px}.data-table th{text-align:left;background:#f7f9fc;color:#64748b;font-size:12px;text-transform:uppercase;letter-spacing:.5px;padding:13px 12px}.data-table td{padding:14px 12px;border-bottom:1px solid #edf1f6;font-size:14px;color:#334155}.data-table tr:hover td{background:#fbfdff}
.nama-cell{min-width:220px}.nama-guru{font-weight:700;color:#17233c}.foto-guru-wrap{display:flex;align-items:center;gap:10px}.foto-guru{width:48px;height:58px;object-fit:cover;border-radius:9px;border:1px solid #dbe4ef;background:#f8fafc}.foto-placeholder{width:48px;height:58px;border-radius:9px;border:1px dashed #cbd5e1;background:#f8fafc;display:flex;align-items:center;justify-content:center;font-size:22px}.foto-toggle{border:1px solid #dbe4ef;background:#f8fafc;color:#334155;border-radius:8px;padding:6px 8px;font-size:12px;font-weight:700;cursor:pointer}.foto-form{display:none;margin-top:8px;padding:9px;border:1px solid #e2e8f0;border-radius:10px;background:#fbfdff}.foto-form.open{display:block}.foto-form input{width:100%;font-size:12px;margin-bottom:7px}.foto-actions{display:flex;gap:6px}.foto-actions button{border:0;border-radius:7px;padding:6px 9px;font-size:11px;font-weight:700;cursor:pointer}.foto-save{background:#0f766e;color:#fff}.foto-cancel{background:#eef2f7;color:#475569}.sub-text{font-size:12px;color:#94a3b8;margin-top:3px}.badge{display:inline-flex;align-items:center;padding:5px 9px;border-radius:999px;font-size:12px;font-weight:700}.badge-aktif{background:#eaf7ef;color:#16804a}.badge-lain{background:#eef2f7;color:#64748b}.aksi{display:flex;gap:7px}.ttd-preview{max-width:150px;max-height:62px;object-fit:contain;background:#fff;border:1px solid #e2e8f0;border-radius:7px;padding:4px}
@media(max-width:950px){.form-grid{grid-template-columns:1fr 1fr}}@media(max-width:650px){.page-head{align-items:flex-start;flex-direction:column}.form-grid{grid-template-columns:1fr}.search-form{max-width:none;width:100%}}
</style>

<main class="main-content">
<div class="guru-page">

<div class="page-head">
<div><h1>Data Guru & Karyawan</h1><p>Kelola data guru dan karyawan SDN Ciburayut 01.</p></div>
<div>
<a href="index.php?tambah=1" class="btn-primary">➕ Tambah Guru</a>
<?php if (in_array($user_role ?? '', ['admin','operator'], true)): ?><a href="index.php?upload_guru=1" class="btn-secondary import-toggle">📥 Upload Data Guru</a><?php endif; ?>
</div>
</div>

<?php if ($pesan_import !== ''): ?>
<div class="alert <?= $tipe_pesan_import === 'success' ? 'alert-success' : 'alert-error'; ?>"><?= $pesan_import; ?></div>
<?php endif; ?>

<?php if (isset($_GET['upload_guru'])): ?>
<div class="import-card">
<div class="import-head"><div><h3>📥 Upload Data Guru / Karyawan</h3><p>Gunakan <strong>format Daftar Guru Dapodik</strong> seperti file Excel yang Anda berikan.</p></div><a class="btn-secondary" href="index.php?unduh_template_guru=1">⬇️ Unduh Format</a></div>
<form method="post" enctype="multipart/form-data" class="import-actions">
<input type="hidden" name="aksi" value="import_excel_guru">
<div class="file-upload"><input type="file" name="file_excel_guru" class="form-control" accept=".xlsx" required></div>
<button type="submit" class="btn-primary">⬆️ Upload & Import</button>
<a href="index.php" class="btn-secondary">Tutup</a>
</form>
<div class="import-note">Format: <strong>.xlsx</strong>, maksimal 10 MB. Sistem membaca header Dapodik secara otomatis, lalu memetakan NIP, NUPTK, NIK, Nama, JK, Jabatan/Tugas Tambahan, Jenis PTK, HP, dan Alamat. Data yang sudah ada diperbarui berdasarkan NIP → NUPTK → NIK.</div>
</div>
<?php endif; ?>

<?php if ($pesan !== ''): ?>
<div class="alert <?= $tipe_pesan === 'success' ? 'alert-success' : 'alert-error'; ?>"><?= h($pesan); ?></div>
<?php endif; ?>

<?php if ($mode_edit || isset($_GET['tambah'])): ?>
<div class="form-card">
<h2 class="form-title"><?= $mode_edit ? 'Edit Data Guru & Karyawan' : 'Tambah Guru / Karyawan'; ?></h2>
<p class="form-subtitle">Data ini akan dipakai untuk wali kelas, absensi guru, dan pengguna aplikasi.</p>

<form method="post" enctype="multipart/form-data">
<input type="hidden" name="aksi" value="simpan">
<input type="hidden" name="id_guru" value="<?= (int)$data_edit['id_guru']; ?>">

<div class="form-grid">

<div class="form-group"><label class="form-label">NIP</label><input type="text" name="nip" class="form-control" value="<?= h($data_edit['nip']); ?>"></div>
<div class="form-group"><label class="form-label">NUPTK</label><input type="text" name="nuptk" class="form-control" value="<?= h($data_edit['nuptk']); ?>"></div>
<div class="form-group"><label class="form-label">NIK</label><input type="text" name="nik" class="form-control" value="<?= h($data_edit['nik']); ?>"></div>

<div class="form-group" style="grid-column:1 / -1"><label class="form-label">Nama Guru / Karyawan *</label><input type="text" name="nama" class="form-control" required value="<?= h($data_edit['nama']); ?>"></div>

<div class="form-group"><label class="form-label">Jenis Kelamin *</label><select name="jenis_kelamin" class="form-control" required><option value="L" <?= $data_edit['jenis_kelamin']==='L'?'selected':''; ?>>Laki-laki</option><option value="P" <?= $data_edit['jenis_kelamin']==='P'?'selected':''; ?>>Perempuan</option></select></div>
<div class="form-group"><label class="form-label">Jabatan</label><input type="text" name="jabatan" class="form-control" placeholder="Contoh: Guru Kelas" value="<?= h($data_edit['jabatan']); ?>"></div>
<div class="form-group"><label class="form-label">Jenis PTK</label><input type="text" name="jenis_ptk" class="form-control" placeholder="Contoh: Guru Kelas" value="<?= h($data_edit['jenis_ptk']); ?>"></div>

<div class="form-group"><label class="form-label">No. HP</label><input type="text" name="no_hp" class="form-control" value="<?= h($data_edit['no_hp']); ?>"></div>
<div class="form-group"><label class="form-label">Status</label><select name="status" class="form-control"><option value="Aktif" <?= $data_edit['status']==='Aktif'?'selected':''; ?>>Aktif</option><option value="Tidak Aktif" <?= $data_edit['status']==='Tidak Aktif'?'selected':''; ?>>Tidak Aktif</option></select></div>
<div class="form-group"><label class="form-label">Upload Tanda Tangan</label><input type="file" name="tanda_tangan" class="form-control" accept="image/png,image/jpeg,image/webp"><small class="sub-text">PNG, JPG, atau WEBP; maksimal 2 MB. Kosongkan untuk mempertahankan tanda tangan lama.</small><?php if (!empty($data_edit['tanda_tangan'])): ?><img class="ttd-preview" src="../../<?= h($data_edit['tanda_tangan']); ?>" alt="Tanda tangan saat ini"><?php endif; ?></div>
<div class="form-group full" style="grid-column:1 / -1"><label class="form-label">Alamat</label><textarea name="alamat" class="form-control" style="min-height:80px;resize:vertical"><?= h($data_edit['alamat']); ?></textarea></div>

</div>

<div class="form-actions"><button type="submit" class="btn-primary">💾 <?= $mode_edit ? 'Simpan Perubahan' : 'Simpan Guru'; ?></button><a href="index.php" class="btn-secondary">Batal</a></div>
</form>
</div>
<?php endif; ?>

<div class="data-panel">

<?php if (!$q_guru): ?><div class="alert alert-error">Data guru gagal dibaca: <?= h(mysqli_error($koneksi)); ?></div><?php endif; ?>

<div class="toolbar">
<form method="get" class="search-form"><input type="text" name="cari" value="<?= h($cari); ?>" placeholder="Cari nama, NIP, NUPTK, NIK, jabatan..."><button type="submit" class="btn-primary">🔎 Cari</button></form>
<div class="data-count">Menampilkan <strong><?= $jumlah_guru; ?></strong> data</div>
</div>

<div class="table-wrap">
<table class="data-table">
<thead><tr><th>No</th><th>NIP / NUPTK / NIK</th><th>Nama</th><th>JK</th><th>Jabatan</th><th>Jenis PTK</th><th>No. HP</th><th>TTD</th><th>Status</th><th width="150">Aksi</th></tr></thead>
<tbody>

<?php if ($q_guru && mysqli_num_rows($q_guru) > 0): ?>
<?php $no=1; while($guru=mysqli_fetch_assoc($q_guru)): ?>
<tr>
<td><?= $no++; ?></td>
<td>
<?= h($guru['nip'] ?: '-'); ?>
<div class="sub-text">NUPTK: <?= h($guru['nuptk'] ?: '-'); ?></div>
<div class="sub-text">NIK: <?= h($guru['nik'] ?: '-'); ?></div>
</td>
<td class="nama-cell">
<div class="foto-guru-wrap">
<?php if (!empty($guru['foto'])): ?><img class="foto-guru" src="../../<?= h($guru['foto']); ?>" alt="Foto <?= h($guru['nama']); ?>"><?php else: ?><div class="foto-placeholder">👤</div><?php endif; ?>
<div style="flex:1;min-width:0"><div class="nama-guru"><?= h($guru['nama']); ?></div>
<?php if (in_array(strtolower((string)($user_role ?? '')), ['admin','operator'], true)): ?><button type="button" class="foto-toggle" onclick="toggleFoto(<?= (int)$guru['id_guru']; ?>)">📷 <?= !empty($guru['foto']) ? 'Ganti Foto' : 'Upload Foto'; ?></button><?php endif; ?></div></div>
<?php if (in_array(strtolower((string)($user_role ?? '')), ['admin','operator'], true)): ?>
<form id="foto-form-<?= (int)$guru['id_guru']; ?>" class="foto-form" method="post" enctype="multipart/form-data">
<input type="hidden" name="aksi" value="upload_foto_guru"><input type="hidden" name="id_guru" value="<?= (int)$guru['id_guru']; ?>">
<input type="file" name="foto_guru" accept="image/jpeg,image/png,image/webp" required>
<div class="foto-actions"><button type="submit" class="foto-save">⬆️ Simpan</button><button type="button" class="foto-cancel" onclick="toggleFoto(<?= (int)$guru['id_guru']; ?>)">Batal</button></div>
<div class="sub-text">JPG, PNG, WEBP • maksimal 3 MB</div>
</form><?php endif; ?>
</td>
<td><?= $guru['jenis_kelamin']==='L' ? 'L' : 'P'; ?></td>
<td><?= h($guru['jabatan'] ?: '-'); ?></td>
<td><?= h($guru['jenis_ptk'] ?: '-'); ?></td>
<td><?= h($guru['no_hp'] ?: '-'); ?></td>
<td><?php if (!empty($guru['tanda_tangan'])): ?><img class="ttd-preview" src="../../<?= h($guru['tanda_tangan']); ?>" alt="TTD <?= h($guru['nama']); ?>"><?php else: ?><span class="sub-text">Belum ada</span><?php endif; ?></td>
<td><span class="badge <?= $guru['status']==='Aktif' ? 'badge-aktif' : 'badge-lain'; ?>"><?= h($guru['status']); ?></span></td>
<td><div class="aksi"><a href="index.php?edit=<?= (int)$guru['id_guru']; ?>" class="btn-secondary">✏️</a>
<form method="post" onsubmit="return confirm('Hapus data guru/karyawan ini?');"><input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id_guru" value="<?= (int)$guru['id_guru']; ?>"><button type="submit" class="btn-danger">🗑️</button></form></div></td>
</tr>
<?php endwhile; ?>
<?php else: ?>
<tr><td colspan="10" style="text-align:center;padding:45px 15px;color:#94a3b8;">Belum ada data guru/karyawan.</td></tr>
<?php endif; ?>

</tbody>
</table>
</div>
</div>
</div>
</main>
<script>function toggleFoto(id){var el=document.getElementById('foto-form-'+id);if(el)el.classList.toggle('open');}</script>
</body>
</html>
