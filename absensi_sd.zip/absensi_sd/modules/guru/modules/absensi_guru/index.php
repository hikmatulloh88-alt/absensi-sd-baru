<?php
require_once "../../config/database.php";

$menu_aktif = 'absensi_guru';
$page_title = 'Absensi Guru & Karyawan - SDN Ciburayut 01';

function h($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

/* Baca struktur tabel yang benar-benar digunakan */
$columns = [];
$qcols = mysqli_query($koneksi, "SHOW COLUMNS FROM absensi_guru");

if ($qcols) {
    while ($c = mysqli_fetch_assoc($qcols)) {
        $columns[] = $c['Field'];
    }
}

$has = function($field) use (&$columns) {
    return in_array($field, $columns, true);
};

$today = date('Y-m-d');
$tanggal = $_REQUEST['tanggal'] ?? $today;

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal)) {
    $tanggal = $today;
}

$id_tahun = (int)($_REQUEST['id_tahun_ajaran'] ?? 0);
$pesan = '';
$tipe = '';

/* =========================
   SIMPAN ABSENSI GURU
========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'simpan') {

    $tgl = $_POST['tanggal'] ?? $today;

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tgl)) {
        $tgl = $today;
    }

    $th = (int)($_POST['id_tahun_ajaran'] ?? 0);

    $status_rows = [];

    foreach ($_POST as $key => $value) {
        if (strpos($key, 'status_') === 0) {
            $id_guru = (int)substr($key, 7);
            if ($id_guru > 0) {
                $status_rows[$id_guru] = trim((string)$value);
            }
        }
    }

    if (!$has('id_guru') || !$has('tanggal') || !$has('status')) {

        $pesan = 'Struktur tabel absensi_guru belum memiliki kolom wajib id_guru, tanggal, dan status.';
        $tipe = 'error';

    } elseif (!$status_rows) {

        $pesan = 'Tidak ada data guru yang dikirim.';
        $tipe = 'error';

    } else {

        $berhasil = 0;
        $gagal = [];

        foreach ($status_rows as $id_guru => $status) {

            if (!in_array($status, ['Hadir', 'Sakit', 'Izin', 'Alpa', 'Dinas', 'Cuti'], true)) {
                $gagal[] = "ID $id_guru: status tidak valid";
                continue;
            }

            $keterangan = trim((string)($_POST['keterangan_' . $id_guru] ?? ''));

            /* Cari record hari yang sama */
            $sql_cek = "SELECT * FROM absensi_guru WHERE id_guru = ? AND tanggal = ?";
            $types_cek = "is";
            $vals_cek = [$id_guru, $tgl];

            if ($has('id_tahun_ajaran')) {
                $sql_cek .= " AND id_tahun_ajaran = ?";
                $types_cek .= "i";
                $vals_cek[] = $th;
            }

            $cek = mysqli_prepare($koneksi, $sql_cek);

            if (!$cek) {
                $gagal[] = "ID $id_guru: " . mysqli_error($koneksi);
                continue;
            }

            mysqli_stmt_bind_param($cek, $types_cek, ...$vals_cek);
            mysqli_stmt_execute($cek);

            $rc = mysqli_stmt_get_result($cek);
            $old = $rc ? mysqli_fetch_assoc($rc) : null;

            if ($old) {

                $primary = '';
                if (isset($old['id_absensi_guru'])) {
                    $primary = 'id_absensi_guru';
                } elseif (isset($old['id'])) {
                    $primary = 'id';
                }

                if ($primary === '') {
                    $gagal[] = "ID $id_guru: primary key absensi tidak dikenali";
                    continue;
                }

                $set = ["`status` = ?"];
                $vals = [$status];
                $types = "s";

                if ($has('keterangan')) {
                    $set[] = "`keterangan` = ?";
                    $vals[] = ($keterangan === '' ? null : $keterangan);
                    $types .= "s";
                }

                $vals[] = (int)$old[$primary];
                $types .= "i";

                $upd = mysqli_prepare(
                    $koneksi,
                    "UPDATE absensi_guru SET " . implode(', ', $set) .
                    " WHERE `$primary` = ?"
                );

                if ($upd) {
                    mysqli_stmt_bind_param($upd, $types, ...$vals);

                    if (mysqli_stmt_execute($upd)) {
                        $berhasil++;
                    } else {
                        $gagal[] = "ID $id_guru: " . mysqli_stmt_error($upd);
                    }
                } else {
                    $gagal[] = "ID $id_guru: " . mysqli_error($koneksi);
                }

            } else {

                $fields = ['id_guru', 'tanggal', 'status'];
                $vals = [$id_guru, $tgl, $status];
                $types = "iss";

                if ($has('id_tahun_ajaran')) {
                    $fields[] = 'id_tahun_ajaran';
                    $vals[] = $th;
                    $types .= "i";
                }

                if ($has('keterangan')) {
                    $fields[] = 'keterangan';
                    $vals[] = ($keterangan === '' ? null : $keterangan);
                    $types .= "s";
                }

                $marks = implode(',', array_fill(0, count($fields), '?'));
                $field_sql = '`' . implode('`,`', $fields) . '`';

                $ins = mysqli_prepare(
                    $koneksi,
                    "INSERT INTO absensi_guru ($field_sql) VALUES ($marks)"
                );

                if ($ins) {
                    mysqli_stmt_bind_param($ins, $types, ...$vals);

                    if (mysqli_stmt_execute($ins)) {
                        $berhasil++;
                    } else {
                        $gagal[] = "ID $id_guru: " . mysqli_stmt_error($ins);
                    }
                } else {
                    $gagal[] = "ID $id_guru: " . mysqli_error($koneksi);
                }
            }
        }

        if ($berhasil > 0) {
            $pesan = "Absensi berhasil disimpan untuk $berhasil guru/karyawan.";
            if ($gagal) {
                $pesan .= " Ada " . count($gagal) . " data yang gagal.";
            }
            $tipe = $gagal ? 'error' : 'success';
        } else {
            $pesan = 'Belum ada absensi guru yang tersimpan.';
            if ($gagal) {
                $pesan .= ' Detail: ' . implode(' | ', array_slice($gagal, 0, 3));
            }
            $tipe = 'error';
        }

        $tanggal = $tgl;
        $id_tahun = $th;
    }
}

/* Tahun ajaran */
$tahun = [];

if ($has('id_tahun_ajaran')) {
    $q = mysqli_query(
        $koneksi,
        "SELECT id_tahun_ajaran, tahun_ajaran, semester, aktif
         FROM tahun_ajaran
         ORDER BY aktif DESC, id_tahun_ajaran DESC"
    );

    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $tahun[] = $r;
        }
    }

    if (!$id_tahun && $tahun) {
        $id_tahun = (int)$tahun[0]['id_tahun_ajaran'];
    }
}

/* Guru/karyawan aktif */
$guru = [];

$where = "status = 'Aktif'";

$qguru = mysqli_query(
    $koneksi,
    "SELECT *
     FROM guru
     WHERE $where
     ORDER BY nama ASC"
);

if ($qguru) {
    while ($r = mysqli_fetch_assoc($qguru)) {
        $guru[] = $r;
    }
}

/* Absensi tanggal terpilih */
$absensi = [];

if ($has('id_guru') && $has('tanggal') && $has('status')) {

    $sql = "SELECT id_guru, status" . ($has('keterangan') ? ", keterangan" : "") .
           " FROM absensi_guru WHERE tanggal = ?";

    $vals = [$tanggal];
    $types = "s";

    if ($has('id_tahun_ajaran') && $id_tahun > 0) {
        $sql .= " AND id_tahun_ajaran = ?";
        $vals[] = $id_tahun;
        $types .= "i";
    }

    $st = mysqli_prepare($koneksi, $sql);

    if ($st) {
        mysqli_stmt_bind_param($st, $types, ...$vals);
        mysqli_stmt_execute($st);

        $rr = mysqli_stmt_get_result($st);

        if ($rr) {
            while ($r = mysqli_fetch_assoc($rr)) {
                $absensi[(int)$r['id_guru']] = $r;
            }
        }
    }
}

/* Statistik */
$stats = [
    'Hadir' => 0,
    'Sakit' => 0,
    'Izin' => 0,
    'Alpa' => 0,
    'Dinas' => 0,
    'Cuti' => 0
];

foreach ($absensi as $a) {
    $s = strtolower(trim($a['status'] ?? ''));

    if ($s === 'hadir') $stats['Hadir']++;
    elseif ($s === 'sakit') $stats['Sakit']++;
    elseif ($s === 'izin') $stats['Izin']++;
    elseif ($s === 'alpa' || $s === 'alpha') $stats['Alpa']++;
    elseif ($s === 'dinas') $stats['Dinas']++;
    elseif ($s === 'cuti') $stats['Cuti']++;
}

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>

<style>
.guru-page{max-width:1450px}
.page-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}
.page-head h1{margin:0 0 6px}.page-head p{margin:0}
.card{background:#fff;border-radius:18px;box-shadow:0 8px 25px rgba(15,35,70,.07);padding:20px;margin-bottom:20px}
.grid2{display:grid;grid-template-columns:repeat(2,1fr);gap:15px}
.fc,.st,.kt{width:100%;height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:0 11px;background:#fff}
label{display:block;font-size:13px;font-weight:600;color:#334155;margin-bottom:7px}
.btn{display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:10px;padding:11px 16px;font-weight:600;text-decoration:none;cursor:pointer}
.pri{background:linear-gradient(135deg,#2388f5,#1265dc);color:#fff;box-shadow:0 8px 18px rgba(18,101,220,.18)}
.sec{background:#eef3f9;color:#334155}
.alert{padding:13px 15px;border-radius:11px;margin-bottom:18px;font-size:14px;line-height:1.5}
.ok{background:#ecfdf3;color:#18794e;border:1px solid #ccefdc}.er{background:#fff1f2;color:#be123c;border:1px solid #fecdd3}
.stats{display:grid;grid-template-columns:repeat(6,1fr);gap:10px;margin-bottom:18px}
.stat{padding:14px;background:#f7f9fc;border-radius:13px}.stat strong{font-size:22px;display:block;color:#17233c}.stat span{font-size:12px;color:#64748b}
.tw{overflow-x:auto}.dt{width:100%;border-collapse:collapse;min-width:1000px}
.dt th{background:#f7f9fc;color:#64748b;font-size:12px;text-transform:uppercase;padding:12px;text-align:left}
.dt td{padding:11px 12px;border-bottom:1px solid #edf1f6}.nm{font-weight:700;color:#17233c}.sub{font-size:12px;color:#94a3b8;margin-top:3px}
.st{min-width:125px}.kt{min-width:210px}
.badge{display:inline-block;padding:4px 8px;border-radius:999px;background:#eef4ff;color:#1769d2;font-size:12px;font-weight:700}
@media(max-width:1000px){.stats{grid-template-columns:repeat(3,1fr)}}
@media(max-width:650px){.grid2{grid-template-columns:1fr}.stats{grid-template-columns:repeat(2,1fr)}.page-head{align-items:flex-start;flex-direction:column;gap:10px}}
</style>

<main class="main-content">
<div class="guru-page">

<div class="page-head">
<div>
<h1>Absensi Guru & Karyawan</h1>
<p>Catat kehadiran guru dan karyawan berdasarkan tanggal.</p>
</div>
</div>

<?php if($pesan): ?>
<div class="alert <?= $tipe==='success'?'ok':'er'; ?>"><?= h($pesan); ?></div>
<?php endif; ?>

<div class="card">
<form method="get">
<div class="grid2">

<div>
<label>Tanggal</label>
<input class="fc" type="date" name="tanggal" value="<?= h($tanggal); ?>">
</div>

<?php if($has('id_tahun_ajaran')): ?>
<div>
<label>Tahun Ajaran / Semester</label>
<select class="fc" name="id_tahun_ajaran">
<?php foreach($tahun as $t): ?>
<option value="<?= (int)$t['id_tahun_ajaran']; ?>" <?= $id_tahun===(int)$t['id_tahun_ajaran']?'selected':''; ?>>
<?= h($t['tahun_ajaran']); ?> - <?= h($t['semester']); ?>
</option>
<?php endforeach; ?>
</select>
</div>
<?php endif; ?>

</div>

<div style="margin-top:15px;display:flex;gap:8px">
<button class="btn pri" type="submit">🔎 Tampilkan</button>
<a class="btn sec" href="index.php">Reset</a>
</div>
</form>
</div>

<div class="stats">
<div class="stat"><strong><?= $stats['Hadir']; ?></strong><span>Hadir</span></div>
<div class="stat"><strong><?= $stats['Sakit']; ?></strong><span>Sakit</span></div>
<div class="stat"><strong><?= $stats['Izin']; ?></strong><span>Izin</span></div>
<div class="stat"><strong><?= $stats['Alpa']; ?></strong><span>Alpa</span></div>
<div class="stat"><strong><?= $stats['Dinas']; ?></strong><span>Dinas</span></div>
<div class="stat"><strong><?= $stats['Cuti']; ?></strong><span>Cuti</span></div>
</div>

<div class="card">

<form method="post">
<input type="hidden" name="aksi" value="simpan">
<input type="hidden" name="tanggal" value="<?= h($tanggal); ?>">
<input type="hidden" name="id_tahun_ajaran" value="<?= (int)$id_tahun; ?>">

<div class="tw">
<table class="dt">
<thead>
<tr>
<th>No</th>
<th>NIP</th>
<th>Nama Guru/Karyawan</th>
<th>Jabatan</th>
<th>Jenis PTK</th>
<th>Status</th>
<?php if($has('keterangan')): ?><th>Keterangan</th><?php endif; ?>
</tr>
</thead>

<tbody>

<?php if($guru): ?>

<?php $no=1; foreach($guru as $g): ?>
<?php
$idg=(int)$g['id_guru'];
$a=$absensi[$idg]??[];
$status_now=$a['status']??'Hadir';
$ket_now=$a['keterangan']??'';
?>

<tr>
<td><?= $no++; ?></td>
<td>
<?= h($g['nip'] ?? $g['nuptk'] ?? '-'); ?>
<div class="sub">NUPTK: <?= h($g['nuptk'] ?? '-'); ?></div>
</td>

<td>
<div class="nm"><?= h($g['nama'] ?? $g['nama_guru'] ?? '-'); ?></div>
<div class="sub"><?= h($g['nik'] ?? '-'); ?></div>
</td>

<td><?= h($g['jabatan'] ?? '-'); ?></td>
<td><span class="badge"><?= h($g['jenis_ptk'] ?? '-'); ?></span></td>

<td>
<select class="st" name="status_<?= $idg; ?>">
<?php foreach(['Hadir','Sakit','Izin','Alpa','Dinas','Cuti'] as $opt): ?>
<option value="<?= $opt; ?>" <?= strtolower($status_now)===strtolower($opt)?'selected':''; ?>>
<?= $opt; ?>
</option>
<?php endforeach; ?>
</select>
</td>

<?php if($has('keterangan')): ?>
<td>
<input class="kt" name="keterangan_<?= $idg; ?>" value="<?= h($ket_now); ?>" placeholder="Keterangan...">
</td>
<?php endif; ?>

</tr>
<?php endforeach; ?>

<?php else: ?>
<tr>
<td colspan="<?= $has('keterangan')?7:6; ?>" style="text-align:center;padding:40px;color:#94a3b8">
Belum ada guru/karyawan aktif.
</td>
</tr>
<?php endif; ?>

</tbody>
</table>
</div>

<?php if($guru): ?>
<div style="margin-top:18px;text-align:right">
<button class="btn pri" type="submit">💾 Simpan Absensi Guru</button>
</div>
<?php endif; ?>

</form>

</div>
</div>
</main>

</body>
</html>
