<?php
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator');
require_once "../../config/database.php";

$menu_aktif = 'absensi_guru';
$page_title = 'Absensi Guru & Karyawan - SDN Ciburayut 01';

function h($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

$columns = [];
$qcols = mysqli_query($koneksi, "SHOW COLUMNS FROM absensi_guru");
if ($qcols) {
    while ($r = mysqli_fetch_assoc($qcols)) {
        $columns[] = $r['Field'];
    }
}
$has = function($field) use (&$columns) {
    return in_array($field, $columns, true);
};

$tanggal = $_REQUEST['tanggal'] ?? date('Y-m-d');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal)) {
    $tanggal = date('Y-m-d');
}

$id_tahun = (int)($_REQUEST['id_tahun_ajaran'] ?? 0);
$pesan = '';
$tipe = '';

/* Tahun ajaran */
$tahun = [];
if ($has('id_tahun_ajaran')) {
    $q = mysqli_query(
        $koneksi,
        "SELECT id_tahun_ajaran, tahun_ajaran, semester, aktif
         FROM tahun_ajaran
         ORDER BY aktif DESC, id_tahun_ajaran DESC"
    );
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $tahun[] = $r;
        }
    }
    if (!$id_tahun && $tahun) {
        $id_tahun = (int)$tahun[0]['id_tahun_ajaran'];
    }
}

/* Simpan */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'simpan') {
    $tgl = $_POST['tanggal'] ?? date('Y-m-d');
    $th = (int)($_POST['id_tahun_ajaran'] ?? 0);

    $statusRows = [];
    foreach ($_POST as $key => $value) {
        if (strpos($key, 'status_') === 0) {
            $id = (int)substr($key, 7);
            if ($id > 0) $statusRows[$id] = trim((string)$value);
        }
    }

    if (!$has('id_guru') || !$has('tanggal') || !$has('status')) {
        $pesan = 'Struktur tabel absensi_guru belum memiliki kolom wajib.';
        $tipe = 'error';
    } elseif (!$statusRows) {
        $pesan = 'Tidak ada data guru yang dikirim.';
        $tipe = 'error';
    } else {
        $berhasil = 0;
        $gagal = [];

        foreach ($statusRows as $id_guru => $status) {
            if (!in_array($status, ['Hadir','Sakit','Izin','Alpa','Dinas','Cuti'], true)) {
                $gagal[] = "ID $id_guru: status tidak valid";
                continue;
            }

            $ket = trim((string)($_POST['keterangan_'.$id_guru] ?? ''));

            $sqlc = "SELECT * FROM absensi_guru WHERE id_guru=? AND tanggal=?";
            $tc = "is";
            $vc = [$id_guru, $tgl];

            if ($has('id_tahun_ajaran')) {
                $sqlc .= " AND id_tahun_ajaran=?";
                $tc .= "i";
                $vc[] = $th;
            }

            $cek = mysqli_prepare($koneksi, $sqlc);
            $old = null;
            if ($cek) {
                mysqli_stmt_bind_param($cek, $tc, ...$vc);
                mysqli_stmt_execute($cek);
                $rr = mysqli_stmt_get_result($cek);
                $old = $rr ? mysqli_fetch_assoc($rr) : null;
            }

            if ($old) {
                $primary = isset($old['id_absensi_guru']) ? 'id_absensi_guru' :
                           (isset($old['id']) ? 'id' : '');

                if (!$primary) {
                    $gagal[] = "ID $id_guru: primary key tidak dikenali";
                    continue;
                }

                $set = ['`status`=?'];
                $vals = [$status];
                $types = 's';

                if ($has('keterangan')) {
                    $set[]='`keterangan`=?';
                    $vals[] = $ket === '' ? null : $ket;
                    $types .= 's';
                }

                $vals[]=(int)$old[$primary];
                $types.='i';

                $u = mysqli_prepare(
                    $koneksi,
                    "UPDATE absensi_guru SET ".implode(',', $set)." WHERE `$primary`=?"
                );

                if ($u) {
                    mysqli_stmt_bind_param($u, $types, ...$vals);
                    if (mysqli_stmt_execute($u)) $berhasil++;
                    else $gagal[] = "ID $id_guru: ".mysqli_stmt_error($u);
                } else {
                    $gagal[] = "ID $id_guru: ".mysqli_error($koneksi);
                }
            } else {
                $fields = ['id_guru','tanggal','status'];
                $vals = [$id_guru,$tgl,$status];
                $types = 'iss';

                if ($has('id_tahun_ajaran')) {
                    $fields[]='id_tahun_ajaran';
                    $vals[]=$th;
                    $types.='i';
                }

                if ($has('keterangan')) {
                    $fields[]='keterangan';
                    $vals[]=$ket === '' ? null : $ket;
                    $types.='s';
                }

                $marks=implode(',',array_fill(0,count($fields),'?'));
                $f='`'.implode('`,`',$fields).'`';

                $ins=mysqli_prepare(
                    $koneksi,
                    "INSERT INTO absensi_guru ($f) VALUES ($marks)"
                );

                if ($ins) {
                    mysqli_stmt_bind_param($ins,$types,...$vals);
                    if (mysqli_stmt_execute($ins)) $berhasil++;
                    else $gagal[]="ID $id_guru: ".mysqli_stmt_error($ins);
                } else {
                    $gagal[]="ID $id_guru: ".mysqli_error($koneksi);
                }
            }
        }

        if ($berhasil > 0) {
            $pesan = "Absensi berhasil disimpan untuk $berhasil guru/karyawan.";
            if ($gagal) $pesan .= " Ada ".count($gagal)." data gagal.";
            $tipe = $gagal ? 'error' : 'success';
        } else {
            $pesan = "Belum ada absensi yang tersimpan.";
            if ($gagal) $pesan .= " Detail: ".implode(' | ',array_slice($gagal,0,3));
            $tipe='error';
        }

        $tanggal = $tgl;
        $id_tahun = $th;
    }
}

/* Hapus banyak absensi guru yang dipilih, hanya pada tanggal/periode yang sedang ditampilkan */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'hapus_banyak') {
    $tgl_hapus = $_POST['tanggal'] ?? $tanggal;
    $th_hapus = (int)($_POST['id_tahun_ajaran'] ?? $id_tahun);
    $pilih = $_POST['selected_guru'] ?? [];
    $pilih = is_array($pilih) ? array_values(array_unique(array_filter(array_map('intval', $pilih), fn($v) => $v > 0))) : [];

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tgl_hapus)) $tgl_hapus = $tanggal;

    if (!$pilih) {
        $pesan = 'Pilih minimal satu guru/karyawan yang akan dihapus.';
        $tipe = 'error';
    } elseif (!$has('tanggal') || !$has('id_guru')) {
        $pesan = 'Kolom tanggal atau id_guru pada tabel absensi_guru tidak ditemukan.';
        $tipe = 'error';
    } else {
        $marks = implode(',', array_fill(0, count($pilih), '?'));
        $sql = "DELETE FROM absensi_guru WHERE tanggal=?";
        $types = 's';
        $vals = [$tgl_hapus];
        if ($has('id_tahun_ajaran') && $th_hapus > 0) { $sql .= " AND id_tahun_ajaran=?"; $types .= 'i'; $vals[] = $th_hapus; }
        $sql .= " AND id_guru IN ($marks)";
        $types .= str_repeat('i', count($pilih));
        $vals = array_merge($vals, $pilih);

        $del = mysqli_prepare($koneksi, $sql);
        if ($del) {
            mysqli_stmt_bind_param($del, $types, ...$vals);
            if (mysqli_stmt_execute($del)) {
                $jumlah = mysqli_stmt_affected_rows($del);
                $pesan = "Berhasil menghapus $jumlah data absensi guru/karyawan yang dipilih pada tanggal " . date('d-m-Y', strtotime($tgl_hapus)) . ".";
                $tipe = 'success';
            } else { $pesan = 'Gagal menghapus data absensi: ' . mysqli_stmt_error($del); $tipe = 'error'; }
        } else { $pesan = 'Gagal menyiapkan penghapusan: ' . mysqli_error($koneksi); $tipe = 'error'; }
        $tanggal = $tgl_hapus; $id_tahun = $th_hapus;
    }
}

/* Data guru */
$guru = [];
$qguru = mysqli_query(
    $koneksi,
    "SELECT * FROM guru
     WHERE status = 'Aktif'
     ORDER BY nama ASC"
);
if ($qguru) {
    while ($r=mysqli_fetch_assoc($qguru)) $guru[]=$r;
}

/* Absensi */
$absensi=[];
if ($has('id_guru') && $has('tanggal') && $has('status')) {
    $sql="SELECT id_guru,status".($has('keterangan')?",keterangan":"")." FROM absensi_guru WHERE tanggal=?";
    $vals=[$tanggal];
    $types='s';

    if ($has('id_tahun_ajaran') && $id_tahun>0) {
        $sql.=" AND id_tahun_ajaran=?";
        $vals[]=$id_tahun;
        $types.='i';
    }

    $st=mysqli_prepare($koneksi,$sql);
    if($st){
        mysqli_stmt_bind_param($st,$types,...$vals);
        mysqli_stmt_execute($st);
        $rr=mysqli_stmt_get_result($st);
        if($rr) while($r=mysqli_fetch_assoc($rr)) $absensi[(int)$r['id_guru']]=$r;
    }
}

$stats=['Hadir'=>0,'Sakit'=>0,'Izin'=>0,'Alpa'=>0,'Dinas'=>0,'Cuti'=>0];
foreach($absensi as $a){
    $s=strtolower(trim($a['status']??''));
    if($s==='hadir')$stats['Hadir']++;
    elseif($s==='sakit')$stats['Sakit']++;
    elseif($s==='izin')$stats['Izin']++;
    elseif($s==='alpa'||$s==='alpha')$stats['Alpa']++;
    elseif($s==='dinas')$stats['Dinas']++;
    elseif($s==='cuti')$stats['Cuti']++;
}

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>
<style>
.gp{max-width:1450px}.ph{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}.ph h1{margin:0 0 6px}.ph p{margin:0}
.card{background:#fff;border-radius:18px;box-shadow:0 8px 25px rgba(15,35,70,.07);padding:20px;margin-bottom:20px}.grid2{display:grid;grid-template-columns:repeat(2,1fr);gap:15px}
label{display:block;font-size:13px;font-weight:600;color:#334155;margin-bottom:7px}.fc,.st,.kt{width:100%;height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:0 11px;background:#fff}
.btn{display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:10px;padding:11px 16px;font-weight:600;text-decoration:none;cursor:pointer}.danger{background:#fee2e2;color:#b91c1c;border:1px solid #fecaca}.pri{background:linear-gradient(135deg,#2388f5,#1265dc);color:#fff}.sec{background:#eef3f9;color:#334155}
.alert{padding:13px 15px;border-radius:11px;margin-bottom:18px;font-size:14px}.ok{background:#ecfdf3;color:#18794e;border:1px solid #ccefdc}.er{background:#fff1f2;color:#be123c;border:1px solid #fecdd3}
.stats{display:grid;grid-template-columns:repeat(6,1fr);gap:10px;margin-bottom:18px}.stat{padding:14px;background:#f7f9fc;border-radius:13px}.stat strong{display:block;font-size:22px;color:#17233c}.stat span{font-size:12px;color:#64748b}
.tw{overflow-x:auto}.dt{width:100%;border-collapse:collapse;min-width:1050px}.dt th{background:#f7f9fc;color:#64748b;font-size:12px;text-transform:uppercase;padding:12px;text-align:left}.dt td{padding:11px 12px;border-bottom:1px solid #edf1f6}.nm{font-weight:700;color:#17233c}.sub{font-size:12px;color:#94a3b8;margin-top:3px}.st{min-width:125px}.kt{min-width:210px}.check{width:18px;height:18px;cursor:pointer;accent-color:#2388f5}.bulk-btn{display:none}.bulk-btn.show{display:inline-flex}
@media(max-width:1000px){.stats{grid-template-columns:repeat(3,1fr)}}@media(max-width:650px){.grid2,.stats{grid-template-columns:1fr}.ph{align-items:flex-start;flex-direction:column;gap:10px}}
</style>

<main class="main-content"><div class="gp">

<div class="ph"><div><h1>Absensi Guru & Karyawan</h1><p>Catat kehadiran guru dan karyawan berdasarkan tanggal.</p></div>
<div style="display:flex;gap:8px;flex-wrap:wrap;">
<a class="btn sec" href="cetak_kartu.php">🎫 Cetak Kartu Pegawai</a>
<a class="btn sec" href="../rekap/index.php">📊 Rekap Kehadiran</a>
<button class="btn danger bulk-btn" id="bulkDeleteBtn" type="submit" form="formAbsensi" name="aksi" value="hapus_banyak" onclick="return confirmHapusBanyak();">🗑️ Hapus Banyak Data <span id="bulkCount"></span></button>
</div>
</div>

<?php if($pesan): ?><div class="alert <?=$tipe==='success'?'ok':'er'?>"><?=h($pesan)?></div><?php endif; ?>

<div class="card"><form method="get"><div class="grid2">
<div><label>Tanggal</label><input class="fc" type="date" name="tanggal" value="<?=h($tanggal)?>"></div>
<?php if($has('id_tahun_ajaran')): ?><div><label>Tahun Ajaran / Semester</label><select class="fc" name="id_tahun_ajaran"><?php foreach($tahun as $t): ?><option value="<?=$t['id_tahun_ajaran']?>" <?=$id_tahun===(int)$t['id_tahun_ajaran']?'selected':''?>><?=h($t['tahun_ajaran'])?> - <?=h($t['semester'])?></option><?php endforeach;?></select></div><?php endif; ?>
</div><div style="margin-top:15px;display:flex;gap:8px"><button class="btn pri">🔎 Tampilkan</button><a class="btn sec" href="absensi.php">Reset</a></div></form></div>

<div class="stats">
<?php foreach(['Hadir','Sakit','Izin','Alpa','Dinas','Cuti'] as $x): ?><div class="stat"><strong><?=$stats[$x]?></strong><span><?=$x?></span></div><?php endforeach; ?>
</div>

<div class="card"><form method="post" id="formAbsensi">
<input type="hidden" name="aksi" value="simpan"><input type="hidden" name="tanggal" value="<?=h($tanggal)?>"><input type="hidden" name="id_tahun_ajaran" value="<?=$id_tahun?>">
<div class="tw"><table class="dt"><thead><tr><th style="width:45px"><input class="check" type="checkbox" id="checkAll" title="Pilih semua"></th><th>No</th><th>NIP/NU PTK</th><th>Nama</th><th>Jabatan</th><th>Jenis PTK</th><th>Status</th><?php if($has('keterangan')):?><th>Keterangan</th><?php endif;?></tr></thead>
<tbody>
<?php if($guru):$no=1;foreach($guru as $g):$idg=(int)$g['id_guru'];$a=$absensi[$idg]??[];$sn=$a['status']??'Hadir';$kn=$a['keterangan']??'';?>
<tr><td><input class="check row-check" type="checkbox" name="selected_guru[]" value="<?=$idg?>" aria-label="Pilih <?=h($g['nama']??$g['nama_guru']??'-')?>"></td><td><?=$no++?></td><td><?=h($g['nip']??'-')?><div class="sub">NUPTK: <?=h($g['nuptk']??'-')?></div></td><td><div class="nm"><?=h($g['nama']??$g['nama_guru']??'-')?></div></td><td><?=h($g['jabatan']??'-')?></td><td><?=h($g['jenis_ptk']??'-')?></td><td><select class="st" name="status_<?=$idg?>"><?php foreach(['Hadir','Sakit','Izin','Alpa','Dinas','Cuti'] as $x):?><option value="<?=$x?>" <?=$sn===$x?'selected':''?>><?=$x?></option><?php endforeach;?></select></td><?php if($has('keterangan')):?><td><input class="kt" name="keterangan_<?=$idg?>" value="<?=h($kn)?>" placeholder="Keterangan..."></td><?php endif;?></tr>
<?php endforeach;else:?><tr><td colspan="<?=$has('keterangan')?8:7?>" style="text-align:center;padding:40px;color:#94a3b8">Belum ada guru/karyawan aktif.</td></tr><?php endif;?>
</tbody></table></div>
<?php if($guru):?><div style="margin-top:18px;display:flex;justify-content:flex-end;gap:8px;flex-wrap:wrap">
<button class="btn sec" type="submit" name="aksi" value="simpan">💾 Simpan Absensi Guru</button>
</div><?php endif;?>
</form>
</div>
</div>
<script>
(function(){
  const all=document.getElementById('checkAll');
  const rows=()=>Array.from(document.querySelectorAll('.row-check'));
  const btn=document.getElementById('bulkDeleteBtn');
  const count=document.getElementById('bulkCount');
  function refresh(){
    const rs=rows(), n=rs.filter(x=>x.checked).length;
    if(btn) btn.classList.toggle('show', n>0);
    if(count) count.textContent=n?`(${n})`:'';
    if(all){ all.checked=rs.length>0 && n===rs.length; all.indeterminate=n>0 && n<rs.length; }
  }
  if(all) all.addEventListener('change',()=>{rows().forEach(x=>x.checked=all.checked);refresh();});
  rows().forEach(x=>x.addEventListener('change',refresh));
  window.confirmHapusBanyak=function(){
    const n=rows().filter(x=>x.checked).length;
    if(!n){ alert('Pilih minimal satu guru/karyawan.'); return false; }
    return confirm(`Hapus ${n} data absensi guru/karyawan yang dipilih pada tanggal ini? Data yang dihapus tidak dapat dikembalikan.`);
  };
  refresh();
})();
</script>
</main></body></html>
