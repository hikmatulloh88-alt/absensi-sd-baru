<?php
require_once '../../config/auth.php';
wajib_login();
require_once '../../config/database.php';

$page_title = 'Laporan & Cetak - SDN Ciburayut 01';
$menu_aktif = 'laporan';

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$items = [
    [
        'icon'=>'📘','title'=>'Cetak Buku Induk','desc'=>'Cetak buku induk siswa secara massal sesuai kelas.',
        'url'=>'/absensi_sd/modules/buku_induk/cetak_masal.php','perm'=>'buku_induk_masal','class'=>'blue'
    ],
    [
        'icon'=>'🎫','title'=>'Cetak Kartu Siswa / QR','desc'=>'Cetak kartu siswa yang digunakan untuk identifikasi dan absensi QR.',
        'url'=>'/absensi_sd/modules/absensi/cetak_kartu.php','perm'=>'kartu_absensi','class'=>'violet'
    ],
    [
        'icon'=>'👨‍🏫','title'=>'Cetak Kartu Guru & Karyawan','desc'=>'Cetak kartu identitas guru dan karyawan.',
        'url'=>'/absensi_sd/modules/guru/cetak_kartu.php','perm'=>'absensi_guru','class'=>'green'
    ],
    [
        'icon'=>'📅','title'=>'Laporan Kehadiran Siswa & Guru/Karyawan','desc'=>'Buka rekap kehadiran siswa berdasarkan periode dan kelas.',
        'url'=>'/absensi_sd/modules/rekap/index.php?cetak=1','perm'=>'rekap_absensi','class'=>'orange'
    ],
    [
        'icon'=>'📚','title'=>'Laporan Nilai / Rapor','desc'=>'Lihat rekap nilai dan cetak rapor siswa.',
        'url'=>'/absensi_sd/modules/laporan/index.php','perm'=>'laporan','class'=>'teal'
    ],
    [
        'icon'=>'🖨️','title'=>'Cetak Rapor Masal','desc'=>'Cetak rapor seluruh siswa dalam satu kelas sekaligus.',
        'url'=>'/absensi_sd/modules/laporan/cetak_masal.php','perm'=>'laporan','class'=>'indigo'
    ],
    [
        'icon'=>'🏅','title'=>'Laporan Ekstrakurikuler','desc'=>'Cetak kegiatan, kehadiran, dokumentasi, dan laporan eskul.',
        'url'=>'/absensi_sd/modules/ekstrakurikuler/laporan.php','perm'=>'ekstrakurikuler','class'=>'pink'
    ],
];

require_once '../../includes/header.php';
require_once '../../includes/sidebar.php';
?>
<style>
.print-center{max-width:1250px;margin:0 auto;padding-bottom:40px}
.print-head{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:24px}
.print-head h1{margin:0 0 7px;font-size:30px;color:#17233c}
.print-head p{margin:0;color:#64748b}
.print-badge{padding:10px 14px;border-radius:12px;background:#eef6ff;color:#1769d2;font-weight:700;font-size:13px;white-space:nowrap}
.print-section{margin:28px 0 12px;font-size:14px;font-weight:800;color:#334155;display:flex;align-items:center;gap:8px}
.print-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
.print-card{background:#fff;border:1px solid #e7edf5;border-radius:18px;padding:20px;display:flex;align-items:center;gap:16px;box-shadow:0 7px 24px rgba(15,35,70,.06);transition:.18s ease}
.print-card:hover{transform:translateY(-2px);box-shadow:0 12px 30px rgba(15,35,70,.10)}
.print-icon{width:56px;height:56px;border-radius:15px;display:flex;align-items:center;justify-content:center;font-size:27px;flex:0 0 56px}
.print-card.blue .print-icon{background:#eaf4ff}.print-card.violet .print-icon{background:#f1edff}.print-card.green .print-icon{background:#eaf9f0}.print-card.orange .print-icon{background:#fff4e7}.print-card.teal .print-icon{background:#e8faf8}.print-card.indigo .print-icon{background:#edf0ff}.print-card.pink .print-icon{background:#fff0f6}
.print-body{flex:1;min-width:0}.print-body h3{margin:0 0 5px;font-size:16px;color:#17233c}.print-body p{margin:0;color:#64748b;font-size:13px;line-height:1.5}
.print-btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;padding:10px 13px;border-radius:10px;background:#1671e8;color:#fff;text-decoration:none;font-weight:700;font-size:12px;white-space:nowrap}
.print-btn:hover{background:#0f60cb}
.print-info{margin-top:22px;padding:15px 17px;border:1px solid #dbeafe;background:#f5f9ff;border-radius:13px;color:#315b8c;font-size:13px;line-height:1.55}
@media(max-width:800px){.print-grid{grid-template-columns:1fr}.print-head{align-items:flex-start;flex-direction:column}.print-card{align-items:flex-start}.print-btn{margin-left:auto}}
</style>

<main class="main-content">
<div class="print-center">
    <div class="print-head">
        <div>
            <h1>🖨️ Laporan &amp; Cetak</h1>
            <p>Satu pusat untuk seluruh dokumen laporan dan kebutuhan cetak aplikasi.</p>
        </div>
        <div class="print-badge">SEMUA CETAK DI SINI</div>
    </div>

    <div class="print-section">📄 DOKUMEN &amp; LAPORAN</div>
    <div class="print-grid">
        <?php foreach($items as $it): ?>
            <?php if (!menu_diizinkan($it['perm'])) continue; ?>
            <div class="print-card <?=h($it['class'])?>">
                <div class="print-icon"><?=h($it['icon'])?></div>
                <div class="print-body">
                    <h3><?=h($it['title'])?></h3>
                    <p><?=h($it['desc'])?></p>
                </div>
                <a class="print-btn" href="<?=h($it['url'])?>">Buka →</a>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="print-info">
        <strong>💡 Konsep baru:</strong> menu input tetap berada di menu masing-masing. Semua akses untuk melihat laporan atau mencetak dokumen dikumpulkan di halaman <strong>Laporan &amp; Cetak</strong>, sehingga sidebar lebih bersih dan mudah digunakan.
    </div>
</div>
</main>
</body>
</html>
