<?php
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator', 'Guru');

require_once "../../config/database.php";

$menu_aktif = 'laporan';
$page_title = 'Laporan Nilai / Rapor - SDN Ciburayut 01';

function h($v){
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

$id_tahun = (int)($_GET['id_tahun_ajaran'] ?? 0);
$id_kelas = (int)($_GET['id_kelas'] ?? 0);
$id_siswa = (int)($_GET['id_siswa'] ?? 0);

/* Tahun ajaran */
$tahun = [];
$q = mysqli_query(
    $koneksi,
    "SELECT id_tahun_ajaran,tahun_ajaran,semester,aktif
     FROM tahun_ajaran
     ORDER BY aktif DESC,id_tahun_ajaran DESC"
);
if($q){
    while($r=mysqli_fetch_assoc($q)) $tahun[]=$r;
}
if(!$id_tahun && $tahun) $id_tahun=(int)$tahun[0]['id_tahun_ajaran'];

/* Kelas */
$kelas = [];
$q = mysqli_query(
    $koneksi,
    "SELECT id_kelas,nama_kelas,tingkat
     FROM kelas
     ORDER BY tingkat,nama_kelas"
);
if($q){
    while($r=mysqli_fetch_assoc($q)) $kelas[]=$r;
}

/* Siswa */
$siswa = [];
$sql = "SELECT s.id_siswa,s.nis,s.nisn,s.nama_siswa,k.nama_kelas
        FROM siswa s
        LEFT JOIN kelas k ON k.id_kelas=s.id_kelas
        WHERE s.status_siswa='Aktif'";
if($id_kelas>0) $sql .= " AND s.id_kelas=".$id_kelas;
$sql .= " ORDER BY k.tingkat,k.nama_kelas,s.nama_siswa";

$q = mysqli_query($koneksi,$sql);
if($q){
    while($r=mysqli_fetch_assoc($q)) $siswa[]=$r;
}

/* Periode aktif */
$periode = null;
foreach($tahun as $t){
    if((int)$t['id_tahun_ajaran']===$id_tahun){
        $periode=$t;
        break;
    }
}

/* Rekap nilai */
$data_siswa = [];
if($id_tahun>0){

    $where = "n.id_tahun_ajaran=".$id_tahun;

    if($id_kelas>0) $where .= " AND n.id_kelas=".$id_kelas;
    if($id_siswa>0) $where .= " AND n.id_siswa=".$id_siswa;

    $q = mysqli_query(
        $koneksi,
        "SELECT
            n.id_siswa,
            n.nilai_tugas,
            n.nilai_uts,
            n.nilai_uas,
            n.nilai_akhir,
            s.nis,
            s.nisn,
            s.nama_siswa,
            k.nama_kelas,
            mp.nama_mapel
         FROM nilai n
         INNER JOIN siswa s ON s.id_siswa=n.id_siswa
         LEFT JOIN kelas k ON k.id_kelas=n.id_kelas
         INNER JOIN mata_pelajaran mp ON mp.id_mapel=n.id_mapel
         WHERE $where
         ORDER BY k.tingkat,k.nama_kelas,s.nama_siswa,mp.nama_mapel"
    );

    if($q){
        while($r=mysqli_fetch_assoc($q)){

            $sid=(int)$r['id_siswa'];

            if(!isset($data_siswa[$sid])){
                $data_siswa[$sid]=[
                    'id_siswa'=>$sid,
                    'nis'=>$r['nis'],
                    'nisn'=>$r['nisn'],
                    'nama_siswa'=>$r['nama_siswa'],
                    'nama_kelas'=>$r['nama_kelas'],
                    'nilai'=>[],
                    'total'=>0,
                    'jumlah'=>0
                ];
            }

            $akhir=(float)($r['nilai_akhir'] ?? 0);

            $data_siswa[$sid]['nilai'][]=[
                'mapel'=>$r['nama_mapel'],
                'tugas'=>(float)($r['nilai_tugas'] ?? 0),
                'uts'=>(float)($r['nilai_uts'] ?? 0),
                'uas'=>(float)($r['nilai_uas'] ?? 0),
                'akhir'=>$akhir
            ];

            $data_siswa[$sid]['total'] += $akhir;
            $data_siswa[$sid]['jumlah']++;
        }
    }

    foreach($data_siswa as &$d){
        $d['rata'] = $d['jumlah'] ? round($d['total']/$d['jumlah'],2) : 0;
    }
    unset($d);
}

$selected = null;
if($id_siswa>0 && isset($data_siswa[$id_siswa])){
    $selected=$data_siswa[$id_siswa];
}

/* Jika siswa belum dipilih, ambil dari filter siswa */
if(!$selected && $id_siswa>0){
    foreach($siswa as $s){
        if((int)$s['id_siswa']===$id_siswa){
            $selected=[
                'id_siswa'=>(int)$s['id_siswa'],
                'nis'=>$s['nis'],
                'nisn'=>$s['nisn'],
                'nama_siswa'=>$s['nama_siswa'],
                'nama_kelas'=>$s['nama_kelas'],
                'nilai'=>[],
                'total'=>0,
                'jumlah'=>0,
                'rata'=>0
            ];
            break;
        }
    }
}

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>

<style>
.lp{max-width:1450px}
.head{margin-bottom:22px}
.head h1{margin:0 0 6px}
.head p{margin:0}
.card{background:#fff;border-radius:18px;box-shadow:0 8px 25px rgba(15,35,70,.07);padding:20px;margin-bottom:20px}
.filters{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
label{display:block;font-size:13px;font-weight:600;color:#334155;margin-bottom:7px}
.fc{width:100%;height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:0 11px;background:#fff}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;border:0;border-radius:10px;padding:11px 16px;font-weight:600;text-decoration:none;cursor:pointer}
.pri{background:linear-gradient(135deg,#2388f5,#1265dc);color:#fff}
.sec{background:#eef3f9;color:#334155}
.tw{overflow-x:auto}
.dt{width:100%;border-collapse:collapse;min-width:800px}
.dt th{background:#f7f9fc;color:#64748b;font-size:12px;text-transform:uppercase;padding:12px;text-align:left}
.dt td{padding:11px 12px;border-bottom:1px solid #edf1f6}
.nm{font-weight:700;color:#17233c}
.sub{font-size:12px;color:#94a3b8;margin-top:3px}
.num{text-align:center;font-weight:700}
.avg{font-size:20px;color:#1769d2}
.bio{display:grid;grid-template-columns:1fr 1fr;gap:15px}
.bio-box{background:#f7f9fc;border-radius:14px;padding:16px}
.bio-box h2{margin:0 0 12px}
.bio-row{display:flex;justify-content:space-between;gap:15px;padding:7px 0;border-bottom:1px solid #e7edf4;font-size:13px}
.bio-row:last-child{border-bottom:0}
.empty{text-align:center;padding:50px;color:#94a3b8}
@media(max-width:900px){.filters,.bio{grid-template-columns:1fr}}
@media print{
 @page{size:A4 portrait;margin:12mm}
 .sidebar,.no-print,.head,.filter-card{display:none!important}
 .main-content{margin:0!important;padding:0!important}
 .card{box-shadow:none!important;padding:0!important;border-radius:0!important}
}
</style>

<main class="main-content">
<div class="lp">

<div class="head">
<h1>Laporan Nilai / Rapor</h1>
<p>Rekap nilai siswa SDN Ciburayut 01.</p>
</div>

<div class="card filter-card no-print">
<form method="get">
<div class="filters">

<div>
<label>Tahun Ajaran / Semester</label>
<select class="fc" name="id_tahun_ajaran">
<?php foreach($tahun as $t): ?>
<option value="<?=$t['id_tahun_ajaran']?>" <?=$id_tahun===(int)$t['id_tahun_ajaran']?'selected':''?>>
<?=h($t['tahun_ajaran'])?> - <?=h($t['semester'])?>
</option>
<?php endforeach;?>
</select>
</div>

<div>
<label>Kelas</label>
<select class="fc" name="id_kelas">
<option value="0">Semua Kelas</option>
<?php foreach($kelas as $k): ?>
<option value="<?=$k['id_kelas']?>" <?=$id_kelas===(int)$k['id_kelas']?'selected':''?>>
Kelas <?=h($k['nama_kelas'])?>
</option>
<?php endforeach;?>
</select>
</div>

<div>
<label>Siswa</label>
<select class="fc" name="id_siswa">
<option value="0">Semua Siswa</option>
<?php foreach($siswa as $s): ?>
<option value="<?=$s['id_siswa']?>" <?=$id_siswa===(int)$s['id_siswa']?'selected':''?>>
<?=h($s['nama_siswa'])?><?=($s['nama_kelas']?' - '.h($s['nama_kelas']):'')?>
</option>
<?php endforeach;?>
</select>
</div>

</div>

<div style="margin-top:15px;display:flex;gap:8px">
<button class="btn pri">🔎 Tampilkan</button>
<a class="btn sec" href="index.php">Reset</a>
</div>
</form>
</div>

<?php if($id_siswa>0 && $selected): ?>

<div class="card">

<div class="bio">
<div class="bio-box">
<h2><?=h($selected['nama_siswa'])?></h2>

<div class="bio-row">
<span>NIS</span>
<strong><?=h($selected['nis']?:'-')?></strong>
</div>

<div class="bio-row">
<span>NISN</span>
<strong><?=h($selected['nisn']?:'-')?></strong>
</div>

<div class="bio-row">
<span>Kelas</span>
<strong><?=h($selected['nama_kelas']?:'-')?></strong>
</div>
</div>

<div class="bio-box">
<h2>Ringkasan Nilai</h2>

<div class="bio-row">
<span>Semester</span>
<strong><?=h($periode['semester']??'-')?></strong>
</div>

<div class="bio-row">
<span>Jumlah Mata Pelajaran</span>
<strong><?=$selected['jumlah']?></strong>
</div>

<div class="bio-row">
<span>Rata-rata</span>
<strong class="avg"><?=number_format($selected['rata'],2)?></strong>
</div>
</div>
</div>

</div>

<div class="card">

<h2 style="margin-top:0">Daftar Nilai</h2>

<?php if($selected['nilai']): ?>
<div class="tw">
<table class="dt">
<thead>
<tr>
<th>No</th>
<th>Mata Pelajaran</th>
<th>Tugas</th>
<th>UTS</th>
<th>UAS</th>
<th>Nilai Akhir</th>
</tr>
</thead>
<tbody>
<?php $no=1;foreach($selected['nilai'] as $n): ?>
<tr>
<td><?=$no++?></td>
<td><div class="nm"><?=h($n['mapel'])?></div></td>
<td class="num"><?=number_format($n['tugas'],2)?></td>
<td class="num"><?=number_format($n['uts'],2)?></td>
<td class="num"><?=number_format($n['uas'],2)?></td>
<td class="num avg"><?=number_format($n['akhir'],2)?></td>
</tr>
<?php endforeach;?>
</tbody>
</table>
</div>
<?php else: ?>
<div class="empty">Belum ada data nilai untuk siswa ini.</div>
<?php endif; ?>

</div>

<div class="no-print" style="text-align:right">
<button class="btn pri" onclick="window.print()">🖨️ Cetak Rapor</button>
</div>

<?php elseif($data_siswa): ?>

<div class="card">
<h2 style="margin-top:0">📊 Rekap Nilai Siswa</h2>

<div class="tw">
<table class="dt">
<thead>
<tr>
<th>No</th>
<th>NIS/NISN</th>
<th>Nama Siswa</th>
<th>Kelas</th>
<th>Jumlah Mapel</th>
<th>Rata-rata</th>
<th>Aksi</th>
</tr>
</thead>
<tbody>
<?php $no=1;foreach($data_siswa as $d): ?>
<tr>
<td><?=$no++?></td>
<td><?=h($d['nis']?:'-')?><div class="sub">NISN: <?=h($d['nisn']?:'-')?></div></td>
<td><div class="nm"><?=h($d['nama_siswa'])?></div></td>
<td><?=h($d['nama_kelas']?:'-')?></td>
<td class="num"><?=$d['jumlah']?></td>
<td class="num avg"><?=number_format($d['rata'],2)?></td>
<td>
<a class="btn pri" href="?id_tahun_ajaran=<?=$id_tahun?>&id_kelas=<?=$id_kelas?>&id_siswa=<?=$d['id_siswa']?>">
📄 Rapor
</a>
</td>
</tr>
<?php endforeach;?>
</tbody>
</table>
</div>
</div>

<?php else: ?>

<div class="card">
<div class="empty">Belum ada data nilai pada periode/filter yang dipilih.</div>
</div>

<?php endif; ?>

</div>
</main>

</body>
</html>
