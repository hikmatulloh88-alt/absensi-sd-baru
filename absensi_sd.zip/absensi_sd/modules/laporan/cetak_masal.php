<?php
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator', 'Guru');

require_once "../../config/database.php";

$menu_aktif = 'laporan';
$page_title = 'Cetak Rapor Masal - SDN Ciburayut 01';

function h($v){
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

$id_tahun = (int)($_GET['id_tahun_ajaran'] ?? 0);
$id_kelas = (int)($_GET['id_kelas'] ?? 0);

/* Tahun ajaran */
$tahun = [];
$q = mysqli_query(
    $koneksi,
    "SELECT id_tahun_ajaran,tahun_ajaran,semester,aktif
     FROM tahun_ajaran
     ORDER BY aktif DESC,id_tahun_ajaran DESC"
);
if($q){
    while($r=mysqli_fetch_assoc($q)) $tahun[]=$r;
}
if(!$id_tahun && $tahun){
    $id_tahun=(int)$tahun[0]['id_tahun_ajaran'];
}

/* Kelas */
$kelas = [];
$q = mysqli_query(
    $koneksi,
    "SELECT id_kelas,nama_kelas,tingkat
     FROM kelas
     ORDER BY tingkat,nama_kelas"
);
if($q){
    while($r=mysqli_fetch_assoc($q)) $kelas[]=$r;
}

/* Periode */
$periode = null;
foreach($tahun as $t){
    if((int)$t['id_tahun_ajaran']===$id_tahun){
        $periode=$t;
        break;
    }
}

/* Siswa + nilai */
$rapor = [];

if($id_tahun > 0 && $id_kelas > 0){

    $qS = mysqli_query(
        $koneksi,
        "SELECT s.id_siswa,s.nis,s.nisn,s.nama_siswa,k.nama_kelas
         FROM siswa s
         LEFT JOIN kelas k ON k.id_kelas=s.id_kelas
         WHERE s.status_siswa='Aktif'
           AND s.id_kelas=".$id_kelas."
         ORDER BY s.nama_siswa"
    );

    if($qS){
        while($s=mysqli_fetch_assoc($qS)){
            $rapor[(int)$s['id_siswa']]=[
                'id_siswa'=>(int)$s['id_siswa'],
                'nis'=>$s['nis'],
                'nisn'=>$s['nisn'],
                'nama_siswa'=>$s['nama_siswa'],
                'nama_kelas'=>$s['nama_kelas'],
                'nilai'=>[],
                'total'=>0,
                'jumlah'=>0,
                'rata'=>0
            ];
        }
    }

    $qN = mysqli_query(
        $koneksi,
        "SELECT n.id_siswa,n.nilai_tugas,n.nilai_uts,n.nilai_uas,n.nilai_akhir,
                mp.nama_mapel
         FROM nilai n
         INNER JOIN mata_pelajaran mp ON mp.id_mapel=n.id_mapel
         WHERE n.id_tahun_ajaran=".$id_tahun."
           AND n.id_kelas=".$id_kelas."
         ORDER BY n.id_siswa,mp.nama_mapel"
    );

    if($qN){
        while($n=mysqli_fetch_assoc($qN)){
            $sid=(int)$n['id_siswa'];
            if(!isset($rapor[$sid])) continue;

            $akhir=(float)($n['nilai_akhir']??0);

            $rapor[$sid]['nilai'][]=[
                'mapel'=>$n['nama_mapel'],
                'tugas'=>(float)($n['nilai_tugas']??0),
                'uts'=>(float)($n['nilai_uts']??0),
                'uas'=>(float)($n['nilai_uas']??0),
                'akhir'=>$akhir
            ];
            $rapor[$sid]['total'] += $akhir;
            $rapor[$sid]['jumlah']++;
        }
    }

    foreach($rapor as &$r){
        $r['rata']=$r['jumlah'] ? round($r['total']/$r['jumlah'],2) : 0;
    }
    unset($r);
}

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>
<style>
.page{max-width:1450px}
.head{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}
.head h1{margin:0 0 6px}.head p{margin:0}
.card{background:#fff;border-radius:18px;box-shadow:0 8px 25px rgba(15,35,70,.07);padding:20px;margin-bottom:20px}
.filters{display:grid;grid-template-columns:1fr 1fr auto;gap:14px;align-items:end}
label{display:block;font-size:13px;font-weight:600;color:#334155;margin-bottom:7px}
.fc{width:100%;height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:0 11px;background:#fff}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;border:0;border-radius:10px;padding:11px 16px;font-weight:600;text-decoration:none;cursor:pointer}
.pri{background:linear-gradient(135deg,#2388f5,#1265dc);color:#fff}
.sec{background:#eef3f9;color:#334155}
.info{padding:14px 16px;border-radius:11px;background:#eef6ff;border:1px solid #d5e7fb;color:#245c9b;font-size:13px;line-height:1.5}
.rapor-sheet{background:#fff;border-radius:12px;margin-bottom:22px;padding:28px;box-shadow:0 5px 18px rgba(15,35,70,.06)}
.school-head{text-align:center;border-bottom:2px solid #17233c;padding-bottom:12px;margin-bottom:16px}
.school-head h2{margin:0;font-size:22px}.school-head p{margin:4px 0 0;color:#64748b}
.identity{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:18px}
.identity-box{background:#f7f9fc;border-radius:10px;padding:12px 14px}
.identity-row{display:flex;justify-content:space-between;padding:5px 0;font-size:13px;border-bottom:1px solid #e7edf4}
.identity-row:last-child{border-bottom:0}
.table{width:100%;border-collapse:collapse}
.table th{background:#f7f9fc;color:#475569;padding:9px;font-size:12px;border:1px solid #e3eaf2}
.table td{padding:8px 9px;border:1px solid #e3eaf2;font-size:12px}
.center{text-align:center}.avg{font-weight:800}
.empty{text-align:center;color:#94a3b8;padding:45px}
@media(max-width:800px){.filters,.identity{grid-template-columns:1fr}}
@media print{
 @page{size:A4 portrait;margin:10mm}
 body{background:#fff!important}
 .sidebar,.no-print,.head{display:none!important}
 .main-content{margin:0!important;padding:0!important}
 .page{max-width:none!important}
 .card{box-shadow:none!important;padding:0!important;margin:0!important;border-radius:0!important}
 .rapor-sheet{box-shadow:none!important;border-radius:0!important;padding:0!important;margin:0 0 8mm!important;break-after:page}
 .rapor-sheet:last-child{break-after:auto}
}
</style>

<main class="main-content">
<div class="page">

<div class="head">
<div>
<h1>Cetak Rapor Masal</h1>
<p>Cetak seluruh rapor siswa dalam satu kelas sekaligus.</p>
</div>
<button class="btn pri no-print" onclick="window.print()">🖨️ Cetak Semua Rapor</button>
</div>

<div class="card no-print">
<form method="get">
<div class="filters">

<div>
<label>Tahun Ajaran / Semester</label>
<select class="fc" name="id_tahun_ajaran">
<?php foreach($tahun as $t): ?>
<option value="<?=$t['id_tahun_ajaran']?>" <?=$id_tahun===(int)$t['id_tahun_ajaran']?'selected':''?>>
<?=h($t['tahun_ajaran'])?> - <?=h($t['semester'])?>
</option>
<?php endforeach;?>
</select>
</div>

<div>
<label>Kelas</label>
<select class="fc" name="id_kelas">
<option value="0">Pilih Kelas</option>
<?php foreach($kelas as $k): ?>
<option value="<?=$k['id_kelas']?>" <?=$id_kelas===(int)$k['id_kelas']?'selected':''?>>
Kelas <?=h($k['nama_kelas'])?>
</option>
<?php endforeach;?>
</select>
</div>

<div>
<button class="btn pri" style="width:100%">🔎 Tampilkan</button>
</div>

</div>
</form>
</div>

<?php if($id_kelas<=0): ?>

<div class="card"><div class="info">Pilih <strong>kelas</strong> terlebih dahulu untuk menampilkan rapor masal.</div></div>

<?php elseif(!$rapor): ?>

<div class="card"><div class="empty">Belum ada siswa pada kelas yang dipilih.</div></div>

<?php else: ?>

<div class="card no-print">
<div class="info">
Ditemukan <strong><?=count($rapor)?> siswa</strong> pada kelas
<strong><?=h($rapor[array_key_first($rapor)]['nama_kelas']??'-')?></strong>.
Setiap siswa akan dicetak pada <strong>satu halaman A4</strong>.
</div>
</div>

<div class="card">

<?php foreach($rapor as $r): ?>

<div class="rapor-sheet">

<div class="school-head">
<h2>SDN CIBURAYUT 01</h2>
<p>LAPORAN HASIL BELAJAR SISWA</p>
</div>

<div class="identity">

<div class="identity-box">
<div class="identity-row"><span>Nama Siswa</span><strong><?=h($r['nama_siswa'])?></strong></div>
<div class="identity-row"><span>NIS</span><strong><?=h($r['nis']?:'-')?></strong></div>
<div class="identity-row"><span>NISN</span><strong><?=h($r['nisn']?:'-')?></strong></div>
<div class="identity-row"><span>Kelas</span><strong><?=h($r['nama_kelas']?:'-')?></strong></div>
</div>

<div class="identity-box">
<div class="identity-row"><span>Tahun Ajaran</span><strong><?=h($periode['tahun_ajaran']??'-')?></strong></div>
<div class="identity-row"><span>Semester</span><strong><?=h($periode['semester']??'-')?></strong></div>
<div class="identity-row"><span>Jumlah Mapel</span><strong><?=$r['jumlah']?></strong></div>
<div class="identity-row"><span>Rata-rata</span><strong><?=number_format($r['rata'],2)?></strong></div>
</div>

</div>

<?php if($r['nilai']): ?>

<table class="table">
<thead>
<tr>
<th style="width:45px">No</th>
<th>Mata Pelajaran</th>
<th>Tugas</th>
<th>UTS</th>
<th>UAS</th>
<th>Nilai Akhir</th>
</tr>
</thead>
<tbody>

<?php $no=1; foreach($r['nilai'] as $n): ?>
<tr>
<td class="center"><?=$no++?></td>
<td><?=h($n['mapel'])?></td>
<td class="center"><?=number_format($n['tugas'],2)?></td>
<td class="center"><?=number_format($n['uts'],2)?></td>
<td class="center"><?=number_format($n['uas'],2)?></td>
<td class="center avg"><?=number_format($n['akhir'],2)?></td>
</tr>
<?php endforeach; ?>

</tbody>
</table>

<?php else: ?>
<div class="empty">Belum ada data nilai.</div>
<?php endif; ?>

<div style="margin-top:38px;display:flex;justify-content:space-between;font-size:12px">
<div></div>
<div style="text-align:center">
Bogor, ____________________<br>
Wali Kelas<br><br><br>
<strong>____________________________</strong>
</div>
</div>

</div>

<?php endforeach; ?>

</div>

<?php endif; ?>

</div>
</main>

</body>
</html>
