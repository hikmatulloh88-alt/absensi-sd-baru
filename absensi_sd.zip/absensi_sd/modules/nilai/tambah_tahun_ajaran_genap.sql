-- Tambahkan periode Tahun Ajaran Genap
-- Database: absensi_sd
INSERT INTO tahun_ajaran (tahun_ajaran, semester, aktif)
SELECT '2026/2027', 'Genap', 0
WHERE NOT EXISTS (
    SELECT 1
    FROM tahun_ajaran
    WHERE tahun_ajaran = '2026/2027'
      AND semester = 'Genap'
);
