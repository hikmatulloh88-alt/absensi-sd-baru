<?php
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator', 'Guru');

require_once "../../config/database.php";

$menu_aktif = 'upload_nilai';
$page_title = 'Upload Nilai Excel - SDN Ciburayut 01';

function h($v){
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

/* Mata pelajaran resmi untuk tabel PRESTASI BELAJAR Buku Induk. */
$mapel_buku_induk = [
    'PPKN',
    'Pendidikan Agama',
    'Bahasa Indonesia',
    'Matematika',
    'Ilmu Pengetahuan Alam',
    'Ilmu Pengetahuan Sosial',
    'Seni Budaya',
    'Penjaskes',
    'Bahasa Inggris',
    'B. Daerah'
];

function ensure_book_induk_subjects($db, $subjects){
    $map = [];
    foreach($subjects as $nama){
        $st=mysqli_prepare($db, "SELECT id_mapel FROM mata_pelajaran WHERE nama_mapel=? LIMIT 1");
        if(!$st) continue;
        mysqli_stmt_bind_param($st,'s',$nama);
        mysqli_stmt_execute($st);
        $rr=mysqli_stmt_get_result($st);
        $r=$rr?mysqli_fetch_assoc($rr):null;
        if(!$r){
            $kode='';
            $codes=['PPKN'=>'PPKN','Pendidikan Agama'=>'AGAMA','Bahasa Indonesia'=>'BIN','Matematika'=>'MTK','Ilmu Pengetahuan Alam'=>'IPA','Ilmu Pengetahuan Sosial'=>'IPS','Seni Budaya'=>'SB','Penjaskes'=>'PJOK','Bahasa Inggris'=>'BING','B. Daerah'=>'BDA'];
            $kode=$codes[$nama]??'';
            $ins=mysqli_prepare($db,"INSERT INTO mata_pelajaran(kode_mapel,nama_mapel,kelompok,status) VALUES(?,?,?,'Aktif')");
            if($ins){$kel=$nama==='B. Daerah'?'MUATAN LOKAL':'UMUM'; mysqli_stmt_bind_param($ins,'sss',$kode,$nama,$kel); mysqli_stmt_execute($ins); $id=(int)mysqli_insert_id($db);}
            else $id=0;
        } else $id=(int)$r['id_mapel'];
        if($id>0) $map[$nama]=$id;
    }
    return $map;
}

$mapel_buku_induk_ids = ensure_book_induk_subjects($koneksi, $mapel_buku_induk);

/* Pastikan kolom nilai tersedia */
function ensure_value_columns($db){
    $wanted = [
        'nilai_tugas'=>'DECIMAL(5,2) NULL',
        'nilai_uts'=>'DECIMAL(5,2) NULL',
        'nilai_uas'=>'DECIMAL(5,2) NULL',
        'nilai_akhir'=>'DECIMAL(5,2) NULL'
    ];

    $q=mysqli_query($db,"SHOW COLUMNS FROM nilai");
    if(!$q) return false;

    $cols=[];
    while($r=mysqli_fetch_assoc($q)) $cols[]=$r['Field'];

    foreach($wanted as $f=>$def){
        if(!in_array($f,$cols,true)){
            if(!mysqli_query($db,"ALTER TABLE nilai ADD COLUMN `$f` $def")) return false;
        }
    }
    return true;
}

function col_index_to_name($i){
    $name='';
    while($i>0){
        $r=($i-1)%26;
        $name=chr(65+$r).$name;
        $i=intdiv($i-1,26);
    }
    return $name;
}

/* Buat XLSX sederhana tanpa library pihak ketiga */
function create_xlsx($headers,$rows,$filename){

    if(!class_exists('ZipArchive')){
        die('ZipArchive PHP belum aktif.');
    }

    $tmp = tempnam(sys_get_temp_dir(), 'xlsx_');
    $zip = new ZipArchive();

    if($zip->open($tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE)!==true){
        die('Gagal membuat file Excel.');
    }

    $contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
</Types>';

    $rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>';

    $workbookRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
</Relationships>';

    $workbook = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets><sheet name="Template Nilai" sheetId="1" r:id="rId1"/></sheets>
</workbook>';

    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<sheetData>';

    $rowNum=1;
    foreach(array_merge([$headers],$rows) as $rowData){
        $xml.='<row r="'.$rowNum.'">';
        $col=1;
        foreach($rowData as $value){
            $ref=col_index_to_name($col).$rowNum;
            $value=(string)$value;
            $xml.='<c r="'.$ref.'" t="inlineStr"><is><t xml:space="preserve">'.htmlspecialchars($value,ENT_XML1,'UTF-8').'</t></is></c>';
            $col++;
        }
        $xml.='</row>';
        $rowNum++;
    }

    $xml.='</sheetData></worksheet>';

    $zip->addFromString('[Content_Types].xml',$contentTypes);
    $zip->addFromString('_rels/.rels',$rels);
    $zip->addFromString('xl/workbook.xml',$workbook);
    $zip->addFromString('xl/_rels/workbook.xml.rels',$workbookRels);
    $zip->addFromString('xl/worksheets/sheet1.xml',$xml);
    $zip->close();

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="'.$filename.'"');
    header('Content-Length: '.filesize($tmp));
    readfile($tmp);
    unlink($tmp);
    exit;
}

/* Baca XLSX */
function xlsx_read_rows($file){

    if(!class_exists('ZipArchive')){
        return ['ok'=>false,'error'=>'ZipArchive PHP belum aktif.'];
    }

    $zip=new ZipArchive();
    if($zip->open($file)!==true){
        return ['ok'=>false,'error'=>'File Excel tidak dapat dibuka.'];
    }

    /* Ambil sharedStrings jika workbook Excel menggunakannya */
    $shared = [];
    $shared_xml = $zip->getFromName('xl/sharedStrings.xml');

    if($shared_xml !== false){
        $ss = @simplexml_load_string($shared_xml);

        if($ss){
            foreach($ss->si as $si){
                $txt='';

                if(isset($si->t)){
                    $txt=(string)$si->t;
                }else{
                    foreach($si->r as $run){
                        $txt .= (string)$run->t;
                    }
                }

                $shared[]=$txt;
            }
        }
    }

    $sheet=$zip->getFromName('xl/worksheets/sheet1.xml');
    if($sheet===false){
        $zip->close();
        return ['ok'=>false,'error'=>'Sheet pertama Excel tidak ditemukan.'];
    }

    $sx=@simplexml_load_string($sheet);
    if(!$sx){
        $zip->close();
        return ['ok'=>false,'error'=>'Isi Excel tidak dapat dibaca.'];
    }

    $rows=[];

    foreach($sx->sheetData->row as $rowNode){
        $row=[];

        foreach($rowNode->c as $cell){

            $ref=(string)$cell['r'];
            $type=(string)$cell['t'];
            $val='';

            if($type==='s' && isset($cell->v)){
                $si=(int)$cell->v;
                $val=$shared[$si]??'';
            }elseif($type==='inlineStr'){
                if(isset($cell->is->t)){
                    $val=(string)$cell->is->t;
                }else{
                    foreach($cell->is->r as $run){
                        $val .= (string)$run->t;
                    }
                }
            }elseif(isset($cell->v)){
                $val=(string)$cell->v;
            }

            preg_match('/^[A-Z]+/',$ref,$m);
            $letters=$m[0]??'';
            $idx=0;

            for($i=0;$i<strlen($letters);$i++){
                $idx=$idx*26+(ord($letters[$i])-64);
            }

            if($idx>0){
                $row[$idx]=$val;
            }
        }

        if($row){
            ksort($row);
            $max=max(array_keys($row));
            $dense=[];

            for($i=1;$i<=$max;$i++){
                $dense[]=$row[$i]??'';
            }

            $rows[]=$dense;
        }
    }

    $zip->close();

    return ['ok'=>true,'rows'=>$rows];
}

function norm_name($s){
    $s=trim((string)$s);
    $s=mb_strtolower($s,'UTF-8');
    $s=preg_replace('/[^a-z0-9]+/iu','',$s);
    return $s;
}

function find_student($db,$id_siswa,$nisn,$nama){

    if($id_siswa>0){
        $st=mysqli_prepare($db,"SELECT id_siswa,id_kelas,nama_siswa,nisn FROM siswa WHERE id_siswa=? LIMIT 1");
        if($st){
            mysqli_stmt_bind_param($st,'i',$id_siswa);
            mysqli_stmt_execute($st);
            $rr=mysqli_stmt_get_result($st);
            $r=$rr?mysqli_fetch_assoc($rr):null;
            if($r) return $r;
        }
    }

    $nisn=preg_replace('/[^0-9]/','',(string)$nisn);

    if($nisn!==''){
        $st=mysqli_prepare($db,"SELECT id_siswa,id_kelas,nama_siswa,nisn FROM siswa WHERE nisn=? LIMIT 1");
        if($st){
            mysqli_stmt_bind_param($st,'s',$nisn);
            mysqli_stmt_execute($st);
            $rr=mysqli_stmt_get_result($st);
            $r=$rr?mysqli_fetch_assoc($rr):null;
            if($r) return $r;
        }
    }

    $target=norm_name($nama);
    if($target==='') return null;

    $q=mysqli_query($db,"SELECT id_siswa,id_kelas,nama_siswa,nisn FROM siswa WHERE status_siswa='Aktif'");
    if(!$q) return null;

    $best=null;
    $bestScore=0;

    while($r=mysqli_fetch_assoc($q)){
        $cand=norm_name($r['nama_siswa']);
        if($cand===$target) return $r;

        if(strlen($target)>=4 && strlen($cand)>=4){
            similar_text($target,$cand,$pct);
            if($pct>$bestScore){
                $bestScore=$pct;
                $best=$r;
            }
        }
    }

    return $bestScore>=75 ? $best : null;
}

$migrasi_ok=ensure_value_columns($koneksi);

$pesan=''; $tipe=''; $hasil=[];

/* =========================
   DOWNLOAD TEMPLATE EXCEL
========================= */
if(isset($_GET['download_template']) && $_GET['download_template']==='1'){

    $id_tahun=(int)($_GET['id_tahun_ajaran']??0);
    $format=$_GET['format']??'';

    if($id_tahun>0){
        $qT=mysqli_query($koneksi,
            "SELECT tahun_ajaran,semester FROM tahun_ajaran WHERE id_tahun_ajaran=$id_tahun LIMIT 1"
        );
    }else{
        $qT=mysqli_query($koneksi,
            "SELECT tahun_ajaran,semester FROM tahun_ajaran ORDER BY aktif DESC,id_tahun_ajaran DESC LIMIT 1"
        );
    }
    $t=$qT?mysqli_fetch_assoc($qT):null;
    $tahunText=$t['tahun_ajaran']??'2026/2027';
    $semesterText=$t['semester']??'Gasal';

    $siswa=[];
    $qS=mysqli_query($koneksi,
        "SELECT id_siswa,nisn,nama_siswa,k.nama_kelas
         FROM siswa s LEFT JOIN kelas k ON k.id_kelas=s.id_kelas
         WHERE s.status_siswa='Aktif'
         ORDER BY k.tingkat,k.nama_kelas,s.nama_siswa"
    );
    if($qS) while($r=mysqli_fetch_assoc($qS)) $siswa[]=$r;

    /* Format utama mengikuti tabel PRESTASI BELAJAR: satu baris per siswa,
       10 kolom mapel persis seperti PDF Buku Induk. */
    $headers=[
        'ID SISWA','NISN','NAMA SISWA','KELAS','TAHUN AJARAN','SEMESTER',
        'PPKN','Pendidikan Agama','Bahasa Indonesia','Matematika',
        'Ilmu Pengetahuan Alam','Ilmu Pengetahuan Sosial','Seni Budaya',
        'Penjaskes','Bahasa Inggris','B. Daerah'
    ];

    $rows=[];
    foreach($siswa as $st){
        $rows[]=[
            $st['id_siswa'], $st['nisn']?:'', $st['nama_siswa'], $st['nama_kelas']?:'',
            $tahunText, $semesterText, '', '', '', '', '', '', '', '', '', ''
        ];
    }

    create_xlsx($headers,$rows,
        'Template_Nilai_Buku_Induk_SDN_Ciburayut_01_'.strtolower($semesterText).'.xlsx');
}

/* =========================
   UPLOAD EXCEL
========================= */
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_FILES['file_excel']) && $migrasi_ok){

    $file=$_FILES['file_excel'];

    if($file['error']!==UPLOAD_ERR_OK){
        $pesan='File Excel gagal diunggah.';
        $tipe='error';
    }else{

        $ext=strtolower(pathinfo($file['name'],PATHINFO_EXTENSION));

        if($ext!=='xlsx'){
            $pesan='Gunakan file Excel .xlsx.';
            $tipe='error';
        }else{

            $read=xlsx_read_rows($file['tmp_name']);

            if(!$read['ok']){
                $pesan=$read['error'];
                $tipe='error';
            }else{

                $rows=$read['rows'];

                if(count($rows)<2){
                    $pesan='File Excel belum berisi data.';
                    $tipe='error';
                }else{

                    $headers=[];
                    foreach($rows[0] as $v){
                        $v=strtoupper(trim((string)$v));
                        $v=preg_replace('/\s+/','_',$v);
                        $headers[]=$v;
                    }

                    $aliases=[
                        'ID_SISWA'=>['ID_SISWA','IDSISWA'],
                        'NISN'=>['NISN'],
                        'NAMA_SISWA'=>['NAMA_SISWA','NAMA'],
                        'NAMA_MAPEL'=>['NAMA_MAPEL','MAPEL'],
                        'TAHUN_AJARAN'=>['TAHUN_AJARAN','TAHUN'],
                        'SEMESTER'=>['SEMESTER'],
                        'NILAI_TUGAS'=>['NILAI_TUGAS','TUGAS'],
                        'NILAI_UTS'=>['NILAI_UTS','UTS'],
                        'NILAI_UAS'=>['NILAI_UAS','UAS']
                    ];

                    $idx=[];
                    foreach($aliases as $canonical=>$alts){
                        foreach($alts as $alt){
                            if(in_array($alt,$headers,true)){ $idx[$canonical]=array_search($alt,$headers,true); break; }
                        }
                    }

                    /* Mode baru: template lebar yang persis mengikuti 10 mapel Buku Induk. */
                    $wide=[];
                    foreach($mapel_buku_induk as $sub){
                        $norm=strtoupper(trim($sub)); $norm=preg_replace('/\s+/','_',$norm);
                        if(in_array($norm,$headers,true)) $wide[$sub]=array_search($norm,$headers,true);
                    }
                    $wide_mode = count($wide) >= 8;

                    $required_common=['NAMA_SISWA','TAHUN_AJARAN','SEMESTER'];
                    foreach($required_common as $req){ if(!array_key_exists($req,$idx)){ $idx=null; break; } }

                    if($idx===null){
                        $pesan='Kolom identitas Excel belum sesuai. Gunakan tombol Download Template Nilai Buku Induk.';
                        $tipe='error';
                    }else{
                        $sukses=0; $gagal=0; $rowNo=1;

                        /* helper penyimpanan satu nilai */
                        $save_nilai = function($nama,$nisn,$id_siswa,$nama_mapel,$tahun,$semester,$tugas,$uts,$uas) use ($koneksi,&$hasil,&$sukses,&$gagal,&$rowNo){
                            $siswa=find_student($koneksi,(int)$id_siswa,$nisn,$nama);
                            if(!$siswa){ $hasil[]='Baris '.$rowNo.': siswa tidak ditemukan — '.$nama.'.'; $gagal++; return; }
                            $real_id=(int)$siswa['id_siswa']; $id_kelas=(int)$siswa['id_kelas'];
                            if($id_kelas<=0){ $hasil[]='Baris '.$rowNo.': siswa belum memiliki kelas — '.$nama.'.'; $gagal++; return; }

                            $st=mysqli_prepare($koneksi,"SELECT id_mapel FROM mata_pelajaran WHERE nama_mapel=? AND status='Aktif' LIMIT 1");
                            if(!$st){$hasil[]='Baris '.$rowNo.': gagal membaca mapel — '.$nama_mapel.'.';$gagal++;return;}
                            mysqli_stmt_bind_param($st,'s',$nama_mapel); mysqli_stmt_execute($st); $rr=mysqli_stmt_get_result($st); $m=$rr?mysqli_fetch_assoc($rr):null; $id_mapel=(int)($m['id_mapel']??0);
                            if($id_mapel<=0){ $hasil[]='Baris '.$rowNo.': mapel tidak ditemukan — '.$nama_mapel.'.'; $gagal++; return; }

                            $st=mysqli_prepare($koneksi,"SELECT id_tahun_ajaran FROM tahun_ajaran WHERE tahun_ajaran=? AND semester=? LIMIT 1");
                            mysqli_stmt_bind_param($st,'ss',$tahun,$semester); mysqli_stmt_execute($st); $rr=mysqli_stmt_get_result($st); $tr=$rr?mysqli_fetch_assoc($rr):null; $id_tahun=(int)($tr['id_tahun_ajaran']??0);
                            if($id_tahun<=0){ $hasil[]='Baris '.$rowNo.': periode tidak ditemukan — '.$tahun.' - '.$semester.'.'; $gagal++; return; }

                            $tugas=max(0,min(100,(float)str_replace(',','.',trim((string)$tugas))));
                            $uts=max(0,min(100,(float)str_replace(',','.',trim((string)$uts))));
                            $uas=max(0,min(100,(float)str_replace(',','.',trim((string)$uas))));
                            $akhir=round(($tugas*.30)+($uts*.30)+($uas*.40),2);

                            $st=mysqli_prepare($koneksi,"SELECT id_nilai FROM nilai WHERE id_siswa=? AND id_mapel=? AND id_tahun_ajaran=? LIMIT 1");
                            mysqli_stmt_bind_param($st,'iii',$real_id,$id_mapel,$id_tahun); mysqli_stmt_execute($st); $rr=mysqli_stmt_get_result($st); $existing=$rr?mysqli_fetch_assoc($rr):null;
                            if($existing){
                                $st=mysqli_prepare($koneksi,"UPDATE nilai SET id_kelas=?,nilai_tugas=?,nilai_uts=?,nilai_uas=?,nilai_akhir=? WHERE id_nilai=?");
                                mysqli_stmt_bind_param($st,'issssi',$id_kelas,$tugas,$uts,$uas,$akhir,$existing['id_nilai']);
                            }else{
                                $st=mysqli_prepare($koneksi,"INSERT INTO nilai(id_siswa,id_kelas,id_mapel,id_tahun_ajaran,nilai_tugas,nilai_uts,nilai_uas,nilai_akhir) VALUES(?,?,?,?,?,?,?,?)");
                                mysqli_stmt_bind_param($st,'iiiissss',$real_id,$id_kelas,$id_mapel,$id_tahun,$tugas,$uts,$uas,$akhir);
                            }
                            if(mysqli_stmt_execute($st)){ $hasil[]='Baris '.$rowNo.': '.($existing?'diperbarui':'berhasil').' — '.$nama.' / '.$nama_mapel.'.'; $sukses++; }
                            else { $hasil[]='Baris '.$rowNo.': gagal simpan — '.$nama.' / '.$nama_mapel.'.'; $gagal++; }
                        };

                        for($i=1;$i<count($rows);$i++){
                            $rowNo++; $row=$rows[$i]; $kosong=true; foreach($row as $cell){if(trim((string)$cell)!==''){$kosong=false;break;}} if($kosong) continue;
                            $id_siswa=(int)($idx['ID_SISWA']!==null?($row[$idx['ID_SISWA']]??0):0);
                            $nisn=''; if(isset($idx['NISN'])) $nisn=trim((string)($row[$idx['NISN']]??''));
                            $nama=trim((string)($row[$idx['NAMA_SISWA']]??''));
                            $tahun=trim((string)($row[$idx['TAHUN_AJARAN']]??'')); $semester=trim((string)($row[$idx['SEMESTER']]??''));
                            if($nama===''||$tahun===''||$semester===''){ $hasil[]='Baris '.$rowNo.': identitas wajib belum lengkap.'; $gagal++; continue; }

                            if($wide_mode){
                                $adaNilai=false;
                                foreach($wide as $sub=>$col){
                                    $raw=trim((string)($row[$col]??''));
                                    if($raw==='') continue; $adaNilai=true;
                                    /* Pada template Buku Induk cukup satu nilai akhir; aplikasi mengisinya sebagai Nilai Akhir. */
                                    $save_nilai($nama,$nisn,$id_siswa,$sub,$tahun,$semester,$raw,$raw,$raw);
                                }
                                if(!$adaNilai){ $hasil[]='Baris '.$rowNo.': belum ada nilai untuk '.$nama.'.'; $gagal++; }
                            }else{
                                foreach(['NAMA_MAPEL','NILAI_TUGAS','NILAI_UTS','NILAI_UAS'] as $req){ if(!array_key_exists($req,$idx)){ $hasil[]='Baris '.$rowNo.': kolom '.$req.' tidak ditemukan.'; $gagal++; continue 2; } }
                                $nama_mapel=trim((string)($row[$idx['NAMA_MAPEL']]??''));
                                $save_nilai($nama,$nisn,$id_siswa,$nama_mapel,$tahun,$semester,$row[$idx['NILAI_TUGAS']]??0,$row[$idx['NILAI_UTS']]??0,$row[$idx['NILAI_UAS']]??0);
                            }
                        }

                        $pesan="Upload Excel selesai. Berhasil: $sukses, gagal: $gagal.";
                        $tipe=$sukses>0?'success':'error';
                    }
                }
            }
        }
    }
}

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>

<style>
.up{max-width:1180px}
.ph h1{margin:0 0 6px}.ph p{margin:0 0 24px}
.card{background:#fff;border-radius:18px;box-shadow:0 8px 25px rgba(15,35,70,.07);padding:24px;margin-bottom:20px}
.info{padding:14px 16px;border-radius:11px;background:#eef6ff;border:1px solid #d5e7fb;color:#245c9b;font-size:13px;line-height:1.6}
.alert{padding:13px 15px;border-radius:11px;margin-bottom:18px;font-size:14px}
.ok{background:#ecfdf3;color:#18794e;border:1px solid #ccefdc}
.er{background:#fff1f2;color:#be123c;border:1px solid #fecdd3}
.file{width:100%;padding:14px;border:1px dashed #b8cbe2;border-radius:12px;background:#f8fbff}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;border:0;border-radius:10px;padding:11px 16px;font-weight:600;text-decoration:none;cursor:pointer}
.pri{background:linear-gradient(135deg,#2388f5,#1265dc);color:#fff}
.sec{background:#eef3f9;color:#334155}
.code{display:block;background:#f7f9fc;border-radius:10px;padding:12px;margin:10px 0;font:12px Consolas,monospace;overflow:auto}
.result{max-height:380px;overflow:auto;border:1px solid #e8eef6;border-radius:12px}
.result div{padding:9px 12px;border-bottom:1px solid #eef2f6;font-size:13px}
</style>

<main class="main-content">
<div class="up">

<div class="ph">
<h1>Upload Nilai Pelajaran</h1>
<p>Upload nilai massal langsung dari Excel (.xlsx).</p>
</div>

<?php if($pesan): ?>
<div class="alert <?=$tipe==='success'?'ok':'er'?>"><?=h($pesan)?></div>
<?php endif; ?>

<div class="card">
<div class="info">
✅ Template ini mengikuti tabel <strong>PRESTASI BELAJAR</strong> pada Buku Induk yang bosku upload.<br>
✅ Tepat <strong>10 mata pelajaran</strong>: PPKN, Pendidikan Agama, Bahasa Indonesia, Matematika, Ilmu Pengetahuan Alam, Ilmu Pengetahuan Sosial, Seni Budaya, Penjaskes, Bahasa Inggris, B. Daerah.<br>
✅ Satu baris = satu siswa untuk satu <strong>Tahun Ajaran/Semester</strong>.<br>
✅ Guru cukup mengisi nilai pada kolom 10 mata pelajaran.
</div>

<h2>1. Download Template Buku Induk</h2>
<form method="get">
<input type="hidden" name="download_template" value="1">
<input type="hidden" name="format" value="buku_induk">
<label>Tahun Ajaran / Semester</label>
<select class="file" name="id_tahun_ajaran">
<?php
$q=mysqli_query($koneksi,"SELECT id_tahun_ajaran,tahun_ajaran,semester,aktif FROM tahun_ajaran ORDER BY aktif DESC,id_tahun_ajaran DESC");
while($t=mysqli_fetch_assoc($q)):
?>
<option value="<?=$t['id_tahun_ajaran']?>" <?=$t['aktif']?'selected':''?>><?=h($t['tahun_ajaran'])?> - <?=h($t['semester'])?></option>
<?php endwhile; ?>
</select>
<div style="margin-top:16px"><button class="btn pri" type="submit">⬇️ Download Template Nilai Buku Induk</button></div>
</form>
</div>

<div class="card">
<h2 style="margin-top:0">2. Format Excel</h2>
<span class="code">ID SISWA | NISN | NAMA SISWA | KELAS | TAHUN AJARAN | SEMESTER | PPKN | Pendidikan Agama | Bahasa Indonesia | Matematika | Ilmu Pengetahuan Alam | Ilmu Pengetahuan Sosial | Seni Budaya | Penjaskes | Bahasa Inggris | B. Daerah</span>
<div class="info">
<strong>Jangan ubah 6 kolom identitas.</strong> Isi nilai 0–100 pada 10 kolom mata pelajaran. Nilai tersebut disimpan sebagai <strong>Nilai Akhir</strong> untuk tabel Prestasi Belajar. Template 10 mapel ini dibuat agar langsung cocok dengan Buku Induk.
</div>
</div>

<div class="card">
<h2 style="margin-top:0">3. Upload Excel</h2>

<form method="post" enctype="multipart/form-data">
<label>File Excel (.xlsx)</label>
<input class="file" type="file" name="file_excel" accept=".xlsx" required>

<div style="margin-top:16px;display:flex;gap:8px">
<button class="btn pri">⬆️ Upload & Proses Excel</button>
<a class="btn sec" href="index.php">Kembali ke Nilai</a>
</div>
</form>
</div>

<?php if($hasil): ?>
<div class="card">
<h2 style="margin-top:0">Hasil Proses</h2>
<div class="result">
<?php foreach($hasil as $line): ?>
<div><?=h($line)?></div>
<?php endforeach; ?>
</div>
</div>
<?php endif; ?>

</div>
</main>

</body>
</html>
