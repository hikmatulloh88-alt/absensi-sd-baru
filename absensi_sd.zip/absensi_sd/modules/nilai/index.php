<?php
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator', 'Guru');
require_once "../../config/database.php";

$menu_aktif = 'nilai';
$page_title = 'Nilai Siswa - Absensi SDN Ciburayut 01';

function h($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

/*
 * Modul ini sengaja membaca struktur tabel nilai secara dinamis.
 * Dengan begitu halaman tidak mengunci nama kolom nilai yang belum
 * dipastikan di database yang sedang dipakai.
 */

$q_columns = mysqli_query($koneksi, "SHOW COLUMNS FROM nilai");
$columns = [];
if ($q_columns) {
    while ($col = mysqli_fetch_assoc($q_columns)) {
        $columns[] = $col;
    }
}

$column_names = array_column($columns, 'Field');

/* Relasi master yang sudah pasti ada */
$daftar_siswa = [];
$q = mysqli_query(
    $koneksi,
    "SELECT id_siswa, nama_siswa
     FROM siswa
     ORDER BY nama_siswa ASC"
);
if ($q) {
    while ($row = mysqli_fetch_assoc($q)) {
        $daftar_siswa[] = $row;
    }
}

$daftar_mapel = [];
$q = mysqli_query(
    $koneksi,
    "SELECT id_mapel, nama_mapel
     FROM mata_pelajaran
     WHERE status = 'Aktif'
     ORDER BY nama_mapel ASC"
);
if ($q) {
    while ($row = mysqli_fetch_assoc($q)) {
        $daftar_mapel[] = $row;
    }
}

$daftar_tahun = [];
$q = mysqli_query(
    $koneksi,
    "SELECT id_tahun_ajaran, tahun_ajaran, semester
     FROM tahun_ajaran
     ORDER BY aktif DESC, id_tahun_ajaran DESC"
);
if ($q) {
    while ($row = mysqli_fetch_assoc($q)) {
        $daftar_tahun[] = $row;
    }
}

/* Kelompok kolom nilai umum. Hanya ditampilkan bila kolomnya memang ada. */
$candidate_value_columns = [
    'nilai_tugas'   => 'Nilai Tugas',
    'nilai_uts'     => 'Nilai UTS',
    'nilai_uas'     => 'Nilai UAS',
    'nilai_akhir'   => 'Nilai Akhir',
    'nilai_harian'  => 'Nilai Harian',
    'nilai_rapor'   => 'Nilai Rapor'
];

$value_columns = [];
foreach ($candidate_value_columns as $field => $label) {
    if (in_array($field, $column_names, true)) {
        $value_columns[$field] = $label;
    }
}

$pesan = '';

/* Simpan hanya bila struktur nilai sudah punya kolom relasi yang dibutuhkan. */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'simpan') {
    $required_relations = ['id_nilai', 'id_siswa', 'id_kelas', 'id_mapel', 'id_tahun_ajaran'];

    $missing_relations = [];
    foreach ($required_relations as $field) {
        if (!in_array($field, $column_names, true)) {
            $missing_relations[] = $field;
        }
    }

    if ($missing_relations) {
        $pesan = 'Struktur tabel nilai belum sesuai modul. Kolom yang belum ditemukan: ' .
                 implode(', ', $missing_relations) . '.';
    } else {
        $id_siswa = (int)($_POST['id_siswa'] ?? 0);
        $id_mapel = (int)($_POST['id_mapel'] ?? 0);
        $id_tahun = (int)($_POST['id_tahun_ajaran'] ?? 0);

        /* kelas diambil dari siswa agar data selalu sinkron dengan master siswa */
        $id_kelas = 0;
        $stmt_kelas = mysqli_prepare(
            $koneksi,
            "SELECT id_kelas FROM siswa WHERE id_siswa = ?"
        );

        if ($stmt_kelas) {
            mysqli_stmt_bind_param($stmt_kelas, "i", $id_siswa);
            mysqli_stmt_execute($stmt_kelas);
            $hasil_kelas = mysqli_stmt_get_result($stmt_kelas);
            $row_kelas = $hasil_kelas ? mysqli_fetch_assoc($hasil_kelas) : null;
            $id_kelas = (int)($row_kelas['id_kelas'] ?? 0);
        }

        if ($id_siswa <= 0 || $id_mapel <= 0 || $id_tahun <= 0) {
            $pesan = 'Siswa, mata pelajaran, dan tahun ajaran wajib dipilih.';
        } elseif ($id_kelas <= 0) {
            $pesan = 'Siswa tersebut belum ditempatkan ke kelas. Silakan lengkapi Data Kelas.';
        } else {
            /*
             * Dibangun dinamis berdasarkan kolom yang benar-benar ada.
             * Saat tabel berubah, modul tidak memaksa kolom fiktif.
             */
            $insert_fields = ['id_siswa', 'id_kelas', 'id_mapel', 'id_tahun_ajaran'];
            $insert_values = [$id_siswa, $id_kelas, $id_mapel, $id_tahun];
            $types = 'iiii';

            foreach ($value_columns as $field => $label) {
                $nilai = trim($_POST[$field] ?? '');
                $insert_fields[] = $field;
                $insert_values[] = ($nilai === '') ? null : $nilai;
                $types .= 's';
            }

            $marks = implode(', ', array_fill(0, count($insert_fields), '?'));
            $field_sql = implode(', ', $insert_fields);

            $sql = "INSERT INTO nilai ($field_sql) VALUES ($marks)";
            $stmt = mysqli_prepare($koneksi, $sql);

            if (!$stmt) {
                $pesan = 'Gagal menyiapkan penyimpanan nilai: ' . mysqli_error($koneksi);
            } else {
                mysqli_stmt_bind_param($stmt, $types, ...$insert_values);

                if (mysqli_stmt_execute($stmt)) {
                    header("Location: index.php?sukses=1");
                    exit;
                }

                $pesan = 'Nilai gagal disimpan: ' . mysqli_error($koneksi);
            }
        }
    }
}

if (isset($_GET['sukses'])) {
    $pesan = 'Nilai berhasil disimpan.';
}

/* Rekap ringkas bila relasi standar tersedia. */
$q_data = false;
$jumlah_data = 0;

if (
    in_array('id_siswa', $column_names, true) &&
    in_array('id_kelas', $column_names, true) &&
    in_array('id_mapel', $column_names, true) &&
    in_array('id_tahun_ajaran', $column_names, true)
) {
    $select_values = '';
    foreach (array_keys($value_columns) as $field) {
        $select_values .= ", n." . $field;
    }

    $sql_data = "SELECT
                    n.id_nilai,
                    s.nama_siswa,
                    k.nama_kelas,
                    m.nama_mapel,
                    ta.tahun_ajaran,
                    ta.semester
                    $select_values
                 FROM nilai n
                 LEFT JOIN siswa s ON s.id_siswa = n.id_siswa
                 LEFT JOIN kelas k ON k.id_kelas = n.id_kelas
                 LEFT JOIN mata_pelajaran m ON m.id_mapel = n.id_mapel
                 LEFT JOIN tahun_ajaran ta ON ta.id_tahun_ajaran = n.id_tahun_ajaran
                 ORDER BY s.nama_siswa ASC, m.nama_mapel ASC";

    $q_data = mysqli_query($koneksi, $sql_data);
    $jumlah_data = $q_data ? mysqli_num_rows($q_data) : 0;
}

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>

<style>
.nilai-page{max-width:1450px}.page-head{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:24px}
.page-head h1{margin-bottom:6px}.page-head p{margin:0}
.btn-primary,.btn-secondary{display:inline-flex;align-items:center;justify-content:center;gap:7px;border:0;border-radius:10px;padding:11px 16px;text-decoration:none;font-size:14px;font-weight:600;cursor:pointer}
.btn-primary{background:linear-gradient(135deg,#2388f5,#1265dc);color:#fff;box-shadow:0 8px 18px rgba(18,101,220,.22)}
.btn-secondary{background:#eef3f9;color:#334155}
.alert{padding:13px 15px;border-radius:11px;margin-bottom:18px;font-size:14px}
.alert-success{background:#ecfdf3;color:#18794e;border:1px solid #ccefdc}
.alert-error{background:#fff1f2;color:#be123c;border:1px solid #fecdd3}
.info{background:#eef6ff;color:#1e5ca8;border:1px solid #cfe4ff}
.form-card,.data-panel{background:#fff;border-radius:18px;box-shadow:0 8px 25px rgba(15,35,70,.07);padding:24px;margin-bottom:22px}
.form-title{margin:0 0 5px}.form-subtitle{margin:0 0 20px;color:#64748b;font-size:14px}
.form-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:15px}
.form-group{display:flex;flex-direction:column;gap:7px}.form-label{font-size:13px;font-weight:600;color:#334155}
.form-control{width:100%;min-height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:9px 11px;outline:none;background:#fff;font:inherit}
.form-control:focus{border-color:#2388f5;box-shadow:0 0 0 3px rgba(35,136,245,.1)}
.form-actions{display:flex;gap:9px;margin-top:20px}.table-wrap{overflow-x:auto}
.data-table{width:100%;border-collapse:collapse;min-width:900px}.data-table th{text-align:left;background:#f7f9fc;color:#64748b;font-size:12px;text-transform:uppercase;letter-spacing:.5px;padding:13px 12px}
.data-table td{padding:14px 12px;border-bottom:1px solid #edf1f6;font-size:14px;color:#334155}.data-table tr:hover td{background:#fbfdff}
.nama-siswa{font-weight:700;color:#17233c}.sub-text{font-size:12px;color:#94a3b8;margin-top:3px}
.badge{display:inline-flex;padding:5px 9px;border-radius:999px;font-size:12px;font-weight:700;background:#eef4ff;color:#1d64d8}
.warning-box{padding:18px;border-radius:12px;background:#fff8e8;color:#8a5a00;border:1px solid #f5d996;line-height:1.6}
@media(max-width:900px){.form-grid{grid-template-columns:1fr 1fr}}@media(max-width:620px){.page-head{align-items:flex-start;flex-direction:column}.form-grid{grid-template-columns:1fr}}
</style>

<main class="main-content">
<div class="nilai-page">

<div class="page-head">
<div>
<h1>Nilai Siswa</h1>
<p>Kelola nilai siswa berdasarkan mata pelajaran dan tahun ajaran.</p>
</div>
<?php if ($q_data !== false || count($column_names) > 0): ?>
<a href="index.php?tambah=1" class="btn-primary">➕ Input Nilai</a>
<?php endif; ?>
</div>

<?php if ($pesan !== ''): ?>
<div class="alert <?= isset($_GET['sukses']) ? 'alert-success' : 'alert-error'; ?>"><?= h($pesan); ?></div>
<?php endif; ?>

<?php if (!$q_columns): ?>
<div class="alert alert-error">
Tabel <strong>nilai</strong> belum dapat dibaca: <?= h(mysqli_error($koneksi)); ?>
</div>
<?php elseif (!in_array('id_siswa', $column_names, true) || !in_array('id_mapel', $column_names, true) || !in_array('id_tahun_ajaran', $column_names, true)): ?>
<div class="warning-box">
<strong>Struktur tabel nilai perlu dicek.</strong><br>
Kolom yang terbaca saat ini:
<?= h(implode(', ', $column_names)); ?><br><br>
Modul belum melakukan penyimpanan agar tidak merusak struktur database.
</div>
<?php endif; ?>

<?php if (isset($_GET['tambah']) && $q_columns): ?>
<div class="form-card">
<h2 class="form-title">Input Nilai Siswa</h2>
<p class="form-subtitle">Pilih siswa, mata pelajaran, dan tahun ajaran. Kelas akan mengikuti data siswa.</p>

<form method="post">
<input type="hidden" name="aksi" value="simpan">

<div class="form-grid">

<div class="form-group">
<label class="form-label">Siswa *</label>
<select name="id_siswa" class="form-control" required>
<option value="">Pilih siswa</option>
<?php foreach ($daftar_siswa as $siswa): ?>
<option value="<?= (int)$siswa['id_siswa']; ?>"><?= h($siswa['nama_siswa']); ?></option>
<?php endforeach; ?>
</select>
</div>

<div class="form-group">
<label class="form-label">Mata Pelajaran *</label>
<select name="id_mapel" class="form-control" required>
<option value="">Pilih mata pelajaran</option>
<?php foreach ($daftar_mapel as $mapel): ?>
<option value="<?= (int)$mapel['id_mapel']; ?>"><?= h($mapel['nama_mapel']); ?></option>
<?php endforeach; ?>
</select>
</div>

<div class="form-group">
<label class="form-label">Tahun Ajaran / Semester *</label>
<select name="id_tahun_ajaran" class="form-control" required>
<option value="">Pilih tahun ajaran</option>
<?php foreach ($daftar_tahun as $tahun): ?>
<option value="<?= (int)$tahun['id_tahun_ajaran']; ?>">
<?= h($tahun['tahun_ajaran']); ?> - <?= h($tahun['semester']); ?>
</option>
<?php endforeach; ?>
</select>
</div>

<?php foreach ($value_columns as $field => $label): ?>
<div class="form-group">
<label class="form-label"><?= h($label); ?></label>
<input type="number" name="<?= h($field); ?>" class="form-control" min="0" max="100" step="0.01">
</div>
<?php endforeach; ?>

</div>

<?php if (empty($value_columns)): ?>
<div class="alert info" style="margin-top:18px;">
Kolom nilai numerik belum terdeteksi. Modul menemukan relasi master, tetapi belum menemukan kolom seperti <strong>nilai_tugas</strong>, <strong>nilai_uts</strong>, <strong>nilai_uas</strong>, atau <strong>nilai_akhir</strong>.
</div>
<?php endif; ?>

<div class="form-actions">
<button type="submit" class="btn-primary">💾 Simpan Nilai</button>
<a href="index.php" class="btn-secondary">Batal</a>
</div>
</form>
</div>
<?php endif; ?>

<div class="data-panel">

<div style="margin-bottom:16px;color:#64748b;font-size:14px;">
📊 <strong><?= $jumlah_data; ?></strong> data nilai
</div>

<?php if ($q_data && $jumlah_data > 0): ?>
<div class="table-wrap">
<table class="data-table">
<thead>
<tr>
<th>No</th><th>Siswa</th><th>Kelas</th><th>Mata Pelajaran</th><th>Tahun / Semester</th>
<?php foreach ($value_columns as $label): ?>
<th><?= h($label); ?></th>
<?php endforeach; ?>
</tr>
</thead>
<tbody>
<?php $no=1; while($row=mysqli_fetch_assoc($q_data)): ?>
<tr>
<td><?= $no++; ?></td>
<td><div class="nama-siswa"><?= h($row['nama_siswa']); ?></div></td>
<td><?= h($row['nama_kelas'] ?: '-'); ?></td>
<td><?= h($row['nama_mapel'] ?: '-'); ?></td>
<td><?= h($row['tahun_ajaran'] ?: '-'); ?> - <?= h($row['semester'] ?: '-'); ?></td>
<?php foreach (array_keys($value_columns) as $field): ?>
<td><span class="badge"><?= h($row[$field] ?? '-'); ?></span></td>
<?php endforeach; ?>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>
<?php elseif ($q_data === false && $q_columns): ?>
<div class="alert alert-error">Data nilai gagal dibaca: <?= h(mysqli_error($koneksi)); ?></div>
<?php else: ?>
<div style="text-align:center;padding:45px 15px;color:#94a3b8;">Belum ada data nilai.</div>
<?php endif; ?>

</div>

</div>
</main>

</body>
</html>
