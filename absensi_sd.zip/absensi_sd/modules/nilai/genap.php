<?php
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator', 'Guru');

require_once "../../config/database.php";

$menu_aktif = 'nilai_genap';
$page_title = 'Nilai Genap - SDN Ciburayut 01';

function h($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

/* Pastikan periode Genap tersedia */
$cek_genap = mysqli_query(
    $koneksi,
    "SELECT id_tahun_ajaran
     FROM tahun_ajaran
     WHERE tahun_ajaran = '2026/2027'
       AND semester = 'Genap'
     LIMIT 1"
);

if ($cek_genap && mysqli_num_rows($cek_genap) === 0) {
    mysqli_query(
        $koneksi,
        "INSERT INTO tahun_ajaran (tahun_ajaran, semester, aktif)
         VALUES ('2026/2027', 'Genap', 0)"
    );
}

/* Struktur tabel nilai */
$columns = [];
$qcols = mysqli_query($koneksi, "SHOW COLUMNS FROM nilai");
if ($qcols) {
    while ($c = mysqli_fetch_assoc($qcols)) {
        $columns[] = $c['Field'];
    }
}

$has = function($field) use (&$columns) {
    return in_array($field, $columns, true);
};

/* Filter */
$id_kelas = (int)($_REQUEST['id_kelas'] ?? 0);
$id_mapel = (int)($_REQUEST['id_mapel'] ?? 0);
$id_tahun = (int)($_REQUEST['id_tahun_ajaran'] ?? 0);
$cari = trim($_REQUEST['cari'] ?? '');

$pesan = '';
$tipe = '';

/* Tahun ajaran Genap */
$tahun = [];
$q = mysqli_query(
    $koneksi,
    "SELECT id_tahun_ajaran, tahun_ajaran, semester, aktif
     FROM tahun_ajaran
     WHERE semester = 'Genap'
     ORDER BY aktif DESC, id_tahun_ajaran DESC"
);

if ($q) {
    while ($r = mysqli_fetch_assoc($q)) {
        $tahun[] = $r;
    }
}

if (!$id_tahun && $tahun) {
    $id_tahun = (int)$tahun[0]['id_tahun_ajaran'];
}

/* Kelas */
$kelas = [];
$q = mysqli_query(
    $koneksi,
    "SELECT id_kelas, nama_kelas, tingkat
     FROM kelas
     ORDER BY tingkat ASC, nama_kelas ASC"
);

if ($q) {
    while ($r = mysqli_fetch_assoc($q)) {
        $kelas[] = $r;
    }
}

/* Mata pelajaran */
$mapel = [];
$q = mysqli_query(
    $koneksi,
    "SELECT id_mapel, kode_mapel, nama_mapel, kelompok
     FROM mata_pelajaran
     WHERE status = 'Aktif'
     ORDER BY nama_mapel ASC"
);

if ($q) {
    while ($r = mysqli_fetch_assoc($q)) {
        $mapel[] = $r;
    }
}

/* Kolom nilai */
$value_fields = [];
if ($has('nilai_tugas')) $value_fields['nilai_tugas'] = 'Nilai Tugas (30%)';
if ($has('nilai_uts'))   $value_fields['nilai_uts']   = 'Nilai UTS (30%)';
if ($has('nilai_uas'))   $value_fields['nilai_uas']   = 'Nilai UAS (40%)';
if ($has('nilai_akhir')) $value_fields['nilai_akhir'] = 'Nilai Akhir';

/* Simpan nilai */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'simpan') {

    $post_kelas = (int)($_POST['id_kelas'] ?? 0);
    $post_mapel = (int)($_POST['id_mapel'] ?? 0);
    $post_tahun = (int)($_POST['id_tahun_ajaran'] ?? 0);

    if (!$post_mapel || !$post_tahun) {
        $pesan = 'Mata pelajaran dan tahun ajaran wajib dipilih.';
        $tipe = 'error';
    } elseif (!$value_fields) {
        $pesan = 'Kolom nilai belum tersedia pada tabel nilai.';
        $tipe = 'error';
    } else {

        $berhasil = 0;
        $gagal = 0;

        $nilai_post = $_POST['nilai'] ?? [];

        foreach ($nilai_post as $sid_raw => $data) {

            $sid = (int)$sid_raw;
            if ($sid <= 0) {
                continue;
            }

            /* Kelas siswa */
            $kelas_siswa = 0;
            $stmt_k = mysqli_prepare(
                $koneksi,
                "SELECT id_kelas FROM siswa WHERE id_siswa = ? LIMIT 1"
            );

            if ($stmt_k) {
                mysqli_stmt_bind_param($stmt_k, "i", $sid);
                mysqli_stmt_execute($stmt_k);
                $rk = mysqli_stmt_get_result($stmt_k);
                $rowk = $rk ? mysqli_fetch_assoc($rk) : null;
                $kelas_siswa = (int)($rowk['id_kelas'] ?? 0);
            }

            if ($kelas_siswa <= 0 && $post_kelas > 0) {
                // Kelas master hanya dikelola dari Data Siswa / Dapodik.
            }

            if ($kelas_siswa <= 0) {
                $gagal++;
                continue;
            }

            $tugas = (float)($data['nilai_tugas'] ?? 0);
            $uts   = (float)($data['nilai_uts'] ?? 0);
            $uas   = (float)($data['nilai_uas'] ?? 0);

            $tugas = max(0, min(100, $tugas));
            $uts   = max(0, min(100, $uts));
            $uas   = max(0, min(100, $uas));

            $akhir = round(($tugas * 0.30) + ($uts * 0.30) + ($uas * 0.40), 2);

            $check = mysqli_prepare(
                $koneksi,
                "SELECT id_nilai
                 FROM nilai
                 WHERE id_siswa = ?
                   AND id_mapel = ?
                   AND id_tahun_ajaran = ?
                 LIMIT 1"
            );

            $existing = false;
            if ($check) {
                mysqli_stmt_bind_param($check, "iii", $sid, $post_mapel, $post_tahun);
                mysqli_stmt_execute($check);
                $cr = mysqli_stmt_get_result($check);
                $existing = $cr && mysqli_num_rows($cr) > 0;
            }

            $save_fields = [];
            $save_values = [];
            $save_types = '';

            if ($has('nilai_tugas')) {
                $save_fields[] = 'nilai_tugas';
                $save_values[] = (string)$tugas;
                $save_types .= 's';
            }
            if ($has('nilai_uts')) {
                $save_fields[] = 'nilai_uts';
                $save_values[] = (string)$uts;
                $save_types .= 's';
            }
            if ($has('nilai_uas')) {
                $save_fields[] = 'nilai_uas';
                $save_values[] = (string)$uas;
                $save_types .= 's';
            }
            if ($has('nilai_akhir')) {
                $save_fields[] = 'nilai_akhir';
                $save_values[] = (string)$akhir;
                $save_types .= 's';
            }

            if ($existing) {

                $sets = [];
                foreach ($save_fields as $field) {
                    $sets[] = "`$field` = ?";
                }

                $params = [$kelas_siswa];
                $types = 'i';

                foreach ($save_values as $v) {
                    $params[] = $v;
                    $types .= 's';
                }

                $params[] = $sid;
                $params[] = $post_mapel;
                $params[] = $post_tahun;
                $types .= 'iii';

                $sql = "UPDATE nilai
                        SET id_kelas = ?, " . implode(', ', $sets) . "
                        WHERE id_siswa = ?
                          AND id_mapel = ?
                          AND id_tahun_ajaran = ?";

                $st = mysqli_prepare($koneksi, $sql);

                if ($st) {
                    mysqli_stmt_bind_param($st, $types, ...$params);
                    if (mysqli_stmt_execute($st)) $berhasil++;
                    else $gagal++;
                } else {
                    $gagal++;
                }

            } else {

                $fields = ['id_siswa', 'id_kelas', 'id_mapel', 'id_tahun_ajaran'];
                $values = [$sid, $kelas_siswa, $post_mapel, $post_tahun];
                $types = 'iiii';

                foreach ($save_fields as $i => $field) {
                    $fields[] = $field;
                    $values[] = $save_values[$i];
                    $types .= 's';
                }

                $marks = implode(', ', array_fill(0, count($fields), '?'));
                $quoted = '`' . implode('`,`', $fields) . '`';

                $sql = "INSERT INTO nilai ($quoted) VALUES ($marks)";
                $st = mysqli_prepare($koneksi, $sql);

                if ($st) {
                    mysqli_stmt_bind_param($st, $types, ...$values);
                    if (mysqli_stmt_execute($st)) $berhasil++;
                    else $gagal++;
                } else {
                    $gagal++;
                }
            }
        }

        if ($berhasil > 0) {
            $pesan = "Nilai Genap berhasil disimpan untuk $berhasil siswa.";
            if ($gagal) $pesan .= " Ada $gagal data yang belum tersimpan.";
            $tipe = $gagal ? 'error' : 'success';
        } else {
            $pesan = 'Belum ada nilai yang berhasil disimpan.';
            $tipe = 'error';
        }

        $id_kelas = $post_kelas;
        $id_mapel = $post_mapel;
        $id_tahun = $post_tahun;
    }
}

/* Siswa */
$siswa = [];
$where = "s.status_siswa = 'Aktif'";

if ($id_kelas > 0) {
    $where .= " AND s.id_kelas = " . $id_kelas;
}

if ($cari !== '') {
    $safe = mysqli_real_escape_string($koneksi, $cari);
    $where .= " AND (
        s.nama_siswa LIKE '%$safe%'
        OR s.nis LIKE '%$safe%'
        OR s.nisn LIKE '%$safe%'
    )";
}

$q = mysqli_query(
    $koneksi,
    "SELECT s.id_siswa, s.nis, s.nisn, s.nama_siswa, k.nama_kelas
     FROM siswa s
     LEFT JOIN kelas k ON k.id_kelas = s.id_kelas
     WHERE $where
     ORDER BY k.tingkat, k.nama_kelas, s.nama_siswa"
);

if ($q) {
    while ($r = mysqli_fetch_assoc($q)) {
        $siswa[] = $r;
    }
}

/* Nilai existing */
$nilai_existing = [];

if ($id_mapel > 0 && $id_tahun > 0) {

    $sql = "SELECT *
            FROM nilai
            WHERE id_mapel = ?
              AND id_tahun_ajaran = ?";

    $vals = [$id_mapel, $id_tahun];
    $types = 'ii';

    if ($id_kelas > 0 && $has('id_kelas')) {
        $sql .= " AND id_kelas = ?";
        $vals[] = $id_kelas;
        $types .= 'i';
    }

    $st = mysqli_prepare($koneksi, $sql);

    if ($st) {
        mysqli_stmt_bind_param($st, $types, ...$vals);
        mysqli_stmt_execute($st);
        $rr = mysqli_stmt_get_result($st);

        if ($rr) {
            while ($r = mysqli_fetch_assoc($rr)) {
                $nilai_existing[(int)$r['id_siswa']] = $r;
            }
        }
    }
}

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>

<style>
.nilai-page{max-width:1500px}
.page-head{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:24px}
.page-head h1{margin:0 0 6px}.page-head p{margin:0}
.card{background:#fff;border-radius:18px;box-shadow:0 8px 25px rgba(15,35,70,.07);padding:20px;margin-bottom:20px}
.filters{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
label{display:block;font-size:13px;font-weight:600;color:#334155;margin-bottom:7px}
.fc,.nilai-input{width:100%;height:40px;border:1px solid #dbe4ef;border-radius:9px;padding:0 10px;background:#fff;outline:none}
.fc:focus,.nilai-input:focus{border-color:#2388f5;box-shadow:0 0 0 3px rgba(35,136,245,.1)}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;border:0;border-radius:10px;padding:11px 16px;font-weight:600;text-decoration:none;cursor:pointer}
.pri{background:linear-gradient(135deg,#2388f5,#1265dc);color:#fff}.sec{background:#eef3f9;color:#334155}
.alert{padding:13px 15px;border-radius:11px;margin-bottom:18px;font-size:14px}.ok{background:#ecfdf3;color:#18794e;border:1px solid #ccefdc}.er{background:#fff1f2;color:#be123c;border:1px solid #fecdd3}
.info{padding:13px 15px;border-radius:11px;background:#eef6ff;color:#245c9b;border:1px solid #d6e7fb;margin-bottom:18px;font-size:13px}
.tw{overflow-x:auto}.dt{width:100%;border-collapse:collapse;min-width:850px}
.dt th{background:#f7f9fc;color:#64748b;font-size:12px;text-transform:uppercase;padding:12px;text-align:left}.dt td{padding:11px 12px;border-bottom:1px solid #edf1f6}
.nm{font-weight:700;color:#17233c}.sub{font-size:12px;color:#94a3b8;margin-top:3px}
.nilai-input{width:105px;text-align:center}.akhir{background:#f1f5f9;font-weight:800;color:#1769d2}
@media(max-width:1000px){.filters{grid-template-columns:1fr 1fr}}@media(max-width:600px){.filters{grid-template-columns:1fr}.page-head{align-items:flex-start;flex-direction:column}}
</style>

<main class="main-content">
<div class="nilai-page">

<div class="page-head">
<div>
<h1>Nilai Genap</h1>
<p>Input dan kelola nilai siswa semester Genap.</p>
</div>
</div>

<?php if($pesan): ?>
<div class="alert <?=$tipe==='success'?'ok':'er'?>"><?=h($pesan)?></div>
<?php endif; ?>

<div class="card">
<form method="get">
<div class="filters">

<div>
<label>Kelas</label>
<select class="fc" name="id_kelas">
<option value="0">Semua Kelas</option>
<?php foreach($kelas as $k): ?>
<option value="<?=$k['id_kelas']?>" <?=$id_kelas===(int)$k['id_kelas']?'selected':''?>>Kelas <?=h($k['nama_kelas'])?></option>
<?php endforeach;?>
</select>
</div>

<div>
<label>Mata Pelajaran</label>
<select class="fc" name="id_mapel">
<option value="0">Pilih Mata Pelajaran</option>
<?php foreach($mapel as $m): ?>
<option value="<?=$m['id_mapel']?>" <?=$id_mapel===(int)$m['id_mapel']?'selected':''?>><?=h($m['nama_mapel'])?></option>
<?php endforeach;?>
</select>
</div>

<div>
<label>Tahun Ajaran / Semester</label>
<select class="fc" name="id_tahun_ajaran">
<?php foreach($tahun as $t): ?>
<option value="<?=$t['id_tahun_ajaran']?>" <?=$id_tahun===(int)$t['id_tahun_ajaran']?'selected':''?>><?=h($t['tahun_ajaran'])?> - <?=h($t['semester'])?></option>
<?php endforeach;?>
</select>
</div>

<div>
<label>Cari Siswa</label>
<input class="fc" type="text" name="cari" value="<?=h($cari)?>" placeholder="Nama, NIS, NISN...">
</div>

</div>

<div style="margin-top:15px;display:flex;gap:8px">
<button class="btn pri" type="submit">🔎 Tampilkan</button>
<a class="btn sec" href="genap.php">Reset</a>
</div>
</form>
</div>

<?php if(!$value_fields): ?>

<div class="alert er">Kolom nilai belum tersedia pada tabel <strong>nilai</strong>.</div>

<?php elseif(!$id_mapel): ?>

<div class="info">Pilih <strong>Mata Pelajaran</strong> terlebih dahulu untuk menampilkan form nilai.</div>

<?php else: ?>

<div class="info">
Rumus Nilai Akhir otomatis:
<strong>Tugas 30% + UTS 30% + UAS 40%</strong>
</div>

<div class="card">
<form method="post">
<input type="hidden" name="aksi" value="simpan">
<input type="hidden" name="id_kelas" value="<?=$id_kelas?>">
<input type="hidden" name="id_mapel" value="<?=$id_mapel?>">
<input type="hidden" name="id_tahun_ajaran" value="<?=$id_tahun?>">

<div class="tw">
<table class="dt">
<thead>
<tr>
<th>No</th>
<th>NIS/NISN</th>
<th>Nama Siswa</th>
<th>Kelas</th>
<th>Tugas<br>30%</th>
<th>UTS<br>30%</th>
<th>UAS<br>40%</th>
<th>Nilai Akhir</th>
</tr>
</thead>

<tbody>

<?php if($siswa): $no=1; foreach($siswa as $s): ?>
<?php $old=$nilai_existing[(int)$s['id_siswa']]??[]; ?>

<tr>
<td><?=$no++?></td>
<td><?=h($s['nis']?:'-')?><div class="sub">NISN: <?=h($s['nisn']?:'-')?></div></td>
<td><div class="nm"><?=h($s['nama_siswa'])?></div></td>
<td><?=h($s['nama_kelas']?:'-')?></td>

<td>
<input class="nilai-input komponen"
       type="number" min="0" max="100" step="0.01"
       name="nilai[<?=$s['id_siswa']?>][nilai_tugas]"
       value="<?=h($old['nilai_tugas']??'')?>">
</td>

<td>
<input class="nilai-input komponen"
       type="number" min="0" max="100" step="0.01"
       name="nilai[<?=$s['id_siswa']?>][nilai_uts]"
       value="<?=h($old['nilai_uts']??'')?>">
</td>

<td>
<input class="nilai-input komponen"
       type="number" min="0" max="100" step="0.01"
       name="nilai[<?=$s['id_siswa']?>][nilai_uas]"
       value="<?=h($old['nilai_uas']??'')?>">
</td>

<td>
<input class="nilai-input akhir"
       type="number" min="0" max="100" step="0.01"
       name="nilai[<?=$s['id_siswa']?>][nilai_akhir]"
       value="<?=h($old['nilai_akhir']??'')?>"
       readonly>
</td>

</tr>

<?php endforeach; else: ?>

<tr>
<td colspan="8" style="text-align:center;padding:40px;color:#94a3b8">
Belum ada siswa pada filter ini.
</td>
</tr>

<?php endif; ?>

</tbody>
</table>
</div>

<?php if($siswa): ?>
<div style="margin-top:18px;text-align:right">
<button class="btn pri" type="submit">💾 Simpan Nilai Genap</button>
</div>
<?php endif; ?>

</form>
</div>

<?php endif; ?>

</div>
</main>

<script>
document.addEventListener('input', function(e){
    if(!e.target.classList.contains('komponen')) return;

    const row = e.target.closest('tr');
    if(!row) return;

    const inputs = row.querySelectorAll('.komponen');

    const tugas = Math.max(0, Math.min(100, parseFloat(inputs[0].value || 0)));
    const uts   = Math.max(0, Math.min(100, parseFloat(inputs[1].value || 0)));
    const uas   = Math.max(0, Math.min(100, parseFloat(inputs[2].value || 0)));

    const akhir = (tugas * 0.30) + (uts * 0.30) + (uas * 0.40);

    const target = row.querySelector('.akhir');
    if(target){
        target.value = akhir.toFixed(2);
    }
});
</script>

</body>
</html>
