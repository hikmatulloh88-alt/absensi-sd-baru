<?php
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator', 'Guru');
require_once "../../config/database.php";

$semester_target = 'Gasal';
$judul_semester = 'Nilai Gasal';
$menu_aktif = 'nilai_gasal';
$page_title = $judul_semester . ' - SDN Ciburayut 01';

function h($v){
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

/* Baca struktur tabel nilai */
$columns = [];
$qcols = mysqli_query($koneksi, "SHOW COLUMNS FROM nilai");
if ($qcols) {
    while ($r = mysqli_fetch_assoc($qcols)) {
        $columns[] = $r['Field'];
    }
}
$has = function($field) use (&$columns) {
    return in_array($field, $columns, true);
};

/* Filter */
$id_kelas = (int)($_GET['id_kelas'] ?? 0);
$id_tahun = (int)($_GET['id_tahun_ajaran'] ?? 0);
$id_mapel = (int)($_GET['id_mapel'] ?? 0);
$cari = trim($_GET['cari'] ?? '');

$pesan = '';
$tipe = '';

/* Tahun ajaran - prioritaskan semester target */
$tahun = [];
$q = mysqli_query(
    $koneksi,
    "SELECT id_tahun_ajaran, tahun_ajaran, semester, aktif
     FROM tahun_ajaran
     WHERE semester = 'Gasal'
     ORDER BY aktif DESC, id_tahun_ajaran DESC"
);
if ($q) {
    while ($r = mysqli_fetch_assoc($q)) {
        $tahun[] = $r;
    }
}

/* Jika belum ada Gasal, tampilkan semua sebagai fallback */
if (!$tahun) {
    $q = mysqli_query(
        $koneksi,
        "SELECT id_tahun_ajaran, tahun_ajaran, semester, aktif
         FROM tahun_ajaran
         ORDER BY aktif DESC, id_tahun_ajaran DESC"
    );
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $tahun[] = $r;
        }
    }
}
if (!$id_tahun && $tahun) {
    $id_tahun = (int)$tahun[0]['id_tahun_ajaran'];
}

/* Kelas */
$kelas = [];
$q = mysqli_query(
    $koneksi,
    "SELECT id_kelas, nama_kelas, tingkat
     FROM kelas
     ORDER BY tingkat ASC, nama_kelas ASC"
);
if ($q) {
    while ($r = mysqli_fetch_assoc($q)) $kelas[] = $r;
}

/* Mapel */
$mapel = [];
$q = mysqli_query(
    $koneksi,
    "SELECT id_mapel, kode_mapel, nama_mapel, kelompok
     FROM mata_pelajaran
     WHERE status = 'Aktif'
     ORDER BY nama_mapel ASC"
);
if ($q) {
    while ($r = mysqli_fetch_assoc($q)) $mapel[] = $r;
}

/* Simpan banyak nilai */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'simpan') {

    $post_tahun = (int)($_POST['id_tahun_ajaran'] ?? 0);
    $post_mapel = (int)($_POST['id_mapel'] ?? 0);
    $post_kelas = (int)($_POST['id_kelas'] ?? 0);

    if (
        !$has('id_siswa') || !$has('id_kelas') ||
        !$has('id_mapel') || !$has('id_tahun_ajaran')
    ) {
        $pesan = 'Struktur tabel nilai belum memiliki relasi yang dibutuhkan.';
        $tipe = 'error';
    } elseif (!$post_tahun || !$post_mapel) {
        $pesan = 'Tahun ajaran dan mata pelajaran wajib dipilih.';
        $tipe = 'error';
    } else {

        /* Ambil kolom nilai numerik yang benar-benar ada */
        $value_candidates = [
            'nilai_tugas' => 'Nilai Tugas (30%)',
            'nilai_uts' => 'Nilai UTS (30%)',
            'nilai_uas' => 'Nilai UAS (40%)',
            'nilai_akhir' => 'Nilai Akhir'
        ];

        $value_fields = [];
        foreach ($value_candidates as $field => $label) {
            if ($has($field)) {
                $value_fields[$field] = $label;
            }
        }

        if (!$value_fields) {
            $pesan = 'Belum ditemukan kolom nilai numerik pada tabel nilai.';
            $tipe = 'error';
        } else {
            $berhasil = 0;
            $gagal = 0;

            foreach ($_POST['nilai'] ?? [] as $id_siswa => $nilai_data) {

                $sid = (int)$id_siswa;
                if ($sid <= 0) continue;

                /* Kelas siswa harus mengikuti master siswa */
                $kelas_siswa = 0;
                $st_k = mysqli_prepare($koneksi, "SELECT id_kelas FROM siswa WHERE id_siswa = ? LIMIT 1");
                if ($st_k) {
                    mysqli_stmt_bind_param($st_k, "i", $sid);
                    mysqli_stmt_execute($st_k);
                    $rr = mysqli_stmt_get_result($st_k);
                    $rk = $rr ? mysqli_fetch_assoc($rr) : null;
                    $kelas_siswa = (int)($rk['id_kelas'] ?? 0);
                }

                if ($kelas_siswa <= 0) {
                    $gagal++;
                    continue;
                }

                /* Cek nilai existing berdasarkan unique siswa-mapel-tahun */
                $check_sql = "SELECT * FROM nilai
                              WHERE id_siswa = ?
                                AND id_mapel = ?
                                AND id_tahun_ajaran = ?
                              LIMIT 1";
                $st_c = mysqli_prepare($koneksi, $check_sql);
                $existing = null;

                if ($st_c) {
                    mysqli_stmt_bind_param($st_c, "iii", $sid, $post_mapel, $post_tahun);
                    mysqli_stmt_execute($st_c);
                    $rr = mysqli_stmt_get_result($st_c);
                    $existing = $rr ? mysqli_fetch_assoc($rr) : null;
                }

                $fields = [];
                $vals = [];
                $types = '';

                foreach ($value_fields as $field => $label) {
                    $v = trim((string)($nilai_data[$field] ?? ''));
                    if ($v === '') {
                        $v = null;
                    } else {
                        $num = (float)$v;
                        if ($num < 0) $num = 0;
                        if ($num > 100) $num = 100;
                        $v = (string)$num;
                    }
                    $fields[] = $field;
                    $vals[] = $v;
                    $types .= 's';
                }

                if ($existing) {

                    $sets = [];
                    foreach ($fields as $f) {
                        $sets[] = "`$f` = ?";
                    }

                    $upd_vals = [$kelas_siswa];
                    $upd_types = 'i';

                    foreach ($vals as $v) {
                        $upd_types .= 's';
                        $upd_vals[] = $v;
                    }

                    $upd_types .= 'iii';
                    $upd_vals[] = $sid;
                    $upd_vals[] = $post_mapel;
                    $upd_vals[] = $post_tahun;

                    $upd = mysqli_prepare(
                        $koneksi,
                        "UPDATE nilai SET id_kelas = ?, " .
                        implode(', ', $sets) .
                        " WHERE id_siswa = ? AND id_mapel = ? AND id_tahun_ajaran = ?"
                    );

                    if ($upd) {
                        mysqli_stmt_bind_param($upd, $upd_types, ...$upd_vals);
                        if (mysqli_stmt_execute($upd)) $berhasil++;
                        else $gagal++;
                    } else {
                        $gagal++;
                    }

                } else {

                    $insert_fields = ['id_siswa','id_kelas','id_mapel','id_tahun_ajaran'];
                    $insert_vals = [$sid,$kelas_siswa,$post_mapel,$post_tahun];
                    $insert_types = 'iiii';

                    foreach ($fields as $i => $f) {
                        $insert_fields[] = $f;
                        $insert_vals[] = $vals[$i];
                        $insert_types .= 's';
                    }

                    $marks = implode(',', array_fill(0, count($insert_fields), '?'));
                    $quoted = '`'.implode('`,`',$insert_fields).'`';

                    $ins = mysqli_prepare(
                        $koneksi,
                        "INSERT INTO nilai ($quoted) VALUES ($marks)"
                    );

                    if ($ins) {
                        mysqli_stmt_bind_param($ins, $insert_types, ...$insert_vals);
                        if (mysqli_stmt_execute($ins)) $berhasil++;
                        else $gagal++;
                    } else {
                        $gagal++;
                    }
                }
            }

            if ($berhasil > 0) {
                $pesan = "Nilai $semester_target berhasil disimpan untuk $berhasil siswa.";
                if ($gagal) $pesan .= " Ada $gagal data yang belum tersimpan.";
                $tipe = $gagal ? 'error' : 'success';
            } else {
                $pesan = 'Belum ada nilai yang tersimpan.';
                $tipe = 'error';
            }

            $id_tahun = $post_tahun;
            $id_mapel = $post_mapel;
            $id_kelas = $post_kelas;
        }
    }
}

/* Siswa untuk input */
$siswa = [];
$where = "s.status_siswa = 'Aktif'";

if ($id_kelas > 0) {
    $where .= " AND s.id_kelas = " . $id_kelas;
}

if ($cari !== '') {
    $safe = mysqli_real_escape_string($koneksi, $cari);
    $where .= " AND (s.nama_siswa LIKE '%$safe%' OR s.nis LIKE '%$safe%' OR s.nisn LIKE '%$safe%')";
}

$q = mysqli_query(
    $koneksi,
    "SELECT s.id_siswa,s.nis,s.nisn,s.nama_siswa,k.nama_kelas
     FROM siswa s
     LEFT JOIN kelas k ON k.id_kelas=s.id_kelas
     WHERE $where
     ORDER BY k.tingkat,k.nama_kelas,s.nama_siswa"
);

if ($q) {
    while ($r=mysqli_fetch_assoc($q)) $siswa[]=$r;
}

/* Nilai yang sudah ada untuk filter */
$nilai_existing = [];

if ($id_mapel > 0 && $id_tahun > 0 && $has('id_siswa') && $has('id_mapel') && $has('id_tahun_ajaran')) {

    $sql = "SELECT * FROM nilai
            WHERE id_mapel = ? AND id_tahun_ajaran = ?";
    $vals = [$id_mapel,$id_tahun];
    $types = 'ii';

    if ($id_kelas > 0 && $has('id_kelas')) {
        $sql .= " AND id_kelas = ?";
        $vals[] = $id_kelas;
        $types .= 'i';
    }

    $st = mysqli_prepare($koneksi,$sql);
    if ($st) {
        mysqli_stmt_bind_param($st,$types,...$vals);
        mysqli_stmt_execute($st);
        $rr = mysqli_stmt_get_result($st);
        if ($rr) {
            while($r=mysqli_fetch_assoc($rr)){
                $nilai_existing[(int)$r['id_siswa']]=$r;
            }
        }
    }
}

/* Kolom nilai */
$value_candidates = [
    'nilai_tugas' => 'Nilai Tugas (30%)',
    'nilai_uts' => 'Nilai UTS (30%)',
    'nilai_uas' => 'Nilai UAS (40%)',
    'nilai_akhir' => 'Nilai Akhir'
];
$value_fields=[];
foreach($value_candidates as $f=>$label){
    if($has($f)) $value_fields[$f]=$label;
}

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>

<style>
.nilai-page{max-width:1500px}
.page-head{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:24px}
.page-head h1{margin:0 0 6px}.page-head p{margin:0}
.card{background:#fff;border-radius:18px;box-shadow:0 8px 25px rgba(15,35,70,.07);padding:20px;margin-bottom:20px}
.filters{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
label{display:block;font-size:13px;font-weight:600;color:#334155;margin-bottom:7px}
.fc,.nilai-input{width:100%;height:40px;border:1px solid #dbe4ef;border-radius:9px;padding:0 10px;background:#fff;outline:none}
.fc:focus,.nilai-input:focus{border-color:#2388f5;box-shadow:0 0 0 3px rgba(35,136,245,.1)}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;border:0;border-radius:10px;padding:11px 16px;font-weight:600;text-decoration:none;cursor:pointer}
.pri{background:linear-gradient(135deg,#2388f5,#1265dc);color:#fff}.sec{background:#eef3f9;color:#334155}
.alert{padding:13px 15px;border-radius:11px;margin-bottom:18px;font-size:14px;line-height:1.5}.ok{background:#ecfdf3;color:#18794e;border:1px solid #ccefdc}.er{background:#fff1f2;color:#be123c;border:1px solid #fecdd3}
.table-wrap{overflow-x:auto}.dt{width:100%;border-collapse:collapse;min-width:1000px}
.dt th{background:#f7f9fc;color:#64748b;font-size:12px;text-transform:uppercase;padding:12px;text-align:left}.dt td{padding:11px 12px;border-bottom:1px solid #edf1f6}
.nm{font-weight:700;color:#17233c}.sub{font-size:12px;color:#94a3b8;margin-top:3px}.nilai-input{min-width:90px;max-width:110px;text-align:center}.nilai-akhir{color:#1769d2}.weight-note{margin-bottom:15px;padding:11px 14px;border-radius:10px;background:#eef6ff;border:1px solid #d6e7fb;color:#245c9b;font-size:13px}
.info{padding:13px 15px;border-radius:11px;background:#eef6ff;border:1px solid #d6e7fb;color:#245c9b;margin-bottom:18px;font-size:13px}
@media(max-width:1000px){.filters{grid-template-columns:1fr 1fr}}@media(max-width:600px){.filters{grid-template-columns:1fr}.page-head{align-items:flex-start;flex-direction:column}}
</style>

<main class="main-content">
<div class="nilai-page">

<div class="page-head">
<div>
<h1><?=h($judul_semester)?></h1>
<p>Input dan kelola nilai siswa semester <?=h($semester_target)?>.</p>
</div>
</div>

<?php if($pesan): ?>
<div class="alert <?=$tipe==='success'?'ok':'er'?>"><?=h($pesan)?></div>
<?php endif; ?>

<div class="card">
<form method="get">
<div class="filters">

<div>
<label>Kelas</label>
<select class="fc" name="id_kelas">
<option value="0">Semua Kelas</option>
<?php foreach($kelas as $k): ?>
<option value="<?=$k['id_kelas']?>" <?=$id_kelas===(int)$k['id_kelas']?'selected':''?>>Kelas <?=h($k['nama_kelas'])?></option>
<?php endforeach;?>
</select>
</div>

<div>
<label>Mata Pelajaran</label>
<select class="fc" name="id_mapel">
<option value="0">Pilih Mata Pelajaran</option>
<?php foreach($mapel as $m): ?>
<option value="<?=$m['id_mapel']?>" <?=$id_mapel===(int)$m['id_mapel']?'selected':''?>><?=h($m['nama_mapel'])?></option>
<?php endforeach;?>
</select>
</div>

<div>
<label>Tahun Ajaran / Semester</label>
<select class="fc" name="id_tahun_ajaran">
<?php foreach($tahun as $t): ?>
<option value="<?=$t['id_tahun_ajaran']?>" <?=$id_tahun===(int)$t['id_tahun_ajaran']?'selected':''?>><?=h($t['tahun_ajaran'])?> - <?=h($t['semester'])?></option>
<?php endforeach;?>
</select>
</div>

<div>
<label>Cari Siswa</label>
<input class="fc" type="text" name="cari" value="<?=h($cari)?>" placeholder="Nama, NIS, NISN...">
</div>

</div>

<div style="margin-top:15px;display:flex;gap:8px">
<button class="btn pri">🔎 Tampilkan</button>
<a class="btn sec" href="gasal.php">Reset</a>
</div>
</form>
</div>

<?php if(!$value_fields): ?>
<div class="alert er">
Kolom nilai numerik belum ditemukan pada tabel <strong>nilai</strong>. Kolom yang terbaca:
<?=h(implode(', ',$columns))?>
</div>
<?php elseif(!$id_mapel): ?>
<div class="info">Pilih <strong>Mata Pelajaran</strong> terlebih dahulu untuk menampilkan form nilai siswa.</div>
<?php else: ?>

<div class="card">

<form method="post">
<input type="hidden" name="aksi" value="simpan">
<input type="hidden" name="id_kelas" value="<?=$id_kelas?>">
<input type="hidden" name="id_mapel" value="<?=$id_mapel?>">
<input type="hidden" name="id_tahun_ajaran" value="<?=$id_tahun?>">

<div class="weight-note">Rumus otomatis: <strong>Tugas 30% + UTS 30% + UAS 40%</strong>. Nilai Akhir dihitung otomatis dan tidak perlu diketik.</div>
<div style="margin-bottom:15px;color:#64748b;font-size:14px">
📊 <strong><?=count($siswa)?></strong> siswa
<?php foreach($mapel as $m){if($id_mapel===(int)$m['id_mapel']){echo ' · '.h($m['nama_mapel']);break;}} ?>
</div>

<div class="table-wrap">
<table class="dt">
<thead>
<tr>
<th>No</th>
<th>NIS/NISN</th>
<th>Nama Siswa</th>
<th>Kelas</th>
<th>Nilai Tugas<br><small>30%</small></th>
<th>Nilai UTS<br><small>30%</small></th>
<th>Nilai UAS<br><small>40%</small></th>
<th>Nilai Akhir</th>
</tr>
</thead>
<tbody>

<?php if($siswa): $no=1; foreach($siswa as $s): $old=$nilai_existing[(int)$s['id_siswa']]??[]; ?>
<tr>
<td><?=$no++?></td>
<td><?=h($s['nis']?:'-')?><div class="sub">NISN: <?=h($s['nisn']?:'-')?></div></td>
<td><div class="nm"><?=h($s['nama_siswa'])?></div></td>
<td><?=h($s['nama_kelas']?:'-')?></td>

<td><input class="nilai-input komponen" type="number" min="0" max="100" step="0.01" name="nilai[<?=$s['id_siswa']?>][nilai_tugas]" value="<?=h($old['nilai_tugas']??'')?>"></td>
<td><input class="nilai-input komponen" type="number" min="0" max="100" step="0.01" name="nilai[<?=$s['id_siswa']?>][nilai_uts]" value="<?=h($old['nilai_uts']??'')?>"></td>
<td><input class="nilai-input komponen" type="number" min="0" max="100" step="0.01" name="nilai[<?=$s['id_siswa']?>][nilai_uas]" value="<?=h($old['nilai_uas']??'')?>"></td>
<td><input class="nilai-input nilai-akhir" type="number" min="0" max="100" step="0.01" name="nilai[<?=$s['id_siswa']?>][nilai_akhir]" value="<?=h($old['nilai_akhir']??'')?>" readonly style="background:#f1f5f9;font-weight:800"></td>

</tr>
<?php endforeach; else: ?>
<tr><td colspan="<?=4+count($value_fields)?>" style="text-align:center;padding:40px;color:#94a3b8">Belum ada siswa pada filter ini.</td></tr>
<?php endif; ?>

</tbody>
</table>
</div>

<?php if($siswa): ?>
<div style="margin-top:18px;text-align:right">
<button class="btn pri" type="submit">💾 Simpan Nilai <?=h($semester_target)?></button>
</div>
<?php endif; ?>

</form>
</div>

<?php endif; ?>

</div>
</main>


<script>
document.addEventListener('input', function(e) {
    if (!e.target.classList.contains('komponen')) return;

    const row = e.target.closest('tr');
    if (!row) return;

    const inputs = row.querySelectorAll('.komponen');
    const tugas = Math.max(0, Math.min(100, parseFloat(inputs[0]?.value || 0)));
    const uts   = Math.max(0, Math.min(100, parseFloat(inputs[1]?.value || 0)));
    const uas   = Math.max(0, Math.min(100, parseFloat(inputs[2]?.value || 0)));

    const akhir = (tugas * 0.30) + (uts * 0.30) + (uas * 0.40);
    const out = row.querySelector('.nilai-akhir');

    if (out) {
        out.value = akhir.toFixed(2);
    }
});
</script>

</body>
</html>
