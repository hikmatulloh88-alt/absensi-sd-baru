<?php
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator', 'Guru');
require_once "../../config/database.php";

$menu_aktif = 'kartu';
$page_title = 'Cetak Kartu Absensi - SDN Ciburayut 01';

function h($v){
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

/* Tahun ajaran aktif */
$tahun = null;
$q_tahun = mysqli_query(
    $koneksi,
    "SELECT tahun_ajaran, semester
     FROM tahun_ajaran
     ORDER BY aktif DESC, id_tahun_ajaran DESC
     LIMIT 1"
);
if ($q_tahun) {
    $tahun = mysqli_fetch_assoc($q_tahun);
}

/* Cek apakah tabel siswa sudah memiliki kolom foto */
$kolom_siswa = [];
$q_cols = mysqli_query($koneksi, "SHOW COLUMNS FROM siswa");
if ($q_cols) {
    while ($c = mysqli_fetch_assoc($q_cols)) {
        $kolom_siswa[] = $c['Field'];
    }
}
$punya_foto = in_array('foto', $kolom_siswa, true);

/* Filter */
$cari = trim($_GET['cari'] ?? '');
$id_kelas = (int)($_GET['id_kelas'] ?? 0);

/* Kelas */
$kelas = [];
$q_kelas = mysqli_query(
    $koneksi,
    "SELECT id_kelas, nama_kelas, tingkat
     FROM kelas
     ORDER BY tingkat ASC, nama_kelas ASC"
);
if ($q_kelas) {
    while ($r = mysqli_fetch_assoc($q_kelas)) {
        $kelas[] = $r;
    }
}

/* Siswa */
$where = ["s.status_siswa = 'Aktif'"];

if ($id_kelas > 0) {
    $where[] = "s.id_kelas = " . $id_kelas;
}

if ($cari !== '') {
    $safe = mysqli_real_escape_string($koneksi, $cari);
    $where[] = "(s.nama_siswa LIKE '%$safe%'
                 OR s.nis LIKE '%$safe%'
                 OR s.nisn LIKE '%$safe%')";
}

$where_sql = implode(' AND ', $where);

$select = "s.id_siswa, s.nis, s.nisn, s.nama_siswa, s.jenis_kelamin,
           k.nama_kelas, k.tingkat";
if ($punya_foto) {
    $select .= ", s.foto";
}

$daftar = [];
$q_siswa = mysqli_query(
    $koneksi,
    "SELECT $select
     FROM siswa s
     LEFT JOIN kelas k ON k.id_kelas = s.id_kelas
     WHERE $where_sql
     ORDER BY k.tingkat ASC, k.nama_kelas ASC, s.nama_siswa ASC"
);

if ($q_siswa) {
    while ($r = mysqli_fetch_assoc($q_siswa)) {
        $daftar[] = $r;
    }
}

/* Cari file foto dengan beberapa pola nama */
function cari_foto_siswa($siswa) {
    $id = (int)$siswa['id_siswa'];

    $kandidat = [];

    if (!empty($siswa['foto'])) {
        $foto_db = trim((string)$siswa['foto']);

        $kandidat[] = "../../" . ltrim($foto_db, "/\\");
        $kandidat[] = $foto_db;
    }

    $kandidat[] = "../../assets/images/siswa/" . $id . ".jpg";
    $kandidat[] = "../../assets/images/siswa/" . $id . ".jpeg";
    $kandidat[] = "../../assets/images/siswa/" . $id . ".png";
    $kandidat[] = "../../assets/images/siswa/" . $id . ".webp";

    foreach ($kandidat as $path) {
        $full = __DIR__ . DIRECTORY_SEPARATOR . str_replace("/", DIRECTORY_SEPARATOR, $path);

        /* Normalisasi path yang dibuat relatif di atas */
        $real = realpath($full);
        if ($real && is_file($real)) {
            $relative = str_replace(DIRECTORY_SEPARATOR, "/", substr($real, strlen(realpath(__DIR__ . "/../.."))));
            return "../../" . ltrim($relative, "/");
        }
    }

    return "";
}

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>

<style>
.kartu-page{max-width:1450px}
.page-head{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:24px}
.page-head h1{margin:0 0 6px}.page-head p{margin:0}
.card{background:#fff;border-radius:18px;box-shadow:0 8px 25px rgba(15,35,70,.07);padding:20px;margin-bottom:20px}
.filters{display:grid;grid-template-columns:2fr 1fr auto;gap:14px;align-items:end}
label{display:block;font-size:13px;font-weight:600;color:#334155;margin-bottom:7px}
.fc{width:100%;height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:0 11px;background:#fff;outline:none}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;border:0;border-radius:10px;padding:11px 16px;font-weight:600;text-decoration:none;cursor:pointer}
.pri{background:linear-gradient(135deg,#2388f5,#1265dc);color:#fff;box-shadow:0 8px 18px rgba(18,101,220,.18)}
.sec{background:#eef3f9;color:#334155}
.count{font-size:14px;color:#64748b;margin-bottom:12px}
.note{padding:12px 14px;background:#eef6ff;border:1px solid #d8e8fb;color:#245c9b;border-radius:10px;font-size:13px;margin-bottom:15px}
.print-area{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px}
.id-card{position:relative;width:100%;aspect-ratio:551 / 870;overflow:hidden;background:#fff url('../../assets/images/template_kartu_absensi.png') center/cover no-repeat;border-radius:14px;box-shadow:0 6px 18px rgba(15,35,70,.10);break-inside:avoid}
.photo-wrap{position:absolute;left:29.2%;top:24.6%;width:41.6%;aspect-ratio:1;border-radius:50%;background:#fff;border:4px solid rgba(255,255,255,.95);overflow:hidden;box-shadow:0 3px 14px rgba(0,0,0,.18);display:flex;align-items:center;justify-content:center}
.photo-wrap img{width:100%;height:100%;object-fit:contain;display:block;background:#fff}
.photo-empty{width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:#aab4bf;font-size:38px;font-weight:700}
.student-name{position:absolute;left:8%;right:8%;top:53.0%;text-align:center;font-size:clamp(11px,1.45vw,20px);line-height:1.05;font-weight:800;color:#111827;text-transform:uppercase}
.student-meta{position:absolute;left:9%;right:9%;top:57.2%;text-align:center;font-size:clamp(7px,.9vw,12px);line-height:1.35;font-weight:700;color:#374151}
.qr-box{position:absolute;width:31%;aspect-ratio:1;left:34.5%;bottom:6.4%;background:#fff;border-radius:6px;padding:2%;box-shadow:0 2px 8px rgba(0,0,0,.12)}
.qr-box img{width:100%;height:100%;display:block}
.qr-label{position:absolute;left:25%;right:25%;bottom:2.9%;text-align:center;font-size:clamp(5px,.55vw,8px);font-weight:700;color:#374151}
.one-print{position:absolute;top:10px;right:10px;z-index:5;border:1px solid rgba(255,255,255,.5);background:rgba(0,0,0,.35);color:#fff;border-radius:8px;padding:6px 9px;cursor:pointer;font-size:11px}
.empty{text-align:center;color:#94a3b8;padding:55px 15px}
@media(max-width:1000px){.filters{grid-template-columns:1fr 1fr}.print-area{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:600px){.filters,.print-area{grid-template-columns:1fr}.page-head{align-items:flex-start;flex-direction:column}}
@media print{
 @page{size:A4 portrait;margin:6mm}
 html,body{background:#fff!important;margin:0!important;padding:0!important}
 .sidebar,.page-head,.filter-card,.no-print,.count,.note{display:none!important}
 .main-content{margin:0!important;padding:0!important}
 .kartu-page{max-width:none!important}
 .card{margin:0!important;padding:0!important;box-shadow:none!important;border-radius:0!important;background:transparent!important}
 .print-area{display:grid!important;grid-template-columns:repeat(3,1fr)!important;gap:4mm!important}
 .id-card{width:100%!important;aspect-ratio:551/870!important;border-radius:0!important;box-shadow:none!important;-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}
 .one-print{display:none!important}
}
</style>

<main class="main-content">
<div class="kartu-page">

<div class="page-head">
<div>
<h1>Cetak Kartu Absensi</h1>
<p>Template portrait SDN CIBURAYUT 01 dengan foto siswa dan QR Code.</p>
</div>
<button type="button" class="btn pri no-print" onclick="window.print()">🖨️ Cetak Semua</button>
</div>

<div class="card filter-card no-print">
<form method="get">
<div class="filters">
<div>
<label>Cari Siswa</label>
<input class="fc" type="text" name="cari" value="<?=h($cari)?>" placeholder="Nama, NIS, atau NISN...">
</div>
<div>
<label>Kelas</label>
<select class="fc" name="id_kelas">
<option value="0">Semua Kelas</option>
<?php foreach($kelas as $k): ?>
<option value="<?=$k['id_kelas']?>" <?=$id_kelas===(int)$k['id_kelas']?'selected':''?>>Kelas <?=h($k['nama_kelas'])?></option>
<?php endforeach;?>
</select>
</div>
<div style="display:flex;gap:8px">
<button class="btn pri">🔎 Tampilkan</button>
<a class="btn sec" href="cetak_kartu.php">Reset</a>
</div>
</div>
</form>
</div>

<div class="note no-print">
📸 Foto siswa akan diambil dari kolom <strong>foto</strong> pada tabel siswa. Bila kolom tersebut belum ada, sistem juga mencari file foto berdasarkan ID siswa di
<strong>assets/images/siswa/</strong> dengan format JPG, JPEG, PNG, atau WEBP.
</div>

<div class="count no-print">
🎫 <strong><?=count($daftar)?></strong> kartu siswa tersedia
</div>

<div class="card">
<?php if($daftar): ?>

<div class="print-area">

<?php foreach($daftar as $s): ?>
<?php
$foto = cari_foto_siswa($s);

$qr_data = 'SDN-CIBURAYUT-01|ID:' . (int)$s['id_siswa'] .
           '|NISN:' . ($s['nisn'] ?: '-') .
           '|NAMA:' . $s['nama_siswa'] .
           '|KELAS:' . ($s['nama_kelas'] ?: '-');

$qr_url = 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&margin=0&data=' . rawurlencode($qr_data);
?>

<div class="id-card">

<div class="one-print no-print" onclick="printOne(this)">🖨️ Cetak</div>

<div class="photo-wrap">
<?php if($foto): ?>
<img src="<?=h($foto)?>" alt="Foto <?=h($s['nama_siswa'])?>">
<?php else: ?>
<div class="photo-empty">👤</div>
<?php endif; ?>
</div>

<div class="student-name"><?=h($s['nama_siswa'])?></div>

<div class="student-meta">
NISN: <?=h($s['nisn'] ?: '-')?>
</div>

<div class="qr-box">
<img src="<?=h($qr_url)?>" alt="QR Code <?=h($s['nama_siswa'])?>">
</div>

<div class="qr-label">SCAN UNTUK IDENTITAS SISWA</div>

</div>

<?php endforeach; ?>

</div>

<?php else: ?>
<div class="empty">Tidak ada siswa aktif yang sesuai dengan filter.</div>
<?php endif; ?>
</div>

</div>
</main>

<script>
function printOne(button){
    const cards=document.querySelectorAll('.id-card');
    const target=button.closest('.id-card');
    cards.forEach(function(card){
        if(card!==target) card.style.display='none';
    });
    window.print();
    cards.forEach(function(card){
        card.style.display='';
    });
}
</script>

</body>
</html>
