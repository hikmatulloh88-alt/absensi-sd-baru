<?php
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator', 'Guru');
require_once "../../config/database.php";

$menu_aktif = 'absensi_siswa';
$page_title = 'Riwayat Absensi Siswa - SDN Ciburayut 01';

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$cols = [];
$qcols = mysqli_query($koneksi, "SHOW COLUMNS FROM absensi_siswa");
if ($qcols) { while ($c = mysqli_fetch_assoc($qcols)) $cols[] = $c['Field']; }
$has = function($f) use (&$cols) { return in_array($f, $cols, true); };
$primary_key = in_array('id_absensi_siswa', $cols, true) ? 'id_absensi_siswa' : (in_array('id_absensi', $cols, true) ? 'id_absensi' : (in_array('id', $cols, true) ? 'id' : ''));

$hari_map = [1=>'Senin',2=>'Selasa',3=>'Rabu',4=>'Kamis',5=>'Jumat',6=>'Sabtu',7=>'Minggu'];

/* ============ TEMPLATE CSV (download) ============ */
if (($_GET['aksi'] ?? '') === 'template_csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="template_absensi.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['NISN', 'Nama Siswa', 'Tanggal (YYYY-MM-DD)', 'Status (Hadir/Sakit/Izin/Alpa)', 'Keterangan']);
    fputcsv($out, ['0012345678', 'Contoh Nama Siswa', date('Y-m-d'), 'Hadir', 'Contoh keterangan']);
    fclose($out);
    exit;
}

$today = date('Y-m-d');
$tanggal_awal = $_GET['tanggal_awal'] ?? $today;
$tanggal_akhir = $_GET['tanggal_akhir'] ?? $today;
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal_awal)) $tanggal_awal = $today;
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal_akhir)) $tanggal_akhir = $today;
if ($tanggal_awal > $tanggal_akhir) { $tmp = $tanggal_awal; $tanggal_awal = $tanggal_akhir; $tanggal_akhir = $tmp; }

$id_kelas = (int)($_GET['id_kelas'] ?? 0);
$status_filter = $_GET['status'] ?? 'Semua';
if (!in_array($status_filter, ['Semua','Hadir','Sakit','Izin','Alpa'], true)) $status_filter = 'Semua';
$cari = trim((string)($_GET['cari'] ?? ''));

$pesan = ''; $tipe = '';
$query_string_filter = http_build_query([
    'tanggal_awal'=>$tanggal_awal,'tanggal_akhir'=>$tanggal_akhir,
    'id_kelas'=>$id_kelas,'status'=>$status_filter,'cari'=>$cari
]);

/* ============ AKSI AJAX: EDIT SATU BARIS ============ */
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['aksi']??'')==='edit_satu' && $primary_key!=='') {
    header('Content-Type: application/json; charset=utf-8');
    $id = (int)($_POST['id'] ?? 0);
    $status_baru = trim((string)($_POST['status'] ?? ''));
    $ket_baru = trim((string)($_POST['keterangan'] ?? ''));
    if (!in_array($status_baru, ['Hadir','Sakit','Izin','Alpa'], true)) {
        echo json_encode(['ok'=>false,'message'=>'Status tidak valid.']); exit;
    }
    $set = ["`status`=?"]; $vals=[$status_baru]; $types='s';
    if ($has('keterangan')) { $set[]="`keterangan`=?"; $vals[]=($ket_baru===''?null:$ket_baru); $types.='s'; }
    $vals[]=$id; $types.='i';
    $u = mysqli_prepare($koneksi, "UPDATE absensi_siswa SET ".implode(',',$set)." WHERE `$primary_key`=?");
    if ($u) {
        mysqli_stmt_bind_param($u,$types,...$vals);
        if (mysqli_stmt_execute($u)) { echo json_encode(['ok'=>true,'message'=>'Tersimpan.']); exit; }
    }
    echo json_encode(['ok'=>false,'message'=>'Gagal menyimpan perubahan.']); exit;
}

/* ============ AKSI AJAX: HAPUS SATU BARIS ============ */
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['aksi']??'')==='hapus_satu' && $primary_key!=='') {
    header('Content-Type: application/json; charset=utf-8');
    $id = (int)($_POST['id'] ?? 0);
    $d = mysqli_prepare($koneksi, "DELETE FROM absensi_siswa WHERE `$primary_key`=?");
    if ($d) { mysqli_stmt_bind_param($d,'i',$id); if (mysqli_stmt_execute($d)) { echo json_encode(['ok'=>true]); exit; } }
    echo json_encode(['ok'=>false,'message'=>'Gagal menghapus data.']); exit;
}

/* ============ AKSI: HAPUS MASSAL ============ */
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['aksi']??'')==='hapus_massal' && $primary_key!=='') {
    $ids = array_filter(array_map('intval', $_POST['ids'] ?? []));
    if ($ids) {
        $marks = implode(',', array_fill(0, count($ids), '?'));
        $types = str_repeat('i', count($ids));
        $d = mysqli_prepare($koneksi, "DELETE FROM absensi_siswa WHERE `$primary_key` IN ($marks)");
        if ($d) {
            mysqli_stmt_bind_param($d, $types, ...$ids);
            mysqli_stmt_execute($d);
            $pesan = count($ids).' data absensi berhasil dihapus.'; $tipe='success';
        }
    } else { $pesan='Tidak ada baris yang dipilih.'; $tipe='error'; }
}

/* ============ AKSI: UBAH KETERANGAN MASSAL ============ */
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['aksi']??'')==='ubah_keterangan_massal' && $primary_key!=='' && $has('keterangan')) {
    $ids = array_filter(array_map('intval', $_POST['ids'] ?? []));
    $ket_baru = trim((string)($_POST['keterangan_baru'] ?? ''));
    if ($ids) {
        $marks = implode(',', array_fill(0, count($ids), '?'));
        $types = 's' . str_repeat('i', count($ids));
        $vals = array_merge([$ket_baru===''?null:$ket_baru], $ids);
        $u = mysqli_prepare($koneksi, "UPDATE absensi_siswa SET `keterangan`=? WHERE `$primary_key` IN ($marks)");
        if ($u) {
            mysqli_stmt_bind_param($u, $types, ...$vals);
            mysqli_stmt_execute($u);
            $pesan = 'Keterangan '.count($ids).' data berhasil diperbarui.'; $tipe='success';
        }
    } else { $pesan='Tidak ada baris yang dipilih.'; $tipe='error'; }
}

/* ============ AKSI: UPLOAD CSV ============ */
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['aksi']??'')==='upload_csv') {
    if (empty($_FILES['file_csv']['tmp_name']) || $_FILES['file_csv']['error'] !== UPLOAD_ERR_OK) {
        $pesan = 'File CSV belum dipilih atau gagal diunggah.'; $tipe='error';
    } else {
        $fh = fopen($_FILES['file_csv']['tmp_name'], 'r');
        if (!$fh) {
            $pesan = 'File CSV tidak dapat dibaca.'; $tipe='error';
        } else {
            $header = fgetcsv($fh);
            $baris = 0; $berhasil = 0; $gagal = [];
            while (($row = fgetcsv($fh)) !== false) {
                $baris++;
                if (count(array_filter($row, fn($v)=>trim((string)$v)!=='')) === 0) continue;
                $nisn = trim((string)($row[0] ?? ''));
                $nama_csv = trim((string)($row[1] ?? ''));
                $tgl = trim((string)($row[2] ?? ''));
                $status_csv = trim((string)($row[3] ?? ''));
                $ket_csv = trim((string)($row[4] ?? ''));

                if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tgl)) { $gagal[]="Baris $baris: tanggal tidak valid ($tgl)"; continue; }
                $status_csv = ucfirst(strtolower($status_csv));
                if (!in_array($status_csv, ['Hadir','Sakit','Izin','Alpa'], true)) { $gagal[]="Baris $baris: status tidak valid ($status_csv)"; continue; }

                $siswa_row = null;
                if ($nisn !== '') {
                    $q = mysqli_prepare($koneksi, "SELECT id_siswa,id_kelas FROM siswa WHERE nisn=? LIMIT 1");
                    mysqli_stmt_bind_param($q,'s',$nisn);
                    mysqli_stmt_execute($q);
                    $siswa_row = mysqli_fetch_assoc(mysqli_stmt_get_result($q));
                }
                if (!$siswa_row && $nama_csv !== '') {
                    $q = mysqli_prepare($koneksi, "SELECT id_siswa,id_kelas FROM siswa WHERE nama_siswa=? LIMIT 1");
                    mysqli_stmt_bind_param($q,'s',$nama_csv);
                    mysqli_stmt_execute($q);
                    $siswa_row = mysqli_fetch_assoc(mysqli_stmt_get_result($q));
                }
                if (!$siswa_row) { $gagal[]="Baris $baris: siswa \"$nisn $nama_csv\" tidak ditemukan"; continue; }

                $sid = (int)$siswa_row['id_siswa'];
                $kelas_sid = (int)($siswa_row['id_kelas'] ?? 0);

                $old=null;
                $sqlc="SELECT * FROM absensi_siswa WHERE id_siswa=? AND tanggal=?"; $tc='is'; $vc=[$sid,$tgl];
                $sc=mysqli_prepare($koneksi,$sqlc);
                mysqli_stmt_bind_param($sc,$tc,...$vc); mysqli_stmt_execute($sc);
                $old = mysqli_fetch_assoc(mysqli_stmt_get_result($sc));

                if ($old) {
                    $set=["`status`=?"]; $vals=[$status_csv]; $types='s';
                    if ($has('keterangan')) { $set[]="`keterangan`=?"; $vals[]=($ket_csv===''?'Import CSV':$ket_csv); $types.='s'; }
                    $vals[]=(int)$old[$primary_key]; $types.='i';
                    $u=mysqli_prepare($koneksi,"UPDATE absensi_siswa SET ".implode(',',$set)." WHERE `$primary_key`=?");
                    mysqli_stmt_bind_param($u,$types,...$vals);
                    if (mysqli_stmt_execute($u)) $berhasil++; else $gagal[]="Baris $baris: gagal memperbarui";
                } else {
                    $fields=['id_siswa','tanggal','status']; $vals=[$sid,$tgl,$status_csv]; $types='iss';
                    if ($has('id_kelas')) { $fields[]='id_kelas'; $vals[]=$kelas_sid; $types.='i'; }
                    if ($has('keterangan')) { $fields[]='keterangan'; $vals[]=($ket_csv===''?'Import CSV':$ket_csv); $types.='s'; }
                    $marks=implode(',',array_fill(0,count($fields),'?'));
                    $f='`'.implode('`,`',$fields).'`';
                    $i=mysqli_prepare($koneksi,"INSERT INTO absensi_siswa ($f) VALUES ($marks)");
                    mysqli_stmt_bind_param($i,$types,...$vals);
                    if (mysqli_stmt_execute($i)) $berhasil++; else $gagal[]="Baris $baris: gagal menyimpan";
                }
            }
            fclose($fh);
            $pesan = "$berhasil data absensi berhasil diimpor dari CSV.";
            if ($gagal) $pesan .= ' '.count($gagal).' baris gagal: '.implode(' | ', array_slice($gagal,0,5)).(count($gagal)>5?' ...':'');
            $tipe = $berhasil>0 ? 'success' : 'error';
        }
    }
}

/* ============ KELAS ============ */
$kelas=[];
$q=mysqli_query($koneksi,"SELECT id_kelas,nama_kelas,tingkat FROM kelas ORDER BY tingkat,nama_kelas");
if($q) while($r=mysqli_fetch_assoc($q)) $kelas[]=$r;

/* ============ AMBIL DATA RIWAYAT ============ */
$data=[];
if ($has('id_siswa') && $has('tanggal') && $has('status')) {
    $sql = "SELECT a.*, s.nama_siswa, s.nis, s.nisn, k.nama_kelas
            FROM absensi_siswa a
            LEFT JOIN siswa s ON s.id_siswa=a.id_siswa
            LEFT JOIN kelas k ON k.id_kelas=".($has('id_kelas')?'a.id_kelas':'s.id_kelas')."
            WHERE a.tanggal BETWEEN ? AND ?";
    $types='ss'; $vals=[$tanggal_awal,$tanggal_akhir];

    if ($id_kelas>0) {
        $sql .= $has('id_kelas') ? " AND a.id_kelas=?" : " AND s.id_kelas=?";
        $types.='i'; $vals[]=$id_kelas;
    }
    if ($status_filter!=='Semua') { $sql.=" AND a.status=?"; $types.='s'; $vals[]=$status_filter; }
    if ($cari!=='') { $sql.=" AND s.nama_siswa LIKE ?"; $types.='s'; $vals[]='%'.$cari.'%'; }

    $sql .= " ORDER BY a.tanggal DESC, s.nama_siswa ASC LIMIT 500";

    $st = mysqli_prepare($koneksi, $sql);
    if ($st) {
        mysqli_stmt_bind_param($st,$types,...$vals);
        mysqli_stmt_execute($st);
        $rs = mysqli_stmt_get_result($st);
        if ($rs) while($r=mysqli_fetch_assoc($rs)) $data[]=$r;
    }
}

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>
<style>
.rw{max-width:1500px}.ph{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}.ph h1{margin:0 0 6px}.ph p{margin:0}
.card{background:#fff;border-radius:18px;box-shadow:0 8px 25px rgba(15,35,70,.07);padding:20px;margin-bottom:20px}
.filters{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
label{display:block;font-size:13px;font-weight:600;color:#334155;margin-bottom:7px}.fc{width:100%;height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:0 11px;background:#fff}
.btn{display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:10px;padding:10px 15px;font-weight:600;text-decoration:none;cursor:pointer;font-size:13px}
.pri{background:linear-gradient(135deg,#2388f5,#1265dc);color:#fff}.sec{background:#eef3f9;color:#334155}.dan{background:#fef2f2;color:#b91c1c}.warn{background:#fffbeb;color:#92400e}.ok2{background:#ecfdf5;color:#047857}
.alert{padding:13px 15px;border-radius:11px;margin-bottom:18px;font-size:14px;line-height:1.5}.ok{background:#ecfdf3;color:#18794e;border:1px solid #ccefdc}.er{background:#fff1f2;color:#be123c;border:1px solid #fecdd3}
.toolbar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:14px}
.tabs{display:flex;gap:8px;flex-wrap:wrap}.tab{padding:8px 14px;border-radius:9px;background:#eef3f9;color:#475569;text-decoration:none;font-size:13px;font-weight:600}.tab.active{background:#2388f5;color:#fff}
.searchbox{margin-left:auto;min-width:230px}
.tw{overflow-x:auto}.dt{width:100%;border-collapse:collapse;min-width:1050px}.dt th{background:#f7f9fc;color:#64748b;font-size:12px;text-transform:uppercase;padding:11px;text-align:left}.dt td{padding:10px 11px;border-bottom:1px solid #edf1f6;font-size:14px}
.nm{font-weight:700;color:#17233c}.sub{font-size:12px;color:#94a3b8;margin-top:2px}
.badge{padding:4px 10px;border-radius:20px;font-size:12px;font-weight:700}.b-hadir{background:#dcfce7;color:#166534}.b-sakit{background:#fef9c3;color:#854d0e}.b-izin{background:#dbeafe;color:#1e40af}.b-alpa{background:#fee2e2;color:#991b1b}
.icon-btn{border:0;background:#f1f5f9;border-radius:8px;width:32px;height:32px;cursor:pointer;margin-right:4px}
@media print{.no-print{display:none !important}.card{box-shadow:none;padding:0}}
@media(max-width:1000px){.filters{grid-template-columns:1fr 1fr}}@media(max-width:600px){.filters{grid-template-columns:1fr}.ph{align-items:flex-start;flex-direction:column;gap:10px}.searchbox{margin-left:0;width:100%}}
</style>

<main class="main-content"><div class="rw">
<div class="ph no-print"><div><h1>Riwayat Absensi Siswa</h1><p>Daftar per catatan kehadiran, bisa dicari, diedit, dihapus, dan diimpor massal.</p></div></div>

<?php if($pesan): ?><div class="alert <?=$tipe==='success'?'ok':'er'?> no-print"><?=h($pesan)?></div><?php endif; ?>

<div class="card no-print">
<form method="get">
<div class="filters">
<div><label>Tanggal Awal</label><input class="fc" type="date" name="tanggal_awal" value="<?=h($tanggal_awal)?>"></div>
<div><label>Tanggal Akhir</label><input class="fc" type="date" name="tanggal_akhir" value="<?=h($tanggal_akhir)?>"></div>
<div><label>Kelas</label><select class="fc" name="id_kelas"><option value="0">Semua Kelas</option><?php foreach($kelas as $k):?><option value="<?=$k['id_kelas']?>" <?=$id_kelas===(int)$k['id_kelas']?'selected':''?>>Kelas <?=h($k['nama_kelas'])?></option><?php endforeach;?></select></div>
<div><label>&nbsp;</label><button class="btn pri" style="width:100%;height:42px">🔎 Tampilkan</button></div>
</div>
<input type="hidden" name="status" value="<?=h($status_filter)?>">
<input type="hidden" name="cari" value="<?=h($cari)?>">
</form>
</div>

<div class="card no-print">
<div class="toolbar">
<div class="tabs">
<?php foreach(['Semua','Hadir','Sakit','Izin','Alpa'] as $tb): ?>
<a class="tab <?=$status_filter===$tb?'active':''?>" href="?<?=http_build_query(['tanggal_awal'=>$tanggal_awal,'tanggal_akhir'=>$tanggal_akhir,'id_kelas'=>$id_kelas,'status'=>$tb,'cari'=>$cari])?>"><?=$tb?></a>
<?php endforeach; ?>
</div>
<form method="get" class="searchbox" style="display:flex;gap:6px;">
<input type="hidden" name="tanggal_awal" value="<?=h($tanggal_awal)?>"><input type="hidden" name="tanggal_akhir" value="<?=h($tanggal_akhir)?>">
<input type="hidden" name="id_kelas" value="<?=$id_kelas?>"><input type="hidden" name="status" value="<?=h($status_filter)?>">
<input class="fc" style="height:38px" type="text" name="cari" value="<?=h($cari)?>" placeholder="Cari nama siswa...">
<button class="btn sec" style="height:38px">Cari</button>
</form>
</div>

<div class="toolbar">
<a class="btn sec" href="?aksi=template_csv">⬇️ Template CSV</a>
<form method="post" enctype="multipart/form-data" style="display:flex;gap:6px;align-items:center">
<input type="hidden" name="aksi" value="upload_csv">
<input type="file" name="file_csv" accept=".csv" required>
<button class="btn pri">⬆️ Upload CSV</button>
</form>
<button class="btn dan" type="button" id="btnHapusMassal">🗑️ Hapus Terpilih</button>
<button class="btn warn" type="button" id="btnKetMassal">✏️ Ubah Keterangan Terpilih</button>
<button class="btn sec" type="button" onclick="window.print()">🖨️ Cetak</button>
</div>

<form method="post" id="formMassal">
<input type="hidden" name="aksi" id="aksiMassal" value="hapus_massal">
<input type="hidden" name="keterangan_baru" id="ketBaruInput" value="">
<div class="tw"><table class="dt">
<thead><tr>
<th style="width:30px"><input type="checkbox" id="chkAll"></th>
<th>No</th><th>Tanggal</th><th>Hari</th><th>Nama Siswa</th><th>Kelas</th><th>Status</th><?php if($has('keterangan')):?><th>Keterangan</th><?php endif;?><?php if($has('jam_masuk')):?><th>Jam Masuk</th><?php endif;?><th class="no-print">Aksi</th>
</tr></thead>
<tbody>
<?php if($data): $no=1; foreach($data as $d):
    $idrow = $primary_key!=='' ? (int)$d[$primary_key] : 0;
    $st = $d['status'] ?? '-';
    $badgeClass = ['Hadir'=>'b-hadir','Sakit'=>'b-sakit','Izin'=>'b-izin','Alpa'=>'b-alpa'][$st] ?? '';
    $hariNama = $hari_map[(int)date('N', strtotime($d['tanggal']))] ?? '-';
?>
<tr data-id="<?=$idrow?>">
<td class="no-print"><input type="checkbox" class="chkRow" name="ids[]" value="<?=$idrow?>"></td>
<td><?=$no++?></td>
<td><?=h(date('d/m/Y', strtotime($d['tanggal'])))?></td>
<td><?=h($hariNama)?></td>
<td><div class="nm"><?=h($d['nama_siswa']??'-')?></div><div class="sub">NISN: <?=h($d['nisn']?:'-')?></div></td>
<td><?=h($d['nama_kelas']?:'-')?></td>
<td class="cell-status"><span class="badge <?=$badgeClass?>"><?=h($st)?></span></td>
<?php if($has('keterangan')):?><td class="cell-ket"><?=h($d['keterangan']??'-')?></td><?php endif;?>
<?php if($has('jam_masuk')):?><td><?=h($d['jam_masuk']??'-')?></td><?php endif;?>
<td class="no-print">
<button type="button" class="icon-btn btnEdit" title="Edit">✏️</button>
<button type="button" class="icon-btn btnHapus" title="Hapus">🗑️</button>
</td>
</tr>
<?php endforeach; else: ?>
<tr><td colspan="10" style="text-align:center;padding:40px;color:#94a3b8">Tidak ada data absensi pada filter ini.</td></tr>
<?php endif; ?>
</tbody>
</table></div>
</form>
<?php if(count($data)>=500): ?><div class="sub" style="margin-top:10px">Menampilkan 500 data teratas. Persempit rentang tanggal untuk melihat semua data.</div><?php endif; ?>
</div>
</div></main>

<script>
document.addEventListener('DOMContentLoaded', function(){
    const chkAll = document.getElementById('chkAll');
    const form = document.getElementById('formMassal');
    const aksiInput = document.getElementById('aksiMassal');
    const ketInput = document.getElementById('ketBaruInput');

    chkAll?.addEventListener('change', function(){
        document.querySelectorAll('.chkRow').forEach(c => c.checked = chkAll.checked);
    });

    document.getElementById('btnHapusMassal')?.addEventListener('click', function(){
        const checked = document.querySelectorAll('.chkRow:checked');
        if (!checked.length) { alert('Pilih minimal satu baris dulu.'); return; }
        if (!confirm('Hapus ' + checked.length + ' data absensi terpilih?')) return;
        aksiInput.value = 'hapus_massal';
        form.submit();
    });

    document.getElementById('btnKetMassal')?.addEventListener('click', function(){
        const checked = document.querySelectorAll('.chkRow:checked');
        if (!checked.length) { alert('Pilih minimal satu baris dulu.'); return; }
        const teks = prompt('Ketik keterangan baru untuk ' + checked.length + ' data terpilih:', '');
        if (teks === null) return;
        aksiInput.value = 'ubah_keterangan_massal';
        ketInput.value = teks;
        form.submit();
    });

    document.querySelectorAll('.btnHapus').forEach(btn=>{
        btn.addEventListener('click', async function(){
            const tr = btn.closest('tr');
            const id = tr.dataset.id;
            if (!confirm('Hapus data absensi baris ini?')) return;
            const body = new URLSearchParams(); body.set('aksi','hapus_satu'); body.set('id', id);
            const res = await fetch(window.location.pathname, {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body});
            const data = await res.json();
            if (data.ok) tr.remove(); else alert(data.message || 'Gagal menghapus.');
        });
    });

    document.querySelectorAll('.btnEdit').forEach(btn=>{
        btn.addEventListener('click', async function(){
            const tr = btn.closest('tr');
            const id = tr.dataset.id;
            const statusLama = tr.querySelector('.cell-status .badge')?.textContent.trim() || 'Hadir';
            const ketCell = tr.querySelector('.cell-ket');
            const ketLama = ketCell ? (ketCell.textContent.trim()==='-' ? '' : ketCell.textContent.trim()) : '';

            const statusBaru = prompt('Status (Hadir/Sakit/Izin/Alpa):', statusLama);
            if (statusBaru === null) return;
            let ketBaru = ketLama;
            if (ketCell) {
                const k = prompt('Keterangan:', ketLama);
                if (k !== null) ketBaru = k;
            }

            const body = new URLSearchParams();
            body.set('aksi','edit_satu'); body.set('id', id); body.set('status', statusBaru.trim()); body.set('keterangan', ketBaru);
            const res = await fetch(window.location.pathname, {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body});
            const data = await res.json();
            if (data.ok) location.reload(); else alert(data.message || 'Gagal menyimpan.');
        });
    });
});
</script>
</body></html>
