<?php
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator', 'Guru');
require_once "../../config/database.php";

$menu_aktif = 'absensi_siswa';
$page_title = 'Scan QR Kehadiran - SDN Ciburayut 01';

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function has_column($db, $table, $column){
    static $cache = [];
    $key = $table . '.' . $column;
    if (isset($cache[$key])) return $cache[$key];
    $safeTable = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    $safeColumn = preg_replace('/[^a-zA-Z0-9_]/', '', $column);
    $q = mysqli_query($db, "SHOW COLUMNS FROM `{$safeTable}` LIKE '" . mysqli_real_escape_string($db, $safeColumn) . "'");
    return $cache[$key] = ($q && mysqli_num_rows($q) > 0);
}

function json_response($ok, $message, $extra = []){
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array_merge(['ok'=>$ok, 'message'=>$message], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}

/*
 * AJAX: input manual (tanpa scan QR). Dipakai saat kartu hilang/rusak
 * atau kamera tidak tersedia. Menyimpan status apapun (Hadir/Sakit/Izin/Alpa),
 * bukan cuma Hadir seperti hasil scan QR.
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'manual_absen') {
    $id_siswa = (int)($_POST['id_siswa'] ?? 0);
    $status_manual = trim((string)($_POST['status'] ?? 'Hadir'));
    if (!in_array($status_manual, ['Hadir','Sakit','Izin','Alpa'], true)) {
        json_response(false, 'Status tidak valid.');
    }
    if ($id_siswa <= 0) json_response(false, 'Siswa belum dipilih.');

    $q = mysqli_prepare($koneksi, "SELECT s.id_siswa, s.nisn, s.nama_siswa, s.id_kelas, s.status_siswa, k.nama_kelas FROM siswa s LEFT JOIN kelas k ON k.id_kelas=s.id_kelas WHERE s.id_siswa=? LIMIT 1");
    mysqli_stmt_bind_param($q, 'i', $id_siswa);
    mysqli_stmt_execute($q);
    $siswa = mysqli_fetch_assoc(mysqli_stmt_get_result($q));
    if (!$siswa) json_response(false, 'Siswa dengan ID tersebut tidak ditemukan.');
    if ((int)($siswa['id_kelas'] ?? 0) <= 0) json_response(false, 'Siswa ' . $siswa['nama_siswa'] . ' belum memiliki kelas.');

    $today = date('Y-m-d'); $now = date('H:i:s');
    $has_kelas = has_column($koneksi, 'absensi_siswa', 'id_kelas');
    $has_ket = has_column($koneksi, 'absensi_siswa', 'keterangan');
    $has_jam = has_column($koneksi, 'absensi_siswa', 'jam_masuk');
    $has_waktu = has_column($koneksi, 'absensi_siswa', 'waktu_absen');
    $id_tahun = 0;
    if (has_column($koneksi, 'absensi_siswa', 'id_tahun_ajaran')) {
        $qy = mysqli_query($koneksi, "SELECT id_tahun_ajaran FROM tahun_ajaran WHERE aktif=1 ORDER BY id_tahun_ajaran DESC LIMIT 1");
        $tahun = $qy ? mysqli_fetch_assoc($qy) : null;
        $id_tahun = (int)($tahun['id_tahun_ajaran'] ?? 0);
    }

    $sql = "SELECT * FROM absensi_siswa WHERE id_siswa=? AND tanggal=?"; $types='is'; $vals=[$id_siswa,$today];
    if (has_column($koneksi, 'absensi_siswa', 'id_tahun_ajaran')) { $sql.=" AND id_tahun_ajaran=?"; $types.='i'; $vals[]=$id_tahun; }
    $cek = mysqli_prepare($koneksi, $sql);
    mysqli_stmt_bind_param($cek, $types, ...$vals);
    mysqli_stmt_execute($cek);
    $old = mysqli_fetch_assoc(mysqli_stmt_get_result($cek));

    if ($old) {
        // Skema bootstrap memakai id_absensi; dua nama lain didukung untuk
        // database lama agar input kedua pada hari yang sama dapat diubah.
        $primary = isset($old['id_absensi_siswa']) ? 'id_absensi_siswa' : (isset($old['id_absensi']) ? 'id_absensi' : (isset($old['id']) ? 'id' : ''));
        if ($primary==='') json_response(false, 'Primary key tabel absensi_siswa tidak dikenali.');
        $set=["`status`=?"]; $uvals=[$status_manual]; $utypes='s';
        if ($has_kelas) { $set[]="`id_kelas`=?"; $uvals[]=(int)$siswa['id_kelas']; $utypes.='i'; }
        if ($has_ket) { $set[]="`keterangan`=?"; $uvals[]='Input Manual'; $utypes.='s'; }
        if ($has_jam) { $set[]="`jam_masuk`=?"; $uvals[]=$now; $utypes.='s'; }
        if ($has_waktu) { $set[]="`waktu_absen`=?"; $uvals[]=date('Y-m-d H:i:s'); $utypes.='s'; }
        $uvals[]=(int)$old[$primary]; $utypes.='i';
        $u = mysqli_prepare($koneksi, "UPDATE absensi_siswa SET ".implode(',',$set)." WHERE `$primary`=?");
        mysqli_stmt_bind_param($u,$utypes,...$uvals);
        if (!mysqli_stmt_execute($u)) json_response(false, 'Gagal memperbarui absensi.');
        json_response(true, 'Absensi diperbarui.', ['duplicate'=>true,'siswa'=>$siswa['nama_siswa'],'kelas'=>$siswa['nama_kelas']??'-','jam'=>$now,'status'=>$status_manual]);
    }

    $fields=['id_siswa','tanggal','status']; $ivals=[$id_siswa,$today,$status_manual]; $itypes='iss';
    if ($has_kelas) { $fields[]='id_kelas'; $ivals[]=(int)$siswa['id_kelas']; $itypes.='i'; }
    if (has_column($koneksi, 'absensi_siswa', 'id_tahun_ajaran')) { $fields[]='id_tahun_ajaran'; $ivals[]=$id_tahun; $itypes.='i'; }
    if ($has_ket) { $fields[]='keterangan'; $ivals[]='Input Manual'; $itypes.='s'; }
    if ($has_jam) { $fields[]='jam_masuk'; $ivals[]=$now; $itypes.='s'; }
    if ($has_waktu) { $fields[]='waktu_absen'; $ivals[]=date('Y-m-d H:i:s'); $itypes.='s'; }
    $marks=implode(',',array_fill(0,count($fields),'?')); $quoted='`'.implode('`,`',$fields).'`';
    $ins = mysqli_prepare($koneksi, "INSERT INTO absensi_siswa ($quoted) VALUES ($marks)");
    mysqli_stmt_bind_param($ins,$itypes,...$ivals);
    if (!mysqli_stmt_execute($ins)) json_response(false, 'Gagal menyimpan absensi.');
    json_response(true, 'Kehadiran manual berhasil dicatat.', ['duplicate'=>false,'siswa'=>$siswa['nama_siswa'],'kelas'=>$siswa['nama_kelas']??'-','jam'=>$now,'status'=>$status_manual]);
}

/*
 * AJAX: simpan hasil scan QR.
 * Mendukung format QR kartu saat ini:
 * SDN-CIBURAYUT-01|ID:{id}|NISN:...|NAMA:...|KELAS:...
 * serta format lama: ABSEN-SDN-CBR01-ID-{id_siswa}
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'scan_qr') {
    $kode = trim((string)($_POST['kode'] ?? ''));

    $id_siswa = 0;

    // Format lama
    if (preg_match('/^ABSEN-SDN-CBR01-ID-(\d+)$/i', $kode, $m)) {
        $id_siswa = (int)$m[1];
    }

    // Format QR kartu yang sekarang: SDN-CIBURAYUT-01|ID:2|NISN:...|...
    if ($id_siswa <= 0 && preg_match('/(?:^|\|)ID\s*:\s*(\d+)(?:\||$)/i', $kode, $m)) {
        $id_siswa = (int)$m[1];
    }

    if ($id_siswa <= 0) {
        json_response(false, 'QR tidak dikenali. Gunakan QR Kartu Absensi SDN Ciburayut 01.');
    }
    if ($id_siswa <= 0) json_response(false, 'ID siswa pada QR tidak valid.');

    $q = mysqli_prepare($koneksi, "SELECT s.id_siswa, s.nis, s.nisn, s.nama_siswa, s.id_kelas, s.status_siswa, k.nama_kelas FROM siswa s LEFT JOIN kelas k ON k.id_kelas=s.id_kelas WHERE s.id_siswa=? LIMIT 1");
    if (!$q) json_response(false, 'Gagal menyiapkan data siswa.');
    mysqli_stmt_bind_param($q, 'i', $id_siswa);
    mysqli_stmt_execute($q);
    $rs = mysqli_stmt_get_result($q);
    $siswa = $rs ? mysqli_fetch_assoc($rs) : null;

    if (!$siswa) json_response(false, 'Siswa dengan ID tersebut tidak ditemukan.');
    if (($siswa['status_siswa'] ?? '') !== 'Aktif') json_response(false, 'Siswa ' . $siswa['nama_siswa'] . ' tidak berstatus Aktif.');
    if ((int)($siswa['id_kelas'] ?? 0) <= 0) json_response(false, 'Siswa ' . $siswa['nama_siswa'] . ' belum memiliki kelas.');

    $today = date('Y-m-d');
    $now = date('H:i:s');

    $id_tahun = 0;
    if (has_column($koneksi, 'absensi_siswa', 'id_tahun_ajaran')) {
        $qy = mysqli_query($koneksi, "SELECT id_tahun_ajaran, tahun_ajaran, semester FROM tahun_ajaran WHERE aktif=1 ORDER BY id_tahun_ajaran DESC LIMIT 1");
        if ($qy) {
            $tahun = mysqli_fetch_assoc($qy);
            $id_tahun = (int)($tahun['id_tahun_ajaran'] ?? 0);
        }
        if ($id_tahun <= 0) json_response(false, 'Tahun ajaran aktif belum tersedia.');
    }

    $has_kelas = has_column($koneksi, 'absensi_siswa', 'id_kelas');
    $has_ket = has_column($koneksi, 'absensi_siswa', 'keterangan');
    $has_jam = has_column($koneksi, 'absensi_siswa', 'jam_masuk');
    $has_waktu = has_column($koneksi, 'absensi_siswa', 'waktu_absen');
    $has_updated = has_column($koneksi, 'absensi_siswa', 'updated_at');
    $has_created = has_column($koneksi, 'absensi_siswa', 'created_at');

    /* Cari absensi hari ini untuk siswa tersebut. */
    $sql = "SELECT * FROM absensi_siswa WHERE id_siswa=? AND tanggal=?";
    $types = 'is';
    $vals = [$id_siswa, $today];
    if (has_column($koneksi, 'absensi_siswa', 'id_tahun_ajaran')) {
        $sql .= " AND id_tahun_ajaran=?";
        $types .= 'i';
        $vals[] = $id_tahun;
    }
    $sql .= " LIMIT 1";

    $cek = mysqli_prepare($koneksi, $sql);
    if (!$cek) json_response(false, 'Gagal memeriksa absensi hari ini.');
    mysqli_stmt_bind_param($cek, $types, ...$vals);
    mysqli_stmt_execute($cek);
    $rr = mysqli_stmt_get_result($cek);
    $old = $rr ? mysqli_fetch_assoc($rr) : null;

    if ($old) {
        /* Scan kedua pada hari yang sama tidak menggandakan data. */
        // Skema bootstrap memakai id_absensi; dua nama lain didukung untuk
        // database lama agar scan kedua dapat memperbarui data yang ada.
        $primary = isset($old['id_absensi_siswa']) ? 'id_absensi_siswa' : (isset($old['id_absensi']) ? 'id_absensi' : (isset($old['id']) ? 'id' : ''));
        if ($primary === '') json_response(false, 'Primary key tabel absensi_siswa tidak dikenali.');

        $set = ["`status`=?"];
        $uvals = ['Hadir'];
        $utypes = 's';

        if ($has_kelas) { $set[] = "`id_kelas`=?"; $uvals[] = (int)$siswa['id_kelas']; $utypes .= 'i'; }
        if ($has_ket) { $set[] = "`keterangan`=?"; $uvals[] = 'Scan QR'; $utypes .= 's'; }
        if ($has_jam) { $set[] = "`jam_masuk`=?"; $uvals[] = $now; $utypes .= 's'; }
        if ($has_waktu) { $set[] = "`waktu_absen`=?"; $uvals[] = date('Y-m-d H:i:s'); $utypes .= 's'; }
        if ($has_updated) { $set[] = "`updated_at`=CURRENT_TIMESTAMP"; }

        $uvals[] = (int)$old[$primary];
        $utypes .= 'i';
        $u = mysqli_prepare($koneksi, "UPDATE absensi_siswa SET " . implode(',', $set) . " WHERE `$primary`=?");
        if (!$u) json_response(false, 'Gagal menyiapkan pembaruan absensi.');
        mysqli_stmt_bind_param($u, $utypes, ...$uvals);
        if (!mysqli_stmt_execute($u)) json_response(false, 'Gagal memperbarui absensi: ' . mysqli_stmt_error($u));

        json_response(true, 'Sudah tercatat hadir hari ini.', [
            'duplicate' => true,
            'siswa' => $siswa['nama_siswa'],
            'nisn' => $siswa['nisn'] ?? '',
            'kelas' => $siswa['nama_kelas'] ?? '-',
            'tanggal' => $today,
            'jam' => $now
        ]);
    }

    $fields = ['id_siswa','tanggal','status'];
    $ivals = [$id_siswa, $today, 'Hadir'];
    $itypes = 'iss';

    if ($has_kelas) { $fields[]='id_kelas'; $ivals[]=(int)$siswa['id_kelas']; $itypes.='i'; }
    if (has_column($koneksi, 'absensi_siswa', 'id_tahun_ajaran')) { $fields[]='id_tahun_ajaran'; $ivals[]=$id_tahun; $itypes.='i'; }
    if ($has_ket) { $fields[]='keterangan'; $ivals[]='Scan QR'; $itypes.='s'; }
    if ($has_jam) { $fields[]='jam_masuk'; $ivals[]=$now; $itypes.='s'; }
    if ($has_waktu) { $fields[]='waktu_absen'; $ivals[]=date('Y-m-d H:i:s'); $itypes.='s'; }

    $marks = implode(',', array_fill(0, count($fields), '?'));
    $quoted = '`' . implode('`,`', $fields) . '`';
    $ins = mysqli_prepare($koneksi, "INSERT INTO absensi_siswa ($quoted) VALUES ($marks)");
    if (!$ins) json_response(false, 'Gagal menyiapkan penyimpanan absensi.');
    mysqli_stmt_bind_param($ins, $itypes, ...$ivals);
    if (!mysqli_stmt_execute($ins)) json_response(false, 'Gagal menyimpan absensi: ' . mysqli_stmt_error($ins));

    json_response(true, 'Kehadiran berhasil dicatat.', [
        'duplicate' => false,
        'siswa' => $siswa['nama_siswa'],
        'nisn' => $siswa['nisn'] ?? '',
        'kelas' => $siswa['nama_kelas'] ?? '-',
        'tanggal' => $today,
        'jam' => $now
    ]);
}

/* Daftar siswa aktif untuk mode Input Manual (dropdown pencarian) */
$daftar_siswa = [];
$qs = mysqli_query($koneksi, "SELECT s.id_siswa, s.nisn, s.nama_siswa, k.nama_kelas FROM siswa s LEFT JOIN kelas k ON k.id_kelas=s.id_kelas WHERE s.status_siswa='Aktif' ORDER BY s.nama_siswa");
if ($qs) while ($r = mysqli_fetch_assoc($qs)) $daftar_siswa[] = $r;

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>
<style>
.scan-wrap{max-width:1100px}.scan-head{display:flex;justify-content:space-between;align-items:flex-start;gap:15px;margin-bottom:20px}.scan-head h1{margin:0 0 6px}.scan-head p{margin:0;color:#64748b}.scan-card{background:#fff;border-radius:18px;box-shadow:0 8px 25px rgba(15,35,70,.07);padding:22px;margin-bottom:18px}.scan-grid{display:grid;grid-template-columns:minmax(320px,1fr) minmax(280px,360px);gap:22px;align-items:start}.reader-box{border:1px solid #e5ebf3;border-radius:16px;padding:14px;background:#f8fafc}.reader-title{font-weight:700;margin-bottom:12px}.result{border-radius:14px;padding:18px;background:#f8fafc;border:1px solid #e5ebf3;min-height:150px}.result.ok{background:#ecfdf5;border-color:#bbf7d0;color:#166534}.result.err{background:#fff1f2;border-color:#fecdd3;color:#9f1239}.result strong{font-size:18px;display:block;margin-bottom:8px}.result small{display:block;margin-top:5px;color:#64748b}.info-box{padding:14px 16px;border-radius:12px;background:#eff6ff;border:1px solid #bfdbfe;color:#1e40af;line-height:1.5;margin-top:15px}.manual{display:flex;gap:8px;margin-top:15px}.manual input{flex:1;height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:0 12px}.btn{border:0;border-radius:10px;padding:11px 16px;font-weight:700;cursor:pointer;background:#1677e8;color:#fff}.btn:disabled{opacity:.6;cursor:not-allowed}.recent{margin-top:16px}.recent h3{margin:0 0 10px}.recent-list{display:flex;flex-direction:column;gap:8px;max-height:270px;overflow:auto}.recent-item{padding:10px 12px;border-radius:10px;background:#f8fafc;border:1px solid #edf2f7}.recent-item b{display:block}.recent-item span{font-size:12px;color:#64748b}@media(max-width:800px){.scan-grid{grid-template-columns:1fr}.scan-head{flex-direction:column}.manual{flex-direction:column}}
</style>

<main class="main-content"><div class="scan-wrap">
    <div class="scan-head">
        <div>
            <h1>📷 Scan QR Kehadiran</h1>
            <p>Arahkan kamera ke QR pada Kartu Absensi Siswa.</p>
        </div>
    </div>

    <div class="scan-card">
        <div class="scan-grid">
            <div>
                <div class="reader-box">
                    <div class="reader-title">Kamera Scanner</div>
                    <div id="reader"></div>
                </div>
                <div class="info-box">
                    <b>Alur otomatis:</b><br>
                    Scan QR → sistem mengenali siswa → status <b>Hadir</b> → tersimpan ke absensi hari ini.
                </div>

                <button class="btn" type="button" id="btnToggleManual" style="margin-top:14px;background:#eef3f9;color:#1e293b;width:100%;">✏️ Aktifkan Input Manual</button>

                <div id="panelManual" style="display:none;margin-top:14px;border:1px solid #e5ebf3;border-radius:14px;padding:16px;background:#f8fafc;">
                    <div style="font-weight:700;margin-bottom:10px;">Input Manual (tanpa scan)</div>
                    <div style="margin-bottom:10px;">
                        <label style="display:block;font-size:13px;font-weight:600;color:#334155;margin-bottom:6px;">Pilih Siswa</label>
                        <select id="pilihSiswa" style="width:100%;height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:0 10px;">
                            <option value="">-- Cari / pilih nama siswa --</option>
                            <?php foreach ($daftar_siswa as $sw): ?>
                                <option value="<?=(int)$sw['id_siswa']?>"><?=h($sw['nama_siswa'])?> — <?=h($sw['nama_kelas'] ?: 'Belum ada kelas')?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div style="margin-bottom:12px;">
                        <label style="display:block;font-size:13px;font-weight:600;color:#334155;margin-bottom:6px;">Status</label>
                        <select id="statusManual" style="width:100%;height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:0 10px;">
                            <option value="Hadir">Hadir</option>
                            <option value="Sakit">Sakit</option>
                            <option value="Izin">Izin</option>
                            <option value="Alpa">Alpa</option>
                        </select>
                    </div>
                    <button class="btn" id="btnSimpanManual" type="button" style="width:100%;">💾 Simpan Absensi Manual</button>
                </div>

                <div class="manual" style="margin-top:14px;">
                    <input id="kodeManual" type="text" placeholder="Tes kode QR mentah (opsional): SDN-CIBURAYUT-01|ID:2|...">
                    <button class="btn" id="btnManual" type="button">Tes Kode</button>
                </div>
            </div>

            <div>
                <div id="hasil" class="result">
                    <strong>Siap melakukan scan.</strong>
                    <span>Arahkan kamera ke QR kartu siswa.</span>
                </div>
                <div class="recent">
                    <h3>Scan Terakhir</h3>
                    <div id="recentList" class="recent-list"></div>
                </div>
            </div>
        </div>
    </div>
</div></main>

<script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
<script>
document.addEventListener('DOMContentLoaded', function(){
    const hasil = document.getElementById('hasil');
    const recentList = document.getElementById('recentList');
    const btnManual = document.getElementById('btnManual');
    const kodeManual = document.getElementById('kodeManual');
    let sedangProses = false;
    let scanner = null;

    function tampil(pesan, ok){
        hasil.className = 'result ' + (ok ? 'ok' : 'err');
        hasil.innerHTML = pesan;
    }

    function tambahRecent(data){
        const item = document.createElement('div');
        item.className = 'recent-item';
        item.innerHTML = '<b>' + escapeHtml(data.siswa) + '</b><span>' + escapeHtml(data.kelas) + ' • ' + escapeHtml(data.jam) + '</span>';
        recentList.prepend(item);
        while(recentList.children.length > 8) recentList.removeChild(recentList.lastChild);
    }

    function escapeHtml(s){
        return String(s ?? '').replace(/[&<>'"]/g, function(c){ return ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c]); });
    }

    async function prosesKode(kode){
        kode = String(kode || '').trim();
        if(!kode || sedangProses) return;
        sedangProses = true;
        tampil('<strong>Memproses QR...</strong><span>Mohon tunggu.</span>', true);

        try{
            const body = new URLSearchParams();
            body.set('aksi','scan_qr');
            body.set('kode',kode);

            const response = await fetch(window.location.href, {
                method:'POST',
                headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},
                body:body.toString()
            });
            const data = await response.json();

            if(data.ok){
                const label = data.duplicate ? 'Sudah tercatat' : 'Kehadiran berhasil dicatat';
                tampil('<strong>✅ ' + label + '</strong>' +
                    '<span>' + escapeHtml(data.siswa) + '</span>' +
                    '<small>Kelas: ' + escapeHtml(data.kelas) + ' • ' + escapeHtml(data.jam) + '</small>', true);
                tambahRecent(data);
            }else{
                tampil('<strong>❌ Gagal</strong><span>' + escapeHtml(data.message) + '</span>', false);
            }
        }catch(e){
            tampil('<strong>❌ Kesalahan koneksi</strong><span>Respons server tidak dapat diproses.</span>', false);
        }finally{
            setTimeout(function(){ sedangProses=false; }, 700);
        }
    }

    btnManual.addEventListener('click', function(){ prosesKode(kodeManual.value); });
    kodeManual.addEventListener('keydown', function(e){ if(e.key === 'Enter') prosesKode(kodeManual.value); });

    if(typeof Html5Qrcode !== 'undefined'){
        scanner = new Html5Qrcode('reader');
        scanner.start(
            { facingMode: 'environment' },
            { fps: 10, qrbox: { width: 250, height: 250 } },
            function(decodedText){ prosesKode(decodedText); },
            function(){ /* frame belum berisi QR */ }
        ).catch(function(){
            tampil('<strong>⚠️ Kamera belum aktif</strong><span>Izinkan akses kamera pada browser, lalu muat ulang halaman.</span>', false);
        });
    }else{
        tampil('<strong>⚠️ Scanner tidak tersedia</strong><span>Library scanner belum termuat.</span>', false);
    }
});
</script>
