<?php
// Sidebar dengan hak akses role.
// File: includes/sidebar.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$auth_file = __DIR__ . '/../config/auth.php';
if (file_exists($auth_file)) {
    require_once $auth_file;
}

$halaman_aktif = basename($_SERVER['PHP_SELF']);
$path_aktif = $_SERVER['REQUEST_URI'] ?? '';

$user_nama = $_SESSION['nama'] ?? $_SESSION['nama_user'] ?? $_SESSION['username'] ?? 'Pengguna';
$user_role = strtolower(trim((string)($_SESSION['role'] ?? '')));

// Profil sekolah untuk header sidebar
$profil = null;
if (isset($koneksi)) {
    $q_profil = mysqli_query($koneksi, "SELECT * FROM sekolah LIMIT 1");
    if ($q_profil) {
        $profil = mysqli_fetch_assoc($q_profil);
    }
}

$nama_sekolah = $profil['nama_sekolah'] ?? 'SDN CIBURAYUT 01';

function menu_diizinkan(string $menu): bool
{
    global $user_role;

    // Admin selalu mendapatkan seluruh menu.
    if ($user_role === 'admin') {
        return true;
    }

    // Untuk Guru/Operator tetap gunakan sistem izin yang sudah ada.
    if (function_exists('izin_menu')) {
        return izin_menu($menu);
    }

    // Fallback aman bila auth belum tersedia.
    return false;
}

function menu_aktif(string $target): bool
{
    global $path_aktif;

    $target = ltrim($target, '/');
    $target_path = '/absensi_sd/' . $target;

    return strpos($path_aktif, $target_path) === 0;
}
?>

<aside class="sidebar">
    <div class="sidebar-header">
        <div class="sidebar-logo">🎓</div>
        <div>
            <h2>Absensi SD</h2>
            <p><?= htmlspecialchars($nama_sekolah); ?></p>
        </div>
    </div>

    <nav class="sidebar-menu">

        <a href="/absensi_sd/index.php"
           class="menu-item <?= menu_aktif('index.php') ? 'active' : ''; ?>">
            🏠 <span>Dashboard</span>
        </a>

        <?php if (
            menu_diizinkan('siswa') ||
            menu_diizinkan('guru') ||
            menu_diizinkan('kelas') ||
            menu_diizinkan('buku_induk') ||
            menu_diizinkan('mapel')
        ): ?>
            <div class="menu-title">MASTER DATA</div>

            <?php if (menu_diizinkan('siswa')): ?>
                <a href="/absensi_sd/modules/siswa/"
                   class="menu-item <?= menu_aktif('modules/siswa/') ? 'active' : ''; ?>">
                    👨‍🎓 <span>Data Siswa</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('guru')): ?>
                <a href="/absensi_sd/modules/guru/"
                   class="menu-item <?= menu_aktif('modules/guru/') ? 'active' : ''; ?>">
                    👨‍🏫 <span>Data Guru & Karyawan</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('kelas')): ?>
                <a href="/absensi_sd/modules/kelas/"
                   class="menu-item <?= menu_aktif('modules/kelas/') ? 'active' : ''; ?>">
                    🏫 <span>Data Kelas</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('buku_induk')): ?>
                <a href="/absensi_sd/modules/buku_induk/"
                   class="menu-item <?= menu_aktif('modules/buku_induk/') ? 'active' : ''; ?>">
                    📚 <span>Buku Induk</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('mapel')): ?>
                <a href="/absensi_sd/modules/mata_pelajaran/index.php"
                   class="menu-item <?= menu_aktif('modules/mata_pelajaran/index.php') ? 'active' : ''; ?>">
                    📖 <span>Mata Pelajaran</span>
                </a>
            <?php endif; ?>
        <?php endif; ?>


        <?php if (
            menu_diizinkan('absensi_siswa') ||
            menu_diizinkan('absensi_guru') ||
            menu_diizinkan('rekap_absensi') ||
            menu_diizinkan('kartu_absensi')
        ): ?>
            <div class="menu-title">ABSENSI</div>

            <?php if (menu_diizinkan('absensi_siswa')): ?>
                <div class="menu-group-title">
                    <div class="menu-item" style="cursor:default;">
                        🗓️ <span>Kehadiran Siswa</span>
                        <span class="menu-arrow">▼</span>
                    </div>
                    <div class="submenu">
                        <a href="/absensi_sd/modules/absensi/index.php" class="submenu-item">✏️ <span>Input Kehadiran</span></a>
                        <a href="/absensi_sd/modules/absensi/scan_qr.php" class="submenu-item">📷 <span>Scan QR Kehadiran</span></a>
                        <?php if (menu_diizinkan('rekap_absensi')): ?>
                            <a href="/absensi_sd/modules/rekap/index.php" class="submenu-item">📊 <span>Rekap Kehadiran</span></a>
                        <?php endif; ?>
                        <?php if (menu_diizinkan('kartu_absensi')): ?>
                            <a href="/absensi_sd/modules/absensi/cetak_kartu.php" class="submenu-item">🎫 <span>Cetak Kartu QR</span></a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (menu_diizinkan('absensi_guru')): ?>
                <a href="/absensi_sd/modules/guru/absensi.php" class="menu-item <?= $halaman_aktif === 'absensi.php' && strpos($path_aktif, '/modules/guru/') !== false ? 'active' : ''; ?>">
                    👤 <span>Absensi Guru & Karyawan</span>
                </a>
            <?php endif; ?>
        <?php endif; ?>


        <?php if (
            menu_diizinkan('nilai_siswa') ||
            menu_diizinkan('nilai_gasal') ||
            menu_diizinkan('nilai_genap') ||
            menu_diizinkan('upload_nilai')
        ): ?>
            <div class="menu-title">NILAI</div>

            <?php if (menu_diizinkan('nilai_siswa')): ?>
                <a href="/absensi_sd/modules/nilai/"
                   class="menu-item <?= menu_aktif('modules/nilai/') && $halaman_aktif === 'index.php' ? 'active' : ''; ?>">
                    📈 <span>Nilai Siswa</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('nilai_gasal')): ?>
                <a href="/absensi_sd/modules/nilai/gasal.php"
                   class="menu-item <?= $halaman_aktif === 'gasal.php' ? 'active' : ''; ?>">
                    📝 <span>Nilai Gasal</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('nilai_genap')): ?>
                <a href="/absensi_sd/modules/nilai/genap.php"
                   class="menu-item <?= $halaman_aktif === 'genap.php' ? 'active' : ''; ?>">
                    📝 <span>Nilai Genap</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('upload_nilai')): ?>
                <a href="/absensi_sd/modules/nilai/upload.php"
                   class="menu-item <?= $halaman_aktif === 'upload.php' ? 'active' : ''; ?>">
                    📤 <span>Upload Nilai Pelajaran</span>
                </a>
            <?php endif; ?>
        <?php endif; ?>


        <?php if (
            menu_diizinkan('laporan') ||
            menu_diizinkan('buku_induk_masal')
        ): ?>
            <div class="menu-title">LAPORAN</div>

            <?php if (menu_diizinkan('laporan')): ?>
                <a href="/absensi_sd/modules/laporan/"
                   class="menu-item <?= menu_aktif('modules/laporan/') && $halaman_aktif === 'index.php' ? 'active' : ''; ?>">
                    📄 <span>Laporan</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('buku_induk_masal')): ?>
                <a href="/absensi_sd/modules/buku_induk/cetak_masal.php"
                   class="menu-item <?= $halaman_aktif === 'cetak_masal.php' && strpos($path_aktif, '/modules/buku_induk/') !== false ? 'active' : ''; ?>">
                    🖨️ <span>Cetak Buku Induk Masal</span>
                </a>
            <?php endif; ?>
        <?php endif; ?>


        <?php if (menu_diizinkan('pengguna') || $user_role === 'admin'): ?>
            <div class="menu-title">PENGATURAN</div>

            <?php if ($user_role === 'admin'): ?>
                <a href="/absensi_sd/modules/pengaturan/"
                   class="menu-item <?= menu_aktif('modules/pengaturan/') ? 'active' : ''; ?>">
                    ⚙️ <span>Pengaturan</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('pengguna')): ?>
                <a href="/absensi_sd/modules/pengguna/"
                   class="menu-item <?= menu_aktif('modules/pengguna/') ? 'active' : ''; ?>">
                    👥 <span>Pengguna</span>
                </a>
            <?php endif; ?>
        <?php endif; ?>


        <a href="/absensi_sd/logout.php" class="menu-item logout">
            🚪 <span>Keluar</span>
        </a>

    </nav>
</aside>
