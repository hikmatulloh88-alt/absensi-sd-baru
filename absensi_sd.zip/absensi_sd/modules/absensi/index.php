<?php
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator', 'Guru');
require_once "../../config/database.php";

$menu_aktif = 'absensi_siswa';
$page_title = 'Absensi Siswa - SDN Ciburayut 01';

function h($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}

$cols=[];
$qcols=mysqli_query($koneksi,"SHOW COLUMNS FROM absensi_siswa");
if($qcols){while($c=mysqli_fetch_assoc($qcols))$cols[]=$c['Field'];}
$has=function($f)use(&$cols){return in_array($f,$cols,true);};

$today=date('Y-m-d');
$tanggal=$_REQUEST['tanggal']??$today;
if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$tanggal))$tanggal=$today;

$id_kelas=(int)($_REQUEST['id_kelas']??0);
$id_tahun=(int)($_REQUEST['id_tahun_ajaran']??0);

$pesan='';$tipe='';

/* SIMPAN */
if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['aksi']??'')==='simpan'){
    $tgl=$_POST['tanggal']??$today;
    $th=(int)($_POST['id_tahun_ajaran']??0);
    $statusRows=[];

    foreach($_POST as $key=>$value){
        if(strpos($key,'status_')===0){
            $sid=(int)substr($key,7);
            if($sid>0)$statusRows[$sid]=trim((string)$value);
        }
    }

    if(!$has('id_siswa')||!$has('tanggal')||!$has('status')){
        $pesan='Kolom wajib pada tabel absensi_siswa belum lengkap.';
        $tipe='error';
    }elseif(!$statusRows){
        $pesan='Tidak ada data siswa yang dikirim.';
        $tipe='error';
    }else{
        $berhasil=0;$gagal=[];

        foreach($statusRows as $sid=>$status){
            if(!in_array($status,['Hadir','Sakit','Izin','Alpa'],true)){
                $gagal[]="ID $sid: status tidak valid";
                continue;
            }

            $kelas_input=(int)($_POST['kelas_'.$sid]??0);
            $keterangan=trim((string)($_POST['keterangan_'.$sid]??''));

            /* Jika siswa belum punya kelas dan user memilih kelas, isi master siswa dulu. */
            $cek_s=mysqli_prepare($koneksi,"SELECT id_kelas FROM siswa WHERE id_siswa=? LIMIT 1");
            $kelas_siswa=null;

            if($cek_s){
                mysqli_stmt_bind_param($cek_s,"i",$sid);
                mysqli_stmt_execute($cek_s);
                $rs=mysqli_stmt_get_result($cek_s);
                $row=$rs?mysqli_fetch_assoc($rs):null;
                $kelas_siswa=isset($row['id_kelas'])?(int)$row['id_kelas']:null;
            }

            if($kelas_siswa<=0 && $kelas_input>0){
                // Kelas master TIDAK boleh diubah dari modul transaksi.
                // Perbaiki kelas hanya melalui Data Siswa / sinkronisasi Dapodik.
            }

            if($has('id_kelas') && (!$kelas_siswa || $kelas_siswa<=0)){
                $gagal[]="ID $sid: kelas belum dipilih";
                continue;
            }

            /* Cari absensi yang sudah ada */
            $old=null;
            $sqlc="SELECT * FROM absensi_siswa WHERE id_siswa=? AND tanggal=?";
            $tc="is";$vc=[$sid,$tgl];

            if($has('id_tahun_ajaran')){
                $sqlc.=" AND id_tahun_ajaran=?";
                $tc.="i";$vc[]=$th;
            }

            $sc=mysqli_prepare($koneksi,$sqlc);
            if($sc){
                mysqli_stmt_bind_param($sc,$tc,...$vc);
                mysqli_stmt_execute($sc);
                $rc=mysqli_stmt_get_result($sc);
                $old=$rc?mysqli_fetch_assoc($rc):null;
            }

            if($old){
                // id_absensi adalah primary key pada schema_bootstrap.php;
                // nama lama tetap diterima untuk database yang sudah ada.
                $primary=isset($old['id_absensi_siswa'])?'id_absensi_siswa':(isset($old['id_absensi'])?'id_absensi':(isset($old['id'])?'id':''));
                if($primary===''){
                    $gagal[]="ID $sid: primary key absensi tidak dikenali";
                    continue;
                }

                $set=["`status`=?"];$vals=[$status];$types="s";
                if($has('id_kelas')){$set[]="`id_kelas`=?";$vals[]=$kelas_siswa;$types.="i";}
                if($has('keterangan')){$set[]="`keterangan`=?";$vals[]=$keterangan===''?null:$keterangan;$types.="s";}
                $vals[]=(int)$old[$primary];$types.="i";

                $u=mysqli_prepare($koneksi,"UPDATE absensi_siswa SET ".implode(',',$set)." WHERE `$primary`=?");
                if($u){
                    mysqli_stmt_bind_param($u,$types,...$vals);
                    if(mysqli_stmt_execute($u))$berhasil++;
                    else $gagal[]="ID $sid: ".mysqli_stmt_error($u);
                }else $gagal[]="ID $sid: ".mysqli_error($koneksi);

            }else{
                $fields=['id_siswa','tanggal','status'];
                $vals=[$sid,$tgl,$status];
                $types="iss";

                if($has('id_kelas')){$fields[]='id_kelas';$vals[]=$kelas_siswa;$types.="i";}
                if($has('id_tahun_ajaran')){$fields[]='id_tahun_ajaran';$vals[]=$th;$types.="i";}
                if($has('keterangan')){$fields[]='keterangan';$vals[]=$keterangan===''?null:$keterangan;$types.="s";}

                $marks=implode(',',array_fill(0,count($fields),'?'));
                $f='`'.implode('`,`',$fields).'`';
                $i=mysqli_prepare($koneksi,"INSERT INTO absensi_siswa ($f) VALUES ($marks)");

                if($i){
                    mysqli_stmt_bind_param($i,$types,...$vals);
                    if(mysqli_stmt_execute($i))$berhasil++;
                    else $gagal[]="ID $sid: ".mysqli_stmt_error($i);
                }else $gagal[]="ID $sid: ".mysqli_error($koneksi);
            }
        }

        if($berhasil>0){
            $pesan="Absensi berhasil disimpan untuk $berhasil siswa.";
            if($gagal)$pesan.=" Ada ".count($gagal)." data yang belum tersimpan.";
            $tipe=$gagal?'error':'success';
        }else{
            $pesan='Belum ada absensi yang tersimpan. Pastikan setiap siswa sudah memiliki kelas.';
            if($gagal)$pesan.=' Detail: '.implode(' | ',array_slice($gagal,0,3));
            $tipe='error';
        }
    }
}

/* TAHUN AJARAN */
$tahun=[];
if($has('id_tahun_ajaran')){
    $q=mysqli_query($koneksi,"SELECT id_tahun_ajaran,tahun_ajaran,semester,aktif FROM tahun_ajaran ORDER BY aktif DESC,id_tahun_ajaran DESC");
    if($q)while($r=mysqli_fetch_assoc($q))$tahun[]=$r;
    if(!$id_tahun && $tahun)$id_tahun=(int)$tahun[0]['id_tahun_ajaran'];
}

/* KELAS */
$kelas=[];
$q=mysqli_query($koneksi,"SELECT id_kelas,nama_kelas,tingkat FROM kelas ORDER BY tingkat,nama_kelas");
if($q)while($r=mysqli_fetch_assoc($q))$kelas[]=$r;

/* SISWA */
$where="s.status_siswa='Aktif'";
if($id_kelas>0)$where.=" AND s.id_kelas=".$id_kelas;

$siswa=[];
$q=mysqli_query($koneksi,"SELECT s.id_siswa,s.nis,s.nisn,s.nama_siswa,s.id_kelas,k.nama_kelas FROM siswa s LEFT JOIN kelas k ON k.id_kelas=s.id_kelas WHERE $where ORDER BY k.tingkat,k.nama_kelas,s.nama_siswa");
if($q)while($r=mysqli_fetch_assoc($q))$siswa[]=$r;

/* ABSENSI HARI INI */
$absensi=[];
if($has('id_siswa')&&$has('tanggal')&&$has('status')){
    $sql="SELECT id_siswa,status".($has('keterangan')?",keterangan":"")." FROM absensi_siswa WHERE tanggal=?";
    $vals=[$tanggal];$types="s";
    if($has('id_tahun_ajaran')&&$id_tahun>0){$sql.=" AND id_tahun_ajaran=?";$vals[]=$id_tahun;$types.="i";}
    $a=mysqli_prepare($koneksi,$sql);
    if($a){
        mysqli_stmt_bind_param($a,$types,...$vals);mysqli_stmt_execute($a);
        $r=mysqli_stmt_get_result($a);
        if($r)while($x=mysqli_fetch_assoc($r))$absensi[(int)$x['id_siswa']]=$x;
    }
}

$stats=['Hadir'=>0,'Sakit'=>0,'Izin'=>0,'Alpa'=>0];
foreach($absensi as $a){
    $s=strtolower(trim($a['status']??''));
    if($s==='hadir')$stats['Hadir']++;
    elseif($s==='sakit')$stats['Sakit']++;
    elseif($s==='izin')$stats['Izin']++;
    elseif($s==='alpa'||$s==='alpha')$stats['Alpa']++;
}

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>
<style>
.abp{max-width:1450px}.ph{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}.ph h1{margin:0 0 6px}.ph p{margin:0}
.card{background:#fff;border-radius:18px;box-shadow:0 8px 25px rgba(15,35,70,.07);padding:20px;margin-bottom:20px}.grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:15px}
label{display:block;font-size:13px;font-weight:600;color:#334155;margin-bottom:7px}.fc,.st,.kt,.ks{width:100%;height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:0 11px;background:#fff}.btn{display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:10px;padding:11px 16px;font-weight:600;text-decoration:none;cursor:pointer}.pri{background:linear-gradient(135deg,#2388f5,#1265dc);color:#fff}.sec{background:#eef3f9;color:#334155}
.alert{padding:13px 15px;border-radius:11px;margin-bottom:18px;font-size:14px;line-height:1.5}.ok{background:#ecfdf3;color:#18794e;border:1px solid #ccefdc}.er{background:#fff1f2;color:#be123c;border:1px solid #fecdd3}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:18px}.stat{padding:15px;background:#f7f9fc;border-radius:13px}.stat strong{font-size:23px;display:block}.stat span{font-size:12px;color:#64748b}
.tw{overflow-x:auto}.dt{width:100%;border-collapse:collapse;min-width:1100px}.dt th{background:#f7f9fc;color:#64748b;font-size:12px;text-transform:uppercase;padding:12px;text-align:left}.dt td{padding:11px 12px;border-bottom:1px solid #edf1f6}.nm{font-weight:700;color:#17233c}.sub{font-size:12px;color:#94a3b8;margin-top:3px}.st{min-width:120px}.kt{min-width:180px}.ks{min-width:160px}.unassigned{background:#fff7e8;border:1px solid #f4d58a}
@media(max-width:800px){.grid3,.stats{grid-template-columns:1fr 1fr}}@media(max-width:600px){.grid3,.stats{grid-template-columns:1fr}.ph{align-items:flex-start;flex-direction:column;gap:10px}}
.scanbox{border:2px solid #1677e8;border-radius:16px;padding:18px}.scanbox h3{margin:0 0 14px;color:#1265dc;display:flex;align-items:center;gap:8px}.scan-status{border:1px dashed #cfe0f7;border-radius:12px;padding:22px;text-align:center;color:#64748b;font-size:15px;background:#f8fbff}.scan-status.ok{background:#ecfdf3;color:#18794e;border-color:#bbf7d0}.scan-status.err{background:#fff1f2;color:#be123c;border-color:#fecdd3}
#readerBox{max-width:340px;margin:0 auto 14px}
.btn-toggle{background:#fff;border:1px solid #1677e8;color:#1677e8;margin-bottom:16px}
.manual-input{display:none}
.manual-input.show{display:block}
.scanbox.hide{display:none}
</style>

<main class="main-content"><div class="abp">
<div class="ph"><div><h1>Absensi Siswa</h1><p>Catat kehadiran siswa berdasarkan tanggal dan kelas.</p></div></div>

<?php if($pesan): ?><div class="alert <?=$tipe==='success'?'ok':'er'?>"><?=h($pesan)?></div><?php endif; ?>

<div class="card scanbox" id="scanBox">
    <h3>📷 Scan Barcode / QR Siswa</h3>
    <div id="readerBox"></div>
    <div id="scanStatus" class="scan-status">Silakan scan kartu siswa...</div>
</div>

<button type="button" class="btn btn-toggle" id="btnToggleManual">✏️ Aktifkan Input Manual</button>

<div id="manualWrap" class="manual-input">
<div class="card"><form method="get"><div class="grid3">
<div><label>Tanggal</label><input class="fc" type="date" name="tanggal" value="<?=h($tanggal)?>"></div>
<div><label>Kelas</label><select class="fc" name="id_kelas"><option value="0">Semua Kelas</option><?php foreach($kelas as $k): ?><option value="<?=$k['id_kelas']?>" <?=$id_kelas===(int)$k['id_kelas']?'selected':''?>>Kelas <?=h($k['nama_kelas'])?></option><?php endforeach;?></select></div>
<?php if($has('id_tahun_ajaran')):?><div><label>Tahun Ajaran / Semester</label><select class="fc" name="id_tahun_ajaran"><?php foreach($tahun as $t): ?><option value="<?=$t['id_tahun_ajaran']?>" <?=$id_tahun===(int)$t['id_tahun_ajaran']?'selected':''?>><?=h($t['tahun_ajaran'])?> - <?=h($t['semester'])?></option><?php endforeach;?></select></div><?php endif;?>
</div><div style="margin-top:15px;display:flex;gap:8px"><button class="btn pri">🔎 Tampilkan</button><a class="btn sec" href="index.php">Reset</a></div></form></div>

<div class="stats"><div class="stat"><strong><?=$stats['Hadir']?></strong><span>Hadir</span></div><div class="stat"><strong><?=$stats['Sakit']?></strong><span>Sakit</span></div><div class="stat"><strong><?=$stats['Izin']?></strong><span>Izin</span></div><div class="stat"><strong><?=$stats['Alpa']?></strong><span>Alpa</span></div></div>

<div class="card"><form method="post"><input type="hidden" name="aksi" value="simpan"><input type="hidden" name="tanggal" value="<?=h($tanggal)?>"><input type="hidden" name="id_tahun_ajaran" value="<?=$id_tahun?>">
<div class="tw"><table class="dt"><thead><tr><th>No</th><th>NIS/NISN</th><th>Nama Siswa</th><th>Kelas</th><th>Status</th><?php if($has('keterangan')):?><th>Keterangan</th><?php endif;?></tr></thead><tbody>

<?php if($siswa): $no=1; foreach($siswa as $s): $a=$absensi[(int)$s['id_siswa']]??[]; $sn=$a['status']??'Hadir'; $kn=$a['keterangan']??''; $needsClass=(int)$s['id_kelas']<=0; ?>
<tr>
<td><?=$no++?></td>
<td><?=h($s['nis']?:'-')?><div class="sub">NISN: <?=h($s['nisn']?:'-')?></div></td>
<td><div class="nm"><?=h($s['nama_siswa'])?></div></td>
<td>
<?php if($needsClass): ?>
<select class="ks unassigned" name="kelas_<?=$s['id_siswa']?>" required>
<option value="">Pilih Kelas</option>
<?php foreach($kelas as $k): ?><option value="<?=$k['id_kelas']?>" <?=$id_kelas===(int)$k['id_kelas']?'selected':''?>><?=h($k['nama_kelas'])?></option><?php endforeach;?>
</select>
<div class="sub">Kelas siswa belum ditentukan.</div>
<?php else: ?>
<?=h($s['nama_kelas'])?>
<input type="hidden" name="kelas_<?=$s['id_siswa']?>" value="<?=$s['id_kelas']?>">
<?php endif;?>
</td>
<td><select class="st" name="status_<?=$s['id_siswa']?>"><?php foreach(['Hadir','Sakit','Izin','Alpa'] as $x):?><option value="<?=$x?>" <?=$sn===$x?'selected':''?>><?=$x?></option><?php endforeach;?></select></td>
<?php if($has('keterangan')):?><td><input class="kt" name="keterangan_<?=$s['id_siswa']?>" value="<?=h($kn)?>" placeholder="Keterangan..."></td><?php endif;?>
</tr>
<?php endforeach; else: ?><tr><td colspan="<?=$has('keterangan')?6:5?>" style="text-align:center;padding:40px;color:#94a3b8">Belum ada siswa aktif pada filter ini.</td></tr><?php endif;?>

</tbody></table></div>

<?php if($siswa): ?><div style="margin-top:18px;text-align:right"><button class="btn pri" type="submit">💾 Simpan Absensi</button></div><?php endif;?>
</form></div>
</div><!-- /manualWrap -->
</div></main>

<script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
<script>
document.addEventListener('DOMContentLoaded', function(){
    const scanBox = document.getElementById('scanBox');
    const scanStatus = document.getElementById('scanStatus');
    const manualWrap = document.getElementById('manualWrap');
    const btnToggle = document.getElementById('btnToggleManual');
    let manualOn = false;
    let sedangProses = false;

    btnToggle.addEventListener('click', function(){
        manualOn = !manualOn;
        manualWrap.classList.toggle('show', manualOn);
        scanBox.classList.toggle('hide', manualOn);
        btnToggle.textContent = manualOn ? '📷 Kembali ke Scan QR' : '✏️ Aktifkan Input Manual';
    });

    function tampilStatus(pesan, tipe){
        scanStatus.className = 'scan-status' + (tipe ? ' ' + tipe : '');
        scanStatus.innerHTML = pesan;
    }

    async function prosesKode(kode){
        kode = String(kode || '').trim();
        if(!kode || sedangProses) return;
        sedangProses = true;
        tampilStatus('Memproses QR, mohon tunggu...', '');
        try{
            const body = new URLSearchParams();
            body.set('aksi','scan_qr');
            body.set('kode',kode);
            const response = await fetch('scan_qr.php', {
                method:'POST',
                headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},
                body:body.toString()
            });
            const data = await response.json();
            if(data.ok){
                const label = data.duplicate ? 'Sudah tercatat hadir' : 'Kehadiran berhasil dicatat';
                tampilStatus('✅ ' + label + ' — ' + (data.siswa||'') + ' (Kelas ' + (data.kelas||'-') + ', ' + (data.jam||'') + ')', 'ok');
            }else{
                tampilStatus('❌ ' + (data.message||'QR tidak dikenali.'), 'err');
            }
        }catch(e){
            tampilStatus('❌ Tidak bisa terhubung ke server.', 'err');
        }finally{
            setTimeout(function(){ sedangProses=false; tampilStatus('Silakan scan kartu siswa...',''); }, 2500);
        }
    }

    if(typeof Html5Qrcode !== 'undefined'){
        const scanner = new Html5Qrcode('readerBox');
        scanner.start(
            { facingMode: 'environment' },
            { fps: 10, qrbox: { width: 230, height: 230 } },
            function(decodedText){ prosesKode(decodedText); },
            function(){ /* belum ada QR di frame */ }
        ).catch(function(){
            tampilStatus('⚠️ Kamera belum aktif. Izinkan akses kamera pada browser, lalu muat ulang halaman. Atau pakai tombol "Aktifkan Input Manual" di bawah.', 'err');
        });
    }else{
        tampilStatus('⚠️ Scanner belum termuat. Gunakan "Aktifkan Input Manual".', 'err');
    }
});
</script>
</body></html>
