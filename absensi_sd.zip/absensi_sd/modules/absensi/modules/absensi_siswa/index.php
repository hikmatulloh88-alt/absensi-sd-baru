<?php
// File ini berada empat level di bawah root aplikasi. Gunakan __DIR__ agar
// akses langsung tidak gagal karena relative path yang salah.
require_once __DIR__ . "/../../../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator', 'Guru');
require_once __DIR__ . "/../../../../config/database.php";
$menu_aktif='absensi_siswa';
$page_title='Absensi Siswa - SDN Ciburayut 01';

function h($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
$cols=[];$qc=mysqli_query($koneksi,"SHOW COLUMNS FROM absensi_siswa");
if($qc){while($r=mysqli_fetch_assoc($qc))$cols[]=$r['Field'];}
$has=function($x)use(&$cols){return in_array($x,$cols,true);};

$today=date('Y-m-d');
$tanggal=$_REQUEST['tanggal']??$today;
if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$tanggal))$tanggal=$today;
$id_kelas=(int)($_REQUEST['id_kelas']??0);
$id_tahun=(int)($_REQUEST['id_tahun_ajaran']??0);
$pesan='';$tipe='';

if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['aksi']??'')==='simpan'){
    if(!$has('id_siswa')||!$has('tanggal')||!$has('status')){
        $pesan='Struktur tabel absensi_siswa belum sesuai.';$tipe='error';
    }else{
        $tgl=$_POST['tanggal']??$today;$th=(int)($_POST['id_tahun_ajaran']??0);
        $statusList=$_POST['status']??[];$ketList=$_POST['keterangan']??[];
        $ok=0;
        foreach($statusList as $sid=>$status){
            $sid=(int)$sid;$status=trim((string)$status);if($sid<=0||$status==='')continue;
            $kelas=0;
            if($has('id_kelas')){
                $s=mysqli_prepare($koneksi,"SELECT id_kelas FROM siswa WHERE id_siswa=? LIMIT 1");
                if($s){mysqli_stmt_bind_param($s,"i",$sid);mysqli_stmt_execute($s);$rr=mysqli_stmt_get_result($s);$x=$rr?mysqli_fetch_assoc($rr):null;$kelas=(int)($x['id_kelas']??0);}
            }
            $exists=0;
            $primary_absensi=$has('id_absensi_siswa') ? 'id_absensi_siswa' : ($has('id_absensi') ? 'id_absensi' : '');
            if($primary_absensi!==''){
                $sqlc=$has('id_tahun_ajaran')
                    ?"SELECT `$primary_absensi` AS id_absensi FROM absensi_siswa WHERE id_siswa=? AND tanggal=? AND id_tahun_ajaran=? LIMIT 1"
                    :"SELECT `$primary_absensi` AS id_absensi FROM absensi_siswa WHERE id_siswa=? AND tanggal=? LIMIT 1";
                $c=mysqli_prepare($koneksi,$sqlc);
                if($c){
                    if($has('id_tahun_ajaran')){mysqli_stmt_bind_param($c,"isi",$sid,$tgl,$th);}
                    else{mysqli_stmt_bind_param($c,"is",$sid,$tgl);}
                    mysqli_stmt_execute($c);$rr=mysqli_stmt_get_result($c);$x=$rr?mysqli_fetch_assoc($rr):null;$exists=(int)($x['id_absensi']??0);
                }
            }
            $ket=trim((string)($ketList[$sid]??''));
            if($exists){
                $set=["status=?"];$vals=[$status];$types="s";
                if($has('id_kelas')){$set[]="id_kelas=?";$vals[]=$kelas;$types.="i";}
                if($has('keterangan')){$set[]="keterangan=?";$vals[]=$ket;$types.="s";}
                $vals[]=$exists;$types.="i";
                $st=mysqli_prepare($koneksi,"UPDATE absensi_siswa SET ".implode(',',$set)." WHERE `$primary_absensi`=?");
                if($st){mysqli_stmt_bind_param($st,$types,...$vals);if(mysqli_stmt_execute($st))$ok++;}
            }else{
                $f=["id_siswa","tanggal","status"];$v=[$sid,$tgl,$status];$types="iss";
                if($has('id_kelas')){$f[]="id_kelas";$v[]=$kelas;$types.="i";}
                if($has('id_tahun_ajaran')){$f[]="id_tahun_ajaran";$v[]=$th;$types.="i";}
                if($has('keterangan')){$f[]="keterangan";$v[]=$ket;$types.="s";}
                $marks=implode(',',array_fill(0,count($f),'?'));
                $st=mysqli_prepare($koneksi,"INSERT INTO absensi_siswa (`".implode('`,`',$f)."`) VALUES ($marks)");
                if($st){mysqli_stmt_bind_param($st,$types,...$v);if(mysqli_stmt_execute($st))$ok++;}
            }
        }
        header("Location:index.php?tanggal=".urlencode($tgl)."&id_kelas=".$id_kelas."&id_tahun_ajaran=".$th."&sukses=".$ok);exit;
    }
}
if(isset($_GET['sukses'])){$pesan='Absensi berhasil disimpan untuk '.(int)$_GET['sukses'].' siswa.';$tipe='success';}

$kelas=[];$q=mysqli_query($koneksi,"SELECT id_kelas,nama_kelas,tingkat FROM kelas ORDER BY tingkat,nama_kelas");
if($q)while($r=mysqli_fetch_assoc($q))$kelas[]=$r;

$tahun=[];if($has('id_tahun_ajaran')){$q=mysqli_query($koneksi,"SELECT id_tahun_ajaran,tahun_ajaran,semester,aktif FROM tahun_ajaran ORDER BY aktif DESC,id_tahun_ajaran DESC");if($q)while($r=mysqli_fetch_assoc($q))$tahun[]=$r;if(!$id_tahun && $tahun)$id_tahun=(int)$tahun[0]['id_tahun_ajaran'];}

$where="s.status_siswa='Aktif'";$ps=[];$ts='';
if($id_kelas){$where.=" AND s.id_kelas=?";$ps[]=$id_kelas;$ts='i';}
$st=mysqli_prepare($koneksi,"SELECT s.id_siswa,s.nis,s.nisn,s.nama_siswa,k.nama_kelas FROM siswa s LEFT JOIN kelas k ON k.id_kelas=s.id_kelas WHERE $where ORDER BY k.tingkat,k.nama_kelas,s.nama_siswa");
$siswa=[];if($st){if($ps)mysqli_stmt_bind_param($st,$ts,...$ps);mysqli_stmt_execute($st);$rr=mysqli_stmt_get_result($st);if($rr)while($r=mysqli_fetch_assoc($rr))$siswa[]=$r;}

$abs=[];$stats=['Hadir'=>0,'Sakit'=>0,'Izin'=>0,'Alpa'=>0];
if($has('id_siswa')&&$has('tanggal')&&$has('status')){
    $sql="SELECT id_siswa,status".($has('keterangan')?",keterangan":"")." FROM absensi_siswa WHERE tanggal=?";
    $av=[$tanggal];$at='s';
    if($has('id_tahun_ajaran')&&$id_tahun){$sql.=" AND id_tahun_ajaran=?";$av[]=$id_tahun;$at.='i';}
    $a=mysqli_prepare($koneksi,$sql);
    if($a){mysqli_stmt_bind_param($a,$at,...$av);mysqli_stmt_execute($a);$rr=mysqli_stmt_get_result($a);if($rr)while($r=mysqli_fetch_assoc($rr)){$abs[(int)$r['id_siswa']]=$r;$s=strtolower($r['status']);if(isset($stats[ucfirst($s)]))$stats[ucfirst($s)]++;elseif(in_array($s,['alpa','alpha']))$stats['Alpa']++;}}
}
require_once __DIR__ . "/../../../../includes/header.php";require_once __DIR__ . "/../../../../includes/sidebar.php";
?>
<style>
.abp{max-width:1450px}.ph{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}.ph h1{margin:0 0 6px}.ph p{margin:0}
.card{background:#fff;border-radius:18px;box-shadow:0 8px 25px rgba(15,35,70,.07);padding:20px;margin-bottom:20px}.grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:15px}
label{font-size:13px;font-weight:600;color:#334155}.fc,.st,.kt{width:100%;height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:0 11px;background:#fff}.btn{display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:10px;padding:11px 16px;font-weight:600;text-decoration:none;cursor:pointer}.pri{background:linear-gradient(135deg,#2388f5,#1265dc);color:#fff}.sec{background:#eef3f9;color:#334155}
.alert{padding:13px 15px;border-radius:11px;margin-bottom:18px;font-size:14px}.ok{background:#ecfdf3;color:#18794e;border:1px solid #ccefdc}.er{background:#fff1f2;color:#be123c;border:1px solid #fecdd3}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:18px}.stat{padding:15px;background:#f7f9fc;border-radius:13px}.stat strong{font-size:23px;display:block}.stat span{font-size:12px;color:#64748b}
.tw{overflow-x:auto}.dt{width:100%;border-collapse:collapse;min-width:900px}.dt th{background:#f7f9fc;color:#64748b;font-size:12px;text-transform:uppercase;padding:12px;text-align:left}.dt td{padding:11px 12px;border-bottom:1px solid #edf1f6}.nm{font-weight:700;color:#17233c}.sub{font-size:12px;color:#94a3b8}.st{min-width:120px}.kt{min-width:190px}
@media(max-width:800px){.grid3,.stats{grid-template-columns:1fr 1fr}}@media(max-width:600px){.grid3,.stats{grid-template-columns:1fr}.ph{align-items:flex-start;flex-direction:column;gap:10px}}
</style>
<main class="main-content"><div class="abp">
<div class="ph"><div><h1>Absensi Siswa</h1><p>Catat kehadiran siswa berdasarkan tanggal dan kelas.</p></div></div>
<?php if($pesan): ?><div class="alert <?= $tipe==='success'?'ok':'er'; ?>"><?= h($pesan); ?></div><?php endif; ?>
<div class="card"><form method="get"><div class="grid3">
<div><label>Tanggal</label><input class="fc" type="date" name="tanggal" value="<?=h($tanggal)?>"></div>
<div><label>Kelas</label><select class="fc" name="id_kelas"><option value="0">Semua Kelas</option><?php foreach($kelas as $k): ?><option value="<?=$k['id_kelas']?>" <?=$id_kelas==(int)$k['id_kelas']?'selected':''?>>Kelas <?=h($k['nama_kelas'])?></option><?php endforeach; ?></select></div>
<?php if($has('id_tahun_ajaran')):?><div><label>Tahun Ajaran / Semester</label><select class="fc" name="id_tahun_ajaran"><?php foreach($tahun as $t): ?><option value="<?=$t['id_tahun_ajaran']?>" <?=$id_tahun==(int)$t['id_tahun_ajaran']?'selected':''?>><?=h($t['tahun_ajaran'])?> - <?=h($t['semester'])?></option><?php endforeach;?></select></div><?php endif;?>
</div><div style="margin-top:15px;display:flex;gap:8px"><button class="btn pri">🔎 Tampilkan</button><a class="btn sec" href="index.php">Reset</a></div></form></div>
<div class="stats"><div class="stat"><strong><?=$stats['Hadir']?></strong><span>Hadir</span></div><div class="stat"><strong><?=$stats['Sakit']?></strong><span>Sakit</span></div><div class="stat"><strong><?=$stats['Izin']?></strong><span>Izin</span></div><div class="stat"><strong><?=$stats['Alpa']?></strong><span>Alpa</span></div></div>
<div class="card"><form method="post"><input type="hidden" name="aksi" value="simpan"><input type="hidden" name="tanggal" value="<?=h($tanggal)?>"><input type="hidden" name="id_tahun_ajaran" value="<?=$id_tahun?>"><div class="tw"><table class="dt"><thead><tr><th>No</th><th>NIS/NISN</th><th>Nama Siswa</th><th>Kelas</th><th>Status</th><?php if($has('keterangan')):?><th>Keterangan</th><?php endif;?></tr></thead><tbody>
<?php if($siswa):$no=1;foreach($siswa as $s):$a=$abs[(int)$s['id_siswa']]??[];$sn=$a['status']??'Hadir';$kn=$a['keterangan']??'';?>
<tr><td><?=$no++?></td><td><?=h($s['nis']?:'-')?><div class="sub">NISN: <?=h($s['nisn']?:'-')?></div></td><td><div class="nm"><?=h($s['nama_siswa'])?></div></td><td><?=h($s['nama_kelas']?:'-')?></td><td><select class="st" name="status[<?=$s['id_siswa']?>]"><?php foreach(['Hadir','Sakit','Izin','Alpa'] as $x):?><option <?=$sn===$x?'selected':''?>><?=$x?></option><?php endforeach;?></select></td><?php if($has('keterangan')):?><td><input class="kt" name="keterangan[<?=$s['id_siswa']?>]" value="<?=h($kn)?>" placeholder="Keterangan..."></td><?php endif;?></tr>
<?php endforeach;else:?><tr><td colspan="<?=$has('keterangan')?6:5?>" style="text-align:center;padding:40px;color:#94a3b8">Belum ada siswa aktif pada filter ini.</td></tr><?php endif;?>
</tbody></table></div><?php if($siswa):?><div style="margin-top:18px;text-align:right"><button class="btn pri">💾 Simpan Absensi</button></div><?php endif;?></form></div>
</div></main></body></html>
