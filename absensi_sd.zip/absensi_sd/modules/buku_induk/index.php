<?php
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator');

require_once "../../config/database.php";

$menu_aktif = 'buku';
$page_title = 'Buku Induk Siswa - Absensi SDN Ciburayut 01';

function h($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function n($v) {
    $v = trim((string)($v ?? ''));
    return $v === '' ? null : $v;
}

/*
 * Modul ini membaca kolom tabel buku_induk yang benar-benar ada.
 * Tujuannya agar tidak lagi error "Unknown column" ketika struktur
 * database berbeda dari rancangan awal.
 */
$columns = [];
$q_columns = mysqli_query($koneksi, "SHOW COLUMNS FROM buku_induk");

if ($q_columns) {
    while ($row = mysqli_fetch_assoc($q_columns)) {
        $columns[] = $row['Field'];
    }
}

$has_id_siswa = in_array('id_siswa', $columns, true);

$pesan = '';
$tipe_pesan = '';

/* Alias nama bidang agar tetap fleksibel */
$field_alias = [
    'tinggi_badan' => ['tinggi_badan', 'tinggi'],
    'berat_badan' => ['berat_badan', 'berat'],
    'lingkar_kepala' => ['lingkar_kepala', 'lingkar_kepala_cm'],
    'jarak_rumah_ke_sekolah' => ['jarak_rumah_ke_sekolah', 'jarak_rumah', 'jarak_rumah_sekolah'],
    'golongan_darah' => ['golongan_darah', 'goldar'],
    'penyakit_pernah_diderita' => ['penyakit_pernah_diderita', 'penyakit'],
    'kelainan_jasmani' => ['kelainan_jasmani', 'kelainan'],
    'asal_sekolah' => ['asal_sekolah'],
    'nomor_peserta_ujian' => ['nomor_peserta_ujian', 'no_peserta_ujian'],
    'nomor_ijazah' => ['nomor_ijazah', 'no_ijazah'],
    'tanggal_ijazah' => ['tanggal_ijazah'],
    'prestasi' => ['prestasi'],
    'catatan_wali_kelas' => ['catatan_wali_kelas', 'catatan_wali'],
    'catatan_kepala_sekolah' => ['catatan_kepala_sekolah', 'catatan_kepala']
];

$actual_fields = [];
foreach ($field_alias as $logical => $aliases) {
    foreach ($aliases as $candidate) {
        if (in_array($candidate, $columns, true)) {
            $actual_fields[$logical] = $candidate;
            break;
        }
    }
}

/* SIMPAN DINAMIS: hanya kolom yang benar-benar ada */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'simpan') {

    $id_siswa = (int)($_POST['id_siswa'] ?? 0);

    if (!$q_columns || !$has_id_siswa) {
        $pesan = 'Tabel buku_induk tidak memiliki kolom id_siswa.';
        $tipe_pesan = 'error';
    } elseif ($id_siswa <= 0) {
        $pesan = 'Siswa belum dipilih.';
        $tipe_pesan = 'error';
    } elseif (!$actual_fields) {
        $pesan = 'Tidak ada kolom data Buku Induk yang dikenali pada tabel buku_induk.';
        $tipe_pesan = 'error';
    } else {

        $cek = mysqli_prepare(
            $koneksi,
            "SELECT * FROM buku_induk WHERE id_siswa = ? LIMIT 1"
        );

        $ada = false;
        if ($cek) {
            mysqli_stmt_bind_param($cek, "i", $id_siswa);
            mysqli_stmt_execute($cek);
            $hasil = mysqli_stmt_get_result($cek);
            $ada = $hasil && mysqli_num_rows($hasil) > 0;
        }

        $fields_save = [];
        $values_save = [];
        $types = '';

        foreach ($actual_fields as $logical => $actual) {
            $fields_save[] = $actual;
            $values_save[] = n($_POST[$logical] ?? '');
            $types .= 's';
        }

        if ($ada) {

            $set = [];
            foreach ($fields_save as $field) {
                $set[] = "`$field` = ?";
            }

            $sql = "UPDATE buku_induk SET " . implode(', ', $set) . " WHERE id_siswa = ?";
            $stmt = mysqli_prepare($koneksi, $sql);

            if ($stmt) {
                $types_update = $types . 'i';
                $values_update = $values_save;
                $values_update[] = $id_siswa;

                mysqli_stmt_bind_param($stmt, $types_update, ...$values_update);

                if (mysqli_stmt_execute($stmt)) {
                    header("Location: index.php?id=" . $id_siswa . "&sukses=1");
                    exit;
                }

                $pesan = 'Buku Induk gagal diperbarui: ' . mysqli_stmt_error($stmt);
                $tipe_pesan = 'error';
            } else {
                $pesan = 'Gagal menyiapkan update Buku Induk: ' . mysqli_error($koneksi);
                $tipe_pesan = 'error';
            }

        } else {

            $insert_fields = ['id_siswa'];
            $insert_values = [$id_siswa];
            $insert_types = 'i';

            foreach ($fields_save as $index => $field) {
                $insert_fields[] = $field;
                $insert_values[] = $values_save[$index];
                $insert_types .= 's';
            }

            $quoted_fields = array_map(function($field) {
                return "`" . $field . "`";
            }, $insert_fields);

            $marks = implode(', ', array_fill(0, count($insert_fields), '?'));

            $sql = "INSERT INTO buku_induk (" .
                   implode(', ', $quoted_fields) .
                   ") VALUES ($marks)";

            $stmt = mysqli_prepare($koneksi, $sql);

            if ($stmt) {
                mysqli_stmt_bind_param($stmt, $insert_types, ...$insert_values);

                if (mysqli_stmt_execute($stmt)) {
                    header("Location: index.php?id=" . $id_siswa . "&sukses=1");
                    exit;
                }

                $pesan = 'Buku Induk gagal disimpan: ' . mysqli_stmt_error($stmt);
                $tipe_pesan = 'error';
            } else {
                $pesan = 'Gagal menyiapkan penyimpanan Buku Induk: ' . mysqli_error($koneksi);
                $tipe_pesan = 'error';
            }
        }
    }
}

if (isset($_GET['sukses'])) {
    $pesan = 'Buku Induk berhasil disimpan.';
    $tipe_pesan = 'success';
}

/* DAFTAR SISWA */
$daftar_siswa = [];
$q_siswa = mysqli_query(
    $koneksi,
    "SELECT
        s.id_siswa,
        s.nis,
        s.nisn,
        s.nama_siswa,
        k.nama_kelas, g.nama AS nama_wali_kelas
     FROM siswa s
     LEFT JOIN kelas k ON k.id_kelas = s.id_kelas
     LEFT JOIN guru g ON g.id_guru = k.id_wali_kelas
     WHERE s.status_siswa = 'Aktif'
     ORDER BY s.nama_siswa ASC"
);

if ($q_siswa) {
    while ($row = mysqli_fetch_assoc($q_siswa)) {
        $daftar_siswa[] = $row;
    }
}

/* SISWA TERPILIH */
$id_pilih = (int)($_GET['id'] ?? 0);
$siswa_pilih = null;
$buku = [];

if ($id_pilih > 0) {

    $stmt = mysqli_prepare(
        $koneksi,
        "SELECT s.id_siswa, s.nis, s.nisn, s.nama_siswa, k.nama_kelas, g.nama AS nama_wali_kelas
         FROM siswa s
         LEFT JOIN kelas k ON k.id_kelas = s.id_kelas
         LEFT JOIN guru g ON g.id_guru = k.id_wali_kelas
         WHERE s.id_siswa = ?
         LIMIT 1"
    );

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "i", $id_pilih);
        mysqli_stmt_execute($stmt);
        $r = mysqli_stmt_get_result($stmt);
        $siswa_pilih = $r ? mysqli_fetch_assoc($r) : null;
    }

    if ($has_id_siswa) {
        $stmt = mysqli_prepare($koneksi, "SELECT * FROM buku_induk WHERE id_siswa = ? LIMIT 1");
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "i", $id_pilih);
            mysqli_stmt_execute($stmt);
            $r = mysqli_stmt_get_result($stmt);
            $buku = $r ? (mysqli_fetch_assoc($r) ?: []) : [];
        }
    }

    /* Dapodik adalah sumber awal data. Isi Buku Induk otomatis dari master siswa
       jika field Buku Induk belum pernah diisi manual. */
    if ($siswa_pilih) {
        $qs = mysqli_prepare($koneksi, "SELECT * FROM siswa WHERE id_siswa = ? LIMIT 1");
        if ($qs) {
            mysqli_stmt_bind_param($qs, "i", $id_pilih);
            mysqli_stmt_execute($qs);
            $rs = mysqli_stmt_get_result($qs);
            $master = $rs ? (mysqli_fetch_assoc($rs) ?: []) : [];
            $fallback = [
                'tinggi_badan'=>'tinggi_badan','berat_badan'=>'berat_badan','lingkar_kepala'=>'lingkar_kepala',
                'jarak_rumah_ke_sekolah'=>'jarak_rumah_km','golongan_darah'=>'golongan_darah',
                'penyakit_pernah_diderita'=>'penyakit_pernah_diderita','kelainan_jasmani'=>'kelainan_jasmani',
                'asal_sekolah'=>'asal_sekolah','nomor_peserta_ujian'=>'nomor_peserta_ujian',
                'nomor_ijazah'=>'nomor_ijazah','tanggal_ijazah'=>'tanggal_ijazah',
                'prestasi'=>'prestasi','catatan_wali_kelas'=>'catatan_wali_kelas'
            ];
            foreach($fallback as $logical=>$col){
                if((!isset($buku[$col]) || trim((string)$buku[$col])==='') && isset($master[$col]) && trim((string)$master[$col])!=='') $buku[$col]=$master[$col];
            }
            /* Alias logis buku_induk yang tidak punya nama kolom identik. */
            if((!isset($buku['jarak_rumah_ke_sekolah']) || trim((string)$buku['jarak_rumah_ke_sekolah'])==='') && !empty($master['jarak_rumah_km'])) $buku['jarak_rumah_ke_sekolah']=$master['jarak_rumah_km'];
            if(!empty($master['ayah_pendidikan'])) $buku['pendidikan_ayah']=$buku['pendidikan_ayah']??$master['ayah_pendidikan'];
            if(!empty($master['ibu_pendidikan'])) $buku['pendidikan_ibu']=$buku['pendidikan_ibu']??$master['ibu_pendidikan'];
            if(!empty($master['ayah_pekerjaan'])) $buku['pekerjaan_ayah']=$buku['pekerjaan_ayah']??$master['ayah_pekerjaan'];
            if(!empty($master['ibu_pekerjaan'])) $buku['pekerjaan_ibu']=$buku['pekerjaan_ibu']??$master['ibu_pekerjaan'];
        }
    }
}

/* STATISTIK */
$total_siswa = 0;
$total_lengkap = 0;

$q_total = mysqli_query(
    $koneksi,
    "SELECT COUNT(*) AS total FROM siswa WHERE status_siswa = 'Aktif'"
);
if ($q_total) {
    $total_siswa = (int)(mysqli_fetch_assoc($q_total)['total'] ?? 0);
}

if ($has_id_siswa) {
    $q_lengkap = mysqli_query(
        $koneksi,
        "SELECT COUNT(*) AS total
         FROM buku_induk b
         INNER JOIN siswa s ON s.id_siswa = b.id_siswa
         WHERE s.status_siswa = 'Aktif'"
    );

    if ($q_lengkap) {
        $total_lengkap = (int)(mysqli_fetch_assoc($q_lengkap)['total'] ?? 0);
    }
}

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>

<style>
.buku-page{max-width:1450px}
.page-head{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:24px}
.page-head h1{margin-bottom:6px}.page-head p{margin:0}
.alert{padding:13px 15px;border-radius:11px;margin-bottom:18px;font-size:14px}
.alert-success{background:#ecfdf3;color:#18794e;border:1px solid #ccefdc}
.alert-error{background:#fff1f2;color:#be123c;border:1px solid #fecdd3}
.alert-info{background:#eef6ff;color:#1859a9;border:1px solid #cfe2ff}
.summary{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:15px;margin-bottom:22px}
.summary-card{background:#fff;border-radius:16px;padding:18px;box-shadow:0 8px 25px rgba(15,35,70,.07)}
.summary-number{font-size:28px;font-weight:800;color:#17233c}.summary-title{font-size:13px;color:#64748b;margin-top:4px}
.layout{display:grid;grid-template-columns:320px minmax(0,1fr);gap:20px;align-items:start}
.panel{background:#fff;border-radius:18px;box-shadow:0 8px 25px rgba(15,35,70,.07);padding:20px}
.panel-title{font-size:18px;font-weight:700;color:#17233c;margin:0 0 15px}
.search-box{width:100%;height:40px;border:1px solid #dbe4ef;border-radius:10px;padding:0 11px;margin-bottom:12px;outline:none}
.siswa-list{max-height:650px;overflow-y:auto;display:flex;flex-direction:column;gap:7px}
.siswa-item{display:block;padding:11px 12px;border-radius:10px;text-decoration:none;color:#334155;background:#f8fafc}
.siswa-item:hover,.siswa-item.active{background:#eef5ff;color:#1769d2}
.siswa-item strong{display:block}.siswa-item small{display:block;color:#94a3b8;margin-top:3px}
.student-info{padding:14px;border-radius:12px;background:#f7f9fc;margin-bottom:18px}
.student-info strong{display:block;color:#17233c;font-size:17px}.student-info span{display:block;color:#64748b;font-size:13px;margin-top:3px}
.form-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:15px}
.form-group{display:flex;flex-direction:column;gap:7px}.form-group.full{grid-column:1/-1}
.form-label{font-size:13px;font-weight:600;color:#334155}
.form-control{width:100%;min-height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:9px 11px;outline:none;background:#fff;font:inherit}
.form-control:focus{border-color:#2388f5;box-shadow:0 0 0 3px rgba(35,136,245,.1)}
textarea.form-control{min-height:86px;resize:vertical}
.section-title{grid-column:1/-1;font-size:14px;font-weight:800;color:#1769d2;padding-top:4px;margin-top:6px;border-bottom:1px solid #e8eef6;padding-bottom:7px}
.form-actions{display:flex;gap:9px;margin-top:20px}
.btn-primary,.btn-secondary{display:inline-flex;align-items:center;justify-content:center;gap:7px;border:0;border-radius:10px;padding:11px 16px;text-decoration:none;font-size:14px;font-weight:600;cursor:pointer}
.btn-primary{background:linear-gradient(135deg,#2388f5,#1265dc);color:#fff;box-shadow:0 8px 18px rgba(18,101,220,.22)}
.btn-secondary{background:#eef3f9;color:#334155}
.empty{text-align:center;padding:35px 10px;color:#94a3b8}
.columns-note{font-size:12px;color:#64748b;line-height:1.6;margin-top:12px}
@media(max-width:1050px){.layout{grid-template-columns:1fr}.siswa-list{max-height:300px}.form-grid{grid-template-columns:1fr 1fr}}
@media(max-width:650px){.summary{grid-template-columns:1fr}.form-grid{grid-template-columns:1fr}.form-group.full,.section-title{grid-column:auto}.page-head{flex-direction:column;align-items:flex-start}}
</style>

<main class="main-content">
<div class="buku-page">

<div class="page-head">
<div>
<h1>Buku Induk</h1>
<p>Kelola data perkembangan, kesehatan, pendidikan sebelumnya, dan catatan siswa.</p>
</div>
</div>

<?php if ($pesan !== ''): ?>
<div class="alert <?= $tipe_pesan === 'success' ? 'alert-success' : 'alert-error'; ?>">
<?= h($pesan); ?>
</div>
<?php endif; ?>

<div class="summary">
<div class="summary-card"><div class="summary-number"><?= $total_siswa; ?></div><div class="summary-title">Siswa Aktif</div></div>
<div class="summary-card"><div class="summary-number"><?= $total_lengkap; ?></div><div class="summary-title">Buku Induk Terisi</div></div>
<div class="summary-card"><div class="summary-number"><?= max(0,$total_siswa-$total_lengkap); ?></div><div class="summary-title">Belum Terisi</div></div>
</div>

<div class="layout">

<div class="panel">
<h2 class="panel-title">Pilih Siswa</h2>
<input type="text" id="cariSiswa" class="search-box" placeholder="Cari nama siswa...">

<div class="siswa-list" id="daftarSiswa">
<?php foreach ($daftar_siswa as $s): ?>
<a class="siswa-item <?= $id_pilih === (int)$s['id_siswa'] ? 'active' : ''; ?>"
   data-nama="<?= h(strtolower($s['nama_siswa'])); ?>"
   href="index.php?id=<?= (int)$s['id_siswa']; ?>">
<strong><?= h($s['nama_siswa']); ?></strong>
<small><?= h($s['nisn'] ?: $s['nis'] ?: '-'); ?> · Kelas <?= h($s['nama_kelas'] ?: '-'); ?> · Wali: <?= h($s['nama_wali_kelas'] ?: 'Belum ditentukan'); ?></small>
</a>
<?php endforeach; ?>

<?php if (!$daftar_siswa): ?>
<div class="empty">Belum ada siswa aktif.</div>
<?php endif; ?>
</div>
</div>

<div class="panel">

<?php if ($siswa_pilih): ?>

<div class="student-info">
<strong><?= h($siswa_pilih['nama_siswa']); ?></strong>
<span>
NIS: <?= h($siswa_pilih['nis'] ?: '-'); ?> ·
NISN: <?= h($siswa_pilih['nisn'] ?: '-'); ?> ·
Kelas: <?= h($siswa_pilih['nama_kelas'] ?: 'Belum ditentukan'); ?> · Wali Kelas: <?= h($siswa_pilih['nama_wali_kelas'] ?: 'Belum ditentukan'); ?>
</span>
</div>

<?php if (!$has_id_siswa): ?>

<div class="alert alert-error">
Tabel <strong>buku_induk</strong> tidak memiliki kolom <strong>id_siswa</strong>, sehingga modul tidak akan melakukan penyimpanan.
</div>

<?php else: ?>

<h2 class="panel-title">Data Buku Induk Siswa</h2>

<?php if (empty($actual_fields)): ?>
<div class="alert alert-info">
Struktur tabel terbaca, tetapi belum ada kolom Buku Induk yang dikenali oleh modul.
<div class="columns-note">
Kolom yang terbaca: <?= h(implode(', ', $columns)); ?>
</div>
</div>
<?php else: ?>

<form method="post">
<input type="hidden" name="aksi" value="simpan">
<input type="hidden" name="id_siswa" value="<?= $id_pilih; ?>">

<div class="form-grid">

<div class="section-title">Perkembangan Fisik</div>

<?php
$fields_sections = [
    'tinggi_badan' => ['Perkembangan Fisik', 'text'],
    'berat_badan' => ['Perkembangan Fisik', 'text'],
    'lingkar_kepala' => ['Perkembangan Fisik', 'text'],
    'jarak_rumah_ke_sekolah' => ['Perkembangan Fisik', 'text'],
    'golongan_darah' => ['Kesehatan', 'text'],
    'penyakit_pernah_diderita' => ['Kesehatan', 'textarea'],
    'kelainan_jasmani' => ['Kesehatan', 'textarea'],
    'asal_sekolah' => ['Pendidikan Sebelumnya', 'text'],
    'nomor_peserta_ujian' => ['Pendidikan Sebelumnya', 'text'],
    'nomor_ijazah' => ['Pendidikan Sebelumnya', 'text'],
    'tanggal_ijazah' => ['Pendidikan Sebelumnya', 'date'],
    'prestasi' => ['Prestasi & Catatan', 'textarea'],
    'catatan_wali_kelas' => ['Prestasi & Catatan', 'textarea'],
    'catatan_kepala_sekolah' => ['Prestasi & Catatan', 'textarea']
];

$last_section = 'Perkembangan Fisik';
foreach ($fields_sections as $logical => [$section, $type]):
    if (!isset($actual_fields[$logical])) continue;

    if ($section !== $last_section):
?>
<div class="section-title"><?= h($section); ?></div>
<?php
        $last_section = $section;
    endif;

    $field = $actual_fields[$logical];
    $value = $buku[$field] ?? '';
    $label = ucwords(str_replace('_', ' ', $logical));
?>
<div class="form-group <?= $type === 'textarea' ? 'full' : ''; ?>">
<label class="form-label"><?= h($label); ?></label>

<?php if ($type === 'textarea'): ?>
<textarea name="<?= h($logical); ?>" class="form-control"><?= h($value); ?></textarea>
<?php else: ?>
<input type="<?= $type === 'date' ? 'date' : 'text'; ?>"
       name="<?= h($logical); ?>"
       class="form-control"
       value="<?= h($value); ?>">
<?php endif; ?>

</div>
<?php endforeach; ?>

</div>

<div class="form-actions">
<button type="submit" class="btn-primary">💾 Simpan Buku Induk</button>
<a href="index.php" class="btn-secondary">Batal</a>
</div>
</form>

<div class="columns-note">
Kolom database yang dikenali: <?= h(implode(', ', array_values($actual_fields))); ?>
</div>

<?php endif; ?>

<?php endif; ?>

<?php else: ?>

<div class="empty">Pilih siswa di sebelah kiri untuk mengisi atau melihat Buku Induk.</div>

<?php endif; ?>

</div>
</div>

</div>
</main>

<script>
const inputCari = document.getElementById('cariSiswa');

if (inputCari) {
    inputCari.addEventListener('input', function () {
        const keyword = this.value.toLowerCase().trim();

        document.querySelectorAll('#daftarSiswa .siswa-item').forEach(function (item) {
            const nama = item.getAttribute('data-nama') || '';
            item.style.display = nama.includes(keyword) ? '' : 'none';
        });
    });
}
</script>

</body>
</html>
