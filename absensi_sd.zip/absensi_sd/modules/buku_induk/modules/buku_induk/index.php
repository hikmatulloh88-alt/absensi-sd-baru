<?php
require_once "../../config/database.php";

$menu_aktif = 'buku';
$page_title = 'Buku Induk Siswa - Absensi SDN Ciburayut 01';

function h($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function clean($v) {
    $v = trim((string)$v);
    return $v === '' ? null : $v;
}

function label_field($field) {
    $labels = [
        'tinggi_badan' => 'Tinggi Badan',
        'berat_badan' => 'Berat Badan',
        'lingkar_kepala' => 'Lingkar Kepala',
        'jarak_rumah_ke_sekolah' => 'Jarak Rumah ke Sekolah',
        'golongan_darah' => 'Golongan Darah',
        'penyakit_pernah_diderita' => 'Penyakit yang Pernah Diderita',
        'kelainan_jasmani' => 'Kelainan Jasmani',
        'asal_sekolah' => 'Asal Sekolah',
        'nomor_peserta_ujian' => 'Nomor Peserta Ujian',
        'nomor_ijazah' => 'Nomor Ijazah',
        'tanggal_ijazah' => 'Tanggal Ijazah',
        'prestasi' => 'Prestasi',
        'catatan_wali_kelas' => 'Catatan Wali Kelas',
        'catatan_kepala_sekolah' => 'Catatan Kepala Sekolah'
    ];
    return $labels[$field] ?? ucwords(str_replace('_', ' ', $field));
}

$pesan = '';
$tipe_pesan = '';

/* SIMPAN */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'simpan') {
    $id_siswa = (int)($_POST['id_siswa'] ?? 0);

    if ($id_siswa <= 0) {
        $pesan = 'Siswa belum dipilih.';
        $tipe_pesan = 'error';
    } else {
        $fields = [
            'tinggi_badan',
            'berat_badan',
            'lingkar_kepala',
            'jarak_rumah_ke_sekolah',
            'golongan_darah',
            'penyakit_pernah_diderita',
            'kelainan_jasmani',
            'asal_sekolah',
            'nomor_peserta_ujian',
            'nomor_ijazah',
            'tanggal_ijazah',
            'prestasi',
            'catatan_wali_kelas',
            'catatan_kepala_sekolah'
        ];

        $values = [];
        foreach ($fields as $field) {
            $values[$field] = clean($_POST[$field] ?? '');
        }

        try {
            $cek = mysqli_prepare(
                $koneksi,
                "SELECT id_buku_induk FROM buku_induk WHERE id_siswa = ? LIMIT 1"
            );
            mysqli_stmt_bind_param($cek, "i", $id_siswa);
            mysqli_stmt_execute($cek);
            $hasil_cek = mysqli_stmt_get_result($cek);
            $ada = $hasil_cek && mysqli_num_rows($hasil_cek) > 0;

            if ($ada) {
                $sql = "UPDATE buku_induk SET
                            tinggi_badan = ?, berat_badan = ?, lingkar_kepala = ?,
                            jarak_rumah_ke_sekolah = ?, golongan_darah = ?,
                            penyakit_pernah_diderita = ?, kelainan_jasmani = ?,
                            asal_sekolah = ?, nomor_peserta_ujian = ?, nomor_ijazah = ?,
                            tanggal_ijazah = ?, prestasi = ?, catatan_wali_kelas = ?,
                            catatan_kepala_sekolah = ?
                        WHERE id_siswa = ?";

                $stmt = mysqli_prepare($koneksi, $sql);

                mysqli_stmt_bind_param(
                    $stmt,
                    "sssssssssssssssi",
                    $values['tinggi_badan'],
                    $values['berat_badan'],
                    $values['lingkar_kepala'],
                    $values['jarak_rumah_ke_sekolah'],
                    $values['golongan_darah'],
                    $values['penyakit_pernah_diderita'],
                    $values['kelainan_jasmani'],
                    $values['asal_sekolah'],
                    $values['nomor_peserta_ujian'],
                    $values['nomor_ijazah'],
                    $values['tanggal_ijazah'],
                    $values['prestasi'],
                    $values['catatan_wali_kelas'],
                    $values['catatan_kepala_sekolah'],
                    $id_siswa
                );
            } else {
                $sql = "INSERT INTO buku_induk (
                            id_siswa, tinggi_badan, berat_badan, lingkar_kepala,
                            jarak_rumah_ke_sekolah, golongan_darah,
                            penyakit_pernah_diderita, kelainan_jasmani,
                            asal_sekolah, nomor_peserta_ujian, nomor_ijazah,
                            tanggal_ijazah, prestasi, catatan_wali_kelas,
                            catatan_kepala_sekolah
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                $stmt = mysqli_prepare($koneksi, $sql);

                mysqli_stmt_bind_param(
                    $stmt,
                    "issssssssssssss",
                    $id_siswa,
                    $values['tinggi_badan'],
                    $values['berat_badan'],
                    $values['lingkar_kepala'],
                    $values['jarak_rumah_ke_sekolah'],
                    $values['golongan_darah'],
                    $values['penyakit_pernah_diderita'],
                    $values['kelainan_jasmani'],
                    $values['asal_sekolah'],
                    $values['nomor_peserta_ujian'],
                    $values['nomor_ijazah'],
                    $values['tanggal_ijazah'],
                    $values['prestasi'],
                    $values['catatan_wali_kelas'],
                    $values['catatan_kepala_sekolah']
                );
            }

            if (!empty($stmt) && mysqli_stmt_execute($stmt)) {
                header("Location: index.php?sukses=1");
                exit;
            }

            $pesan = 'Buku induk gagal disimpan: ' . mysqli_error($koneksi);
            $tipe_pesan = 'error';

        } catch (Throwable $e) {
            $pesan = 'Buku induk gagal disimpan. Periksa tabel buku_induk.';
            $tipe_pesan = 'error';
        }
    }
}

if (isset($_GET['sukses'])) {
    $pesan = 'Buku induk berhasil disimpan.';
    $tipe_pesan = 'success';
}

/* SISWA YANG AKTIF */
$daftar_siswa = [];
$q_siswa = mysqli_query(
    $koneksi,
    "SELECT
        s.id_siswa, s.nis, s.nisn, s.nama_siswa,
        s.jenis_kelamin, k.nama_kelas, g.nama AS nama_wali_kelas
     FROM siswa s
     LEFT JOIN kelas k ON k.id_kelas = s.id_kelas
     LEFT JOIN guru g ON g.id_guru = k.id_wali_kelas
     WHERE s.status_siswa = 'Aktif'
     ORDER BY s.nama_siswa ASC"
);

if ($q_siswa) {
    while ($row = mysqli_fetch_assoc($q_siswa)) {
        $daftar_siswa[] = $row;
    }
}

/* SISWA TERPILIH */
$id_pilih = (int)($_GET['id'] ?? 0);
$buku = [];

if ($id_pilih > 0) {
    $stmt = mysqli_prepare(
        $koneksi,
        "SELECT * FROM buku_induk WHERE id_siswa = ? LIMIT 1"
    );
    mysqli_stmt_bind_param($stmt, "i", $id_pilih);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $buku = $result ? (mysqli_fetch_assoc($result) ?: []) : [];
}

/* REKAP KELENGKAPAN */
$total_siswa = 0;
$total_lengkap = 0;

$q_total = mysqli_query(
    $koneksi,
    "SELECT COUNT(*) AS total FROM siswa WHERE status_siswa = 'Aktif'"
);
if ($q_total) {
    $total_siswa = (int)mysqli_fetch_assoc($q_total)['total'];
}

$q_lengkap = mysqli_query(
    $koneksi,
    "SELECT COUNT(*) AS total
     FROM buku_induk b
     INNER JOIN siswa s ON s.id_siswa = b.id_siswa
     WHERE s.status_siswa = 'Aktif'"
);
if ($q_lengkap) {
    $total_lengkap = (int)mysqli_fetch_assoc($q_lengkap)['total'];
}

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>

<style>
.buku-page{max-width:1450px}
.page-head{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:24px}
.page-head h1{margin-bottom:6px}.page-head p{margin:0}
.btn-primary,.btn-secondary{display:inline-flex;align-items:center;justify-content:center;gap:7px;border:0;border-radius:10px;padding:11px 16px;text-decoration:none;font-size:14px;font-weight:600;cursor:pointer}
.btn-primary{background:linear-gradient(135deg,#2388f5,#1265dc);color:#fff;box-shadow:0 8px 18px rgba(18,101,220,.22)}
.btn-secondary{background:#eef3f9;color:#334155}
.alert{padding:13px 15px;border-radius:11px;margin-bottom:18px;font-size:14px}
.alert-success{background:#ecfdf3;color:#18794e;border:1px solid #ccefdc}
.alert-error{background:#fff1f2;color:#be123c;border:1px solid #fecdd3}
.summary{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:15px;margin-bottom:22px}
.summary-card{background:#fff;border-radius:16px;padding:18px;box-shadow:0 8px 25px rgba(15,35,70,.07)}
.summary-number{font-size:28px;font-weight:800;color:#17233c}.summary-title{font-size:13px;color:#64748b;margin-top:4px}
.layout{display:grid;grid-template-columns:320px minmax(0,1fr);gap:20px;align-items:start}
.panel{background:#fff;border-radius:18px;box-shadow:0 8px 25px rgba(15,35,70,.07);padding:20px}
.panel-title{font-size:18px;font-weight:700;color:#17233c;margin:0 0 15px}
.siswa-list{max-height:620px;overflow-y:auto;display:flex;flex-direction:column;gap:7px}
.siswa-item{display:block;padding:11px 12px;border-radius:10px;text-decoration:none;color:#334155;background:#f8fafc}
.siswa-item:hover,.siswa-item.active{background:#eef5ff;color:#1769d2}
.siswa-item strong{display:block}.siswa-item small{display:block;color:#94a3b8;margin-top:3px}
.search-box{width:100%;height:40px;border:1px solid #dbe4ef;border-radius:10px;padding:0 11px;margin-bottom:12px;outline:none}
.form-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:15px}
.form-group{display:flex;flex-direction:column;gap:7px}.form-group.full{grid-column:1/-1}
.form-label{font-size:13px;font-weight:600;color:#334155}
.form-control{width:100%;min-height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:9px 11px;outline:none;background:#fff;font:inherit}
.form-control:focus{border-color:#2388f5;box-shadow:0 0 0 3px rgba(35,136,245,.1)}
textarea.form-control{min-height:86px;resize:vertical}
.form-actions{display:flex;gap:9px;margin-top:20px}
.student-info{padding:14px;border-radius:12px;background:#f7f9fc;margin-bottom:18px}
.student-info strong{display:block;color:#17233c;font-size:17px}.student-info span{display:block;color:#64748b;font-size:13px;margin-top:3px}
.section-title{grid-column:1/-1;font-size:14px;font-weight:800;color:#1769d2;padding-top:4px;margin-top:5px;border-bottom:1px solid #e8eef6;padding-bottom:7px}
.empty{color:#94a3b8;text-align:center;padding:35px 10px}
@media(max-width:1050px){.layout{grid-template-columns:1fr}.siswa-list{max-height:300px}.form-grid{grid-template-columns:1fr 1fr}}
@media(max-width:650px){.summary{grid-template-columns:1fr}.form-grid{grid-template-columns:1fr}.form-group.full,.section-title{grid-column:auto}.page-head{flex-direction:column;align-items:flex-start}}
</style>

<main class="main-content">
<div class="buku-page">

<div class="page-head">
<div>
<h1>Buku Induk</h1>
<p>Kelola data perkembangan, kesehatan, pendidikan sebelumnya, dan catatan siswa.</p>
</div>
</div>

<?php if ($pesan !== ''): ?>
<div class="alert <?= $tipe_pesan === 'success' ? 'alert-success' : 'alert-error'; ?>">
<?= h($pesan); ?>
</div>
<?php endif; ?>

<div class="summary">
<div class="summary-card">
<div class="summary-number"><?= $total_siswa; ?></div>
<div class="summary-title">Siswa Aktif</div>
</div>
<div class="summary-card">
<div class="summary-number"><?= $total_lengkap; ?></div>
<div class="summary-title">Buku Induk Terisi</div>
</div>
<div class="summary-card">
<div class="summary-number"><?= max(0, $total_siswa - $total_lengkap); ?></div>
<div class="summary-title">Belum Terisi</div>
</div>
</div>

<div class="layout">

<div class="panel">
<h2 class="panel-title">Pilih Siswa</h2>
<input type="text" id="cariSiswa" class="search-box" placeholder="Cari nama siswa...">

<div class="siswa-list" id="daftarSiswa">
<?php foreach ($daftar_siswa as $s): ?>
<a class="siswa-item <?= $id_pilih === (int)$s['id_siswa'] ? 'active' : ''; ?>"
   data-nama="<?= h(strtolower($s['nama_siswa'])); ?>"
   href="index.php?id=<?= (int)$s['id_siswa']; ?>">
<strong><?= h($s['nama_siswa']); ?></strong>
<small>
<?= h($s['nisn'] ?: $s['nis'] ?: '-'); ?> · Kelas <?= h($s['nama_kelas'] ?: '-'); ?>
</small>
</a>
<?php endforeach; ?>

<?php if (!$daftar_siswa): ?>
<div class="empty">Belum ada siswa aktif.</div>
<?php endif; ?>
</div>
</div>

<div class="panel">

<?php if ($id_pilih > 0): ?>

<?php
$info_siswa = null;
$stmt_info = mysqli_prepare(
    $koneksi,
    "SELECT s.nama_siswa, s.nis, s.nisn, k.nama_kelas, g.nama AS nama_wali_kelas
     FROM siswa s
     LEFT JOIN kelas k ON k.id_kelas = s.id_kelas
     LEFT JOIN guru g ON g.id_guru = k.id_wali_kelas
     WHERE s.id_siswa = ? LIMIT 1"
);
if ($stmt_info) {
    mysqli_stmt_bind_param($stmt_info, "i", $id_pilih);
    mysqli_stmt_execute($stmt_info);
    $r_info = mysqli_stmt_get_result($stmt_info);
    $info_siswa = $r_info ? mysqli_fetch_assoc($r_info) : null;
}
?>

<?php if ($info_siswa): ?>
<div class="student-info">
<strong><?= h($info_siswa['nama_siswa']); ?></strong>
<span>NIS: <?= h($info_siswa['nis'] ?: '-'); ?> · NISN: <?= h($info_siswa['nisn'] ?: '-'); ?> · Kelas: <?= h($info_siswa['nama_kelas'] ?: 'Belum ditentukan'); ?></span>
</div>
<?php endif; ?>

<h2 class="panel-title">Data Buku Induk Siswa</h2>

<form method="post">
<input type="hidden" name="aksi" value="simpan">
<input type="hidden" name="id_siswa" value="<?= $id_pilih; ?>">

<div class="form-grid">

<div class="section-title">Perkembangan Fisik</div>

<div class="form-group">
<label class="form-label">Tinggi Badan</label>
<input type="text" name="tinggi_badan" class="form-control" value="<?= h($buku['tinggi_badan'] ?? ''); ?>" placeholder="Contoh: 125 cm">
</div>

<div class="form-group">
<label class="form-label">Berat Badan</label>
<input type="text" name="berat_badan" class="form-control" value="<?= h($buku['berat_badan'] ?? ''); ?>" placeholder="Contoh: 27 kg">
</div>

<div class="form-group">
<label class="form-label">Lingkar Kepala</label>
<input type="text" name="lingkar_kepala" class="form-control" value="<?= h($buku['lingkar_kepala'] ?? ''); ?>">
</div>

<div class="form-group full">
<label class="form-label">Jarak Rumah ke Sekolah</label>
<input type="text" name="jarak_rumah_ke_sekolah" class="form-control" value="<?= h($buku['jarak_rumah_ke_sekolah'] ?? ''); ?>" placeholder="Contoh: 2 km">
</div>

<div class="section-title">Kesehatan</div>

<div class="form-group">
<label class="form-label">Golongan Darah</label>
<input type="text" name="golongan_darah" class="form-control" value="<?= h($buku['golongan_darah'] ?? ''); ?>" placeholder="A / B / AB / O">
</div>

<div class="form-group full">
<label class="form-label">Penyakit yang Pernah Diderita</label>
<textarea name="penyakit_pernah_diderita" class="form-control"><?= h($buku['penyakit_pernah_diderita'] ?? ''); ?></textarea>
</div>

<div class="form-group full">
<label class="form-label">Kelainan Jasmani</label>
<textarea name="kelainan_jasmani" class="form-control"><?= h($buku['kelainan_jasmani'] ?? ''); ?></textarea>
</div>

<div class="section-title">Pendidikan Sebelumnya</div>

<div class="form-group">
<label class="form-label">Asal Sekolah</label>
<input type="text" name="asal_sekolah" class="form-control" value="<?= h($buku['asal_sekolah'] ?? ''); ?>">
</div>

<div class="form-group">
<label class="form-label">Nomor Peserta Ujian</label>
<input type="text" name="nomor_peserta_ujian" class="form-control" value="<?= h($buku['nomor_peserta_ujian'] ?? ''); ?>">
</div>

<div class="form-group">
<label class="form-label">Nomor Ijazah</label>
<input type="text" name="nomor_ijazah" class="form-control" value="<?= h($buku['nomor_ijazah'] ?? ''); ?>">
</div>

<div class="form-group">
<label class="form-label">Tanggal Ijazah</label>
<input type="date" name="tanggal_ijazah" class="form-control" value="<?= h($buku['tanggal_ijazah'] ?? ''); ?>">
</div>

<div class="section-title">Prestasi & Catatan</div>

<div class="form-group full">
<label class="form-label">Prestasi</label>
<textarea name="prestasi" class="form-control"><?= h($buku['prestasi'] ?? ''); ?></textarea>
</div>

<div class="form-group full">
<label class="form-label">Catatan Wali Kelas</label>
<textarea name="catatan_wali_kelas" class="form-control"><?= h($buku['catatan_wali_kelas'] ?? ''); ?></textarea>
</div>

<div class="form-group full">
<label class="form-label">Catatan Kepala Sekolah</label>
<textarea name="catatan_kepala_sekolah" class="form-control"><?= h($buku['catatan_kepala_sekolah'] ?? ''); ?></textarea>
</div>

</div>

<div class="form-actions">
<button type="submit" class="btn-primary">💾 Simpan Buku Induk</button>
<a href="index.php" class="btn-secondary">Batal</a>
</div>
</form>

<?php else: ?>

<div class="empty">
Pilih siswa di sebelah kiri untuk mengisi atau melihat Buku Induk.
</div>

<?php endif; ?>

</div>
</div>

</div>
</main>

<script>
const inputCari = document.getElementById('cariSiswa');

if (inputCari) {
    inputCari.addEventListener('input', function () {
        const keyword = this.value.toLowerCase().trim();

        document.querySelectorAll('#daftarSiswa .siswa-item').forEach(function (item) {
            const nama = item.getAttribute('data-nama') || '';
            item.style.display = nama.includes(keyword) ? '' : 'block';
        });
    });
}
</script>

</body>
</html>
