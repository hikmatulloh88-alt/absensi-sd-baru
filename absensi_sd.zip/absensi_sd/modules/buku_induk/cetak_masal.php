<?php
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator');
require_once "../../config/database.php";

$menu_aktif = 'buku_induk_masal';
$page_title = 'Cetak Buku Induk Masal - SDN Ciburayut 01';
function h($v){ return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8'); }
function v($row,$keys,$default=''){
    foreach((array)$keys as $k){ if(isset($row[$k]) && trim((string)$row[$k])!=='') return $row[$k]; }
    return $default;
}
function kelas_tampil($s){ return trim(preg_replace('/^kelas\s+/i','',(string)$s)); }
function tanggal_id($d){
    if(!$d || $d==='0000-00-00') return '';
    $t=strtotime($d); return $t?date('d-m-Y',$t):$d;
}
function norm_mapel($s){
    $s=strtolower(trim((string)$s));
    $s=str_replace(['pendidikan agama islam','pendidikan agama','pai'],'agama',$s);
    $s=str_replace(['pendidikan pancasila dan kewarganegaraan','pendidikan pancasila','ppkn'],'ppkn',$s);
    $s=str_replace(['ilmu pengetahuan alam','ipa'],'ipa',$s);
    $s=str_replace(['ilmu pengetahuan sosial','ips'],'ips',$s);
    $s=str_replace(['pendidikan jasmani olahraga dan kesehatan','pendidikan jasmani','pjok','penjaskes'],'penjaskes',$s);
    $s=str_replace(['bahasa sunda','bahasa jawa','bahasa daerah','b. daerah'],'daerah',$s);
    $s=preg_replace('/[^a-z0-9]+/','',$s);
    return $s;
}

$id_kelas=(int)($_GET['id_kelas']??0);
$kelas=[];
/* Ambil kelas dari tabel kelas terlebih dahulu. Jangan menggantungkan daftar kelas
   pada JOIN tahun_ajaran/guru agar dropdown tetap bekerja walau data referensi belum lengkap. */
$qk=mysqli_query($koneksi,"SELECT id_kelas,nama_kelas,tingkat,id_wali_kelas,id_tahun_ajaran FROM kelas WHERE status='Aktif' ORDER BY tingkat,nama_kelas");
if($qk){
    while($r=mysqli_fetch_assoc($qk)){
        $r['nama_wali_kelas']=''; $r['tahun_ajaran']=''; $r['semester']='';
        if(!empty($r['id_wali_kelas'])){
            $idw=(int)$r['id_wali_kelas'];
            $qw=mysqli_query($koneksi,"SELECT nama FROM guru WHERE id_guru=$idw LIMIT 1");
            if($qw && ($rw=mysqli_fetch_assoc($qw))) $r['nama_wali_kelas']=$rw['nama'] ?? '';
        }
        if(!empty($r['id_tahun_ajaran'])){
            $idt=(int)$r['id_tahun_ajaran'];
            $qt=mysqli_query($koneksi,"SELECT tahun_ajaran,semester FROM tahun_ajaran WHERE id_tahun_ajaran=$idt LIMIT 1");
            if($qt && ($rt=mysqli_fetch_assoc($qt))){ $r['tahun_ajaran']=$rt['tahun_ajaran'] ?? ''; $r['semester']=$rt['semester'] ?? ''; }
        }
        $kelas[]=$r;
    }
}

$kelas_terpilih=null;
if($id_kelas){
    $st=mysqli_prepare($koneksi,"SELECT id_kelas,nama_kelas,tingkat,id_wali_kelas,id_tahun_ajaran FROM kelas WHERE id_kelas=? LIMIT 1");
    if($st){
        mysqli_stmt_bind_param($st,'i',$id_kelas); mysqli_stmt_execute($st); $rr=mysqli_stmt_get_result($st); $kelas_terpilih=$rr?mysqli_fetch_assoc($rr):null;
        if($kelas_terpilih){
            $kelas_terpilih['nama_wali_kelas']=''; $kelas_terpilih['tahun_ajaran']=''; $kelas_terpilih['semester']='';
            if(!empty($kelas_terpilih['id_wali_kelas'])){ $idw=(int)$kelas_terpilih['id_wali_kelas']; $qw=mysqli_query($koneksi,"SELECT nama FROM guru WHERE id_guru=$idw LIMIT 1"); if($qw && ($rw=mysqli_fetch_assoc($qw))) $kelas_terpilih['nama_wali_kelas']=$rw['nama']??''; }
            if(!empty($kelas_terpilih['id_tahun_ajaran'])){ $idt=(int)$kelas_terpilih['id_tahun_ajaran']; $qt=mysqli_query($koneksi,"SELECT tahun_ajaran,semester FROM tahun_ajaran WHERE id_tahun_ajaran=$idt LIMIT 1"); if($qt && ($rt=mysqli_fetch_assoc($qt))){$kelas_terpilih['tahun_ajaran']=$rt['tahun_ajaran']??'';$kelas_terpilih['semester']=$rt['semester']??'';} }
        }
    }
}

$siswa=[];
if($id_kelas){
    $sql="SELECT s.*,k.nama_kelas,k.tingkat,k.id_wali_kelas,g.nama AS nama_wali_kelas,ta.tahun_ajaran,ta.semester FROM siswa s LEFT JOIN kelas k ON k.id_kelas=s.id_kelas LEFT JOIN guru g ON g.id_guru=k.id_wali_kelas LEFT JOIN tahun_ajaran ta ON ta.id_tahun_ajaran=k.id_tahun_ajaran WHERE s.status_siswa='Aktif' AND s.id_kelas=? ORDER BY s.nama_siswa";
    $st=mysqli_prepare($koneksi,$sql);
    if($st){ mysqli_stmt_bind_param($st,'i',$id_kelas); mysqli_stmt_execute($st); $rs=mysqli_stmt_get_result($st); while($rs && ($r=mysqli_fetch_assoc($rs))) $siswa[]=$r; }
}

/* Buku induk: fleksibel terhadap struktur tabel yang sudah ada. */
$bi_cols=[]; $qbi=mysqli_query($koneksi,"SHOW COLUMNS FROM buku_induk");
if($qbi) while($r=mysqli_fetch_assoc($qbi)) $bi_cols[]=$r['Field'];
$bi=[];
if($siswa){
    $ids=implode(',',array_map(fn($x)=>(int)$x['id_siswa'],$siswa));
    if($ids){ $qb=mysqli_query($koneksi,"SELECT * FROM buku_induk WHERE id_siswa IN ($ids)"); if($qb) while($r=mysqli_fetch_assoc($qb)) $bi[(int)$r['id_siswa']]=$r; }
}

/* Nilai historis untuk halaman 3. Jika tabel belum tersedia, tabel tetap dicetak kosong sesuai template. */
$nilai=[]; $nilai_cols=[]; $qncol=mysqli_query($koneksi,"SHOW COLUMNS FROM nilai");
if($qncol) while($r=mysqli_fetch_assoc($qncol)) $nilai_cols[]=$r['Field'];
if($siswa && $nilai_cols){
    $ids=implode(',',array_map(fn($x)=>(int)$x['id_siswa'],$siswa));
    $qv=mysqli_query($koneksi,"SELECT n.id_siswa,n.id_tahun_ajaran,n.id_kelas,n.id_mapel,n.nilai_akhir,ta.tahun_ajaran,ta.semester,k.tingkat,mp.nama_mapel FROM nilai n LEFT JOIN tahun_ajaran ta ON ta.id_tahun_ajaran=n.id_tahun_ajaran LEFT JOIN kelas k ON k.id_kelas=n.id_kelas LEFT JOIN mata_pelajaran mp ON mp.id_mapel=n.id_mapel WHERE n.id_siswa IN ($ids)");
    if($qv) while($r=mysqli_fetch_assoc($qv)) $nilai[(int)$r['id_siswa']][]=$r;
}

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>
<style>
.bi-page{max-width:1500px}.head{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px}.head h1{margin:0 0 5px}.head p{margin:0;color:#64748b}.card{background:#fff;border-radius:18px;padding:20px;margin-bottom:18px;box-shadow:0 8px 25px rgba(15,35,70,.07)}
.filters{display:grid;grid-template-columns:1fr auto;gap:12px;align-items:end}.fc{width:100%;height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:0 10px;background:#fff}.lbl{font-size:13px;font-weight:700;color:#334155;display:block;margin-bottom:7px}.btn{border:0;border-radius:10px;padding:11px 16px;font-weight:700;cursor:pointer}.pri{background:#1265dc;color:#fff}.info{padding:12px 14px;background:#eef6ff;border:1px solid #d6e8fb;border-radius:10px;color:#245c9b;font-size:13px}.empty{text-align:center;padding:40px;color:#94a3b8}
/* Lembar mengikuti PDF sumber: Letter portrait halaman 1-2, Letter landscape halaman 3. */
.bi-sheet{position:relative;width:612pt;height:792pt;margin:0 auto 20px;background:#fff url('../../assets/images/buku_induk_template/page1.png') center/100% 100% no-repeat;overflow:hidden}
.bi-sheet.p2{background-image:url('../../assets/images/buku_induk_template/page2.png')}
.bi-sheet.p3{width:792pt;height:612pt;background-image:url('../../assets/images/buku_induk_template/page3.png')}
.ov{position:absolute;z-index:2;font-family:Arial,Helvetica,sans-serif;font-size:9pt;line-height:1.05;color:#111;white-space:nowrap;background:#fff;padding:0 2px;min-width:10px}
.ov.center{text-align:center}.photo{position:absolute;z-index:3;object-fit:cover;background:#fff}
.print-only{display:block}
@media print{
 @page portraitbi{size:letter portrait;margin:0} @page landscapebi{size:letter landscape;margin:0}
 body{background:#fff!important}.sidebar,.head,.filter-card,.no-print{display:none!important}.main-content{margin:0!important;padding:0!important}.bi-page{max-width:none!important}
 .bi-sheet{page:portraitbi;width:612pt;height:792pt;margin:0;break-after:page;background-image:url('../../assets/images/buku_induk_template/page1.png')!important;background-size:100% 100%!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
 .bi-sheet.p2{page:portraitbi;background-image:url('../../assets/images/buku_induk_template/page2.png')!important}.bi-sheet.p3{page:landscapebi;width:792pt;height:612pt;background-image:url('../../assets/images/buku_induk_template/page3.png')!important}.bi-sheet:last-child{break-after:auto}
 .ov{font-size:9pt}.print-only{display:block}
}
</style>
<main class="main-content"><div class="bi-page">
<div class="head"><div><h1>Cetak Buku Induk Masal</h1><p>Template cetak mengikuti file <strong>BUKU INDUK SDN CIBURAYUT 01.pdf</strong> secara utuh (3 halaman per siswa).</p></div></div>
<div class="card filter-card no-print"><form method="get" id="formPilihKelas"><div class="filters"><div><label class="lbl">Pilih Kelas</label><select class="fc" name="id_kelas" id="id_kelas" onchange="document.getElementById('formPilihKelas').submit()"><option value="0">Pilih Kelas</option><?php foreach($kelas as $k): ?><?php $jml=0; $qj=mysqli_query($koneksi,"SELECT COUNT(*) AS jml FROM siswa WHERE id_kelas=".(int)$k['id_kelas']." AND status_siswa='Aktif'"); if($qj && ($rj=mysqli_fetch_assoc($qj))) $jml=(int)$rj['jml']; ?><option value="<?=h($k['id_kelas'])?>" <?=$id_kelas==(int)$k['id_kelas']?'selected':''?>><?=h($k['nama_kelas'])?><?php if($k['nama_wali_kelas']) echo ' — '.h($k['nama_wali_kelas']); ?> (<?=$jml?> siswa)</option><?php endforeach;?></select></div><button class="btn pri" type="submit">🔎 Tampilkan</button></div></form></div>
<?php if(!$kelas): ?><div class="card"><div class="info">Belum ada kelas aktif pada database. Silakan buat/aktifkan kelas di menu Data Kelas terlebih dahulu.</div></div>
<?php elseif(!$id_kelas): ?><div class="card"><div class="info">Pilih kelas untuk melihat preview Buku Induk. Hasil cetak menggunakan layout asli: halaman 1 portrait, halaman 2 portrait, halaman 3 landscape.</div></div>
<?php elseif(!$siswa): ?><div class="card"><div class="info"><strong>Kelas <?=h($kelas_terpilih['nama_kelas']??'')?> belum memiliki siswa aktif.</strong><br>Silakan cek <strong>Data Siswa → Kelas</strong>. Buku Induk Masal hanya mencetak siswa yang berasal dari Data Siswa dan berstatus <strong>Aktif</strong>.</div></div>
<?php else: ?>
<div class="card no-print"><div class="info"><strong><?=count($siswa)?> siswa</strong> — Kelas <?=h($kelas_terpilih['nama_kelas']??'')?><?php if(!empty($kelas_terpilih['nama_wali_kelas'])) echo ' — Wali Kelas: '.h($kelas_terpilih['nama_wali_kelas']); ?><br><button type="button" class="btn pri" style="margin-top:10px" onclick="window.print()">🖨️ Cetak Semua Buku Induk</button></div></div>
<div class="print-only">
<?php foreach($siswa as $s): $b=$bi[(int)$s['id_siswa']]??[]; $d=$s; foreach($b as $bk=>$bv){ if($bv!==null && trim((string)$bv)!=='') $d[$bk]=$bv; } $foto=''; foreach(['jpg','jpeg','png','webp'] as $e){$f="../../assets/images/siswa/".(int)$s['id_siswa'].".$e"; if(is_file(__DIR__.'/../../assets/images/siswa/'.(int)$s['id_siswa'].".$e")){ $foto=$f; break; }} ?>
<!-- HALAMAN 1 -->
<div class="bi-sheet">
<?php
$full=$s['nama_siswa']??''; $panggilan=trim(explode(' ',preg_replace('/\s+/',' ',$full))[0]??'');
$fields1=[
 ['x'=>243.27,'y'=>56.03,'w'=>58,'t'=>v($s,['nis'])],['x'=>373.04,'y'=>56.03,'w'=>60,'t'=>v($s,['nisn'])],
 ['x'=>232.88,'y'=>125.62,'w'=>61,'t'=>$full],['x'=>232.88,'y'=>142.42,'w'=>61,'t'=>$panggilan],
 ['x'=>232.88,'y'=>159.25,'w'=>61,'t'=>($s['jenis_kelamin']??'')==='P'?'Perempuan':'Laki-laki'],
 ['x'=>232.88,'y'=>192.85,'w'=>61,'t'=>tanggal_id($s['tanggal_lahir']??'')],['x'=>232.88,'y'=>209.85,'w'=>61,'t'=>v($s,['tempat_lahir'])],
 ['x'=>232.88,'y'=>226.65,'w'=>61,'t'=>v($s,['agama'])],['x'=>232.88,'y'=>243.45,'w'=>61,'t'=>v($s,['kewarganegaraan'])],
 ['x'=>232.88,'y'=>277.27,'w'=>61,'t'=>v($s,['jumlah_saudara_kandung'])],
 ['x'=>289.50,'y'=>361.50,'w'=>61,'t'=>v($d,['berat_badan','berat'])],['x'=>289.50,'y'=>378.30,'w'=>61,'t'=>v($d,['tinggi_badan','tinggi'])],['x'=>232.88,'y'=>395.10,'w'=>61,'t'=>v($d,['golongan_darah','goldar'])],['x'=>289.50,'y'=>411.90,'w'=>61,'t'=>v($d,['penyakit_pernah_diderita','penyakit'])],
 ['x'=>289.50,'y'=>428.90,'w'=>61,'t'=>v($s,['alamat'])],['x'=>289.50,'y'=>445.70,'w'=>61,'t'=>v($d,['bertempat_tinggal_pada','tempat_tinggal'])],['x'=>289.50,'y'=>462.52,'w'=>70,'t'=>v($d,['jarak_rumah_ke_sekolah','jarak_rumah'])],
 ['x'=>232.88,'y'=>532.12,'w'=>61,'t'=>v($s,['nama_ayah'])],['x'=>232.88,'y'=>548.92,'w'=>61,'t'=>v($s,['nama_ibu'])],
 ['x'=>232.88,'y'=>582.55,'w'=>61,'t'=>v($d,['pendidikan_ayah'])],['x'=>232.88,'y'=>599.35,'w'=>61,'t'=>v($d,['pendidikan_ibu'])],
 ['x'=>232.88,'y'=>633.15,'w'=>61,'t'=>v($d,['pekerjaan_ayah'])],['x'=>232.88,'y'=>649.95,'w'=>61,'t'=>v($d,['pekerjaan_ibu'])],
 ['x'=>261.08,'y'=>683.78,'w'=>61,'t'=>v($d,['hubungan_wali','hubungan_keluarga'])],['x'=>261.08,'y'=>700.58,'w'=>61,'t'=>v($d,['pendidikan_wali'])],['x'=>261.08,'y'=>717.38,'w'=>61,'t'=>v($d,['pekerjaan_wali','jabatan_wali'])]
];
foreach($fields1 as $f) if(trim((string)$f['t'])!=='') echo '<span class="ov" style="left:'.$f['x'].'pt;top:'.$f['y'].'pt;width:'.$f['w'].'pt;">'.h($f['t']).'</span>';
if($foto) echo '<img class="photo" src="'.h($foto).'" style="left:428.4pt;top:107.11pt;width:113.35pt;height:170.05pt" onerror="this.style.display=\'none\'">';
?>
</div>
<!-- HALAMAN 2 -->
<div class="bi-sheet p2">
<?php
$fields2=[
 ['x'=>317.90,'y'=>83.42,'w'=>61,'t'=>v($d,['asal_siswa','asal_sekolah'])],['x'=>317.90,'y'=>100.22,'w'=>61,'t'=>v($d,['nama_paud'])],['x'=>317.90,'y'=>117.03,'w'=>61,'t'=>v($d,['alamat_asal','alamat'])],['x'=>317.90,'y'=>134.03,'w'=>61,'t'=>v($d,['tanggal_nomor_ijazah','nomor_ijazah'])],
 ['x'=>289.50,'y'=>167.65,'w'=>61,'t'=>v($d,['nama_sekolah_asal','asal_sekolah'])],['x'=>289.50,'y'=>184.45,'w'=>61,'t'=>v($d,['dari_tingkat'])],['x'=>289.50,'y'=>201.45,'w'=>61,'t'=>v($d,['diterima_tanggal'])],['x'=>289.50,'y'=>218.25,'w'=>68,'t'=>v($d,['di_tingkat'])],
 ['x'=>232.88,'y'=>415.10,'w'=>61,'t'=>v($d,['jenis_bea_siswa','beasiswa'])],['x'=>232.88,'y'=>484.53,'w'=>40,'t'=>v($d,['tahun_tamat'])],['x'=>232.88,'y'=>501.33,'w'=>55,'t'=>v($d,['nomor_ijazah','no_ijazah'])],['x'=>250.00,'y'=>518.33,'w'=>100,'t'=>v($d,['melanjutkan_ke_sekolah'])],
 ['x'=>232.88,'y'=>551.92,'w'=>55,'t'=>v($d,['pindah_dari_tingkat'])],['x'=>232.88,'y'=>568.72,'w'=>100,'t'=>v($d,['pindah_ke_sekolah'])],['x'=>232.88,'y'=>585.52,'w'=>55,'t'=>v($d,['pindah_ke_tingkat'])],['x'=>232.88,'y'=>602.32,'w'=>70,'t'=>v($d,['tanggal_pindah'])],
 ['x'=>232.88,'y'=>635.92,'w'=>70,'t'=>v($d,['tanggal_keluar'])],['x'=>232.88,'y'=>652.72,'w'=>100,'t'=>v($d,['alasan_keluar'])],['x'=>232.88,'y'=>718.00,'w'=>100,'t'=>v($d,['catatan_wali_kelas','catatan_wali','catatan'])]
];
foreach($fields2 as $f) if(trim((string)$f['t'])!=='') echo '<span class="ov" style="left:'.$f['x'].'pt;top:'.$f['y'].'pt;width:'.$f['w'].'pt;">'.h($f['t']).'</span>';
/* tabel keadaan jasmani 6 tahun */
$xcenters=[280.70,328.94,377.37,425.56,473.79,521.99];
for($i=0;$i<6;$i++){
 $x=$xcenters[$i]; $tahun=v($d,['tahun_'.$i,'tahun'.($i+1)]);
 $bb=v($d,['berat_badan_'.$i,'berat_'.$i]); $tb=v($d,['tinggi_badan_'.$i,'tinggi_'.$i]); $lk=v($d,['lingkar_kepala_'.$i,'lingkar_'.$i]);
 foreach([['y'=>286.17,'t'=>$tahun],['y'=>301.98,'t'=>$bb],['y'=>317.58,'t'=>$tb],['y'=>333.37,'t'=>$lk]] as $z) if($z['t']!=='') echo '<span class="ov center" style="left:'.($x-22).'pt;top:'.$z['y'].'pt;width:44pt">'.h($z['t']).'</span>';
}
if($foto) echo '<img class="photo" src="'.h($foto).'" style="left:428.1pt;top:516.67pt;width:113.35pt;height:170.05pt" onerror="this.style.display=\'none\'">';
?>
</div>
<!-- HALAMAN 3 -->
<div class="bi-sheet p3">
<?php
/* Kolom nilai: 12 kolom, masing-masing 6 kelas x 2 semester. Koordinat mengikuti tabel pada PDF. */
$subject_rows=['ppkn','agama','bahasaindonesia','matematika','ipa','ips','senibudaya','penjaskes','bahasainggris','daerah'];
$all=$nilai[(int)$s['id_siswa']]??[]; $map=[]; $years=[];
foreach($all as $nrow){
 $lvl=(int)($nrow['tingkat']??0); $sem=strtolower((string)($nrow['semester']??'')); $semno=str_contains($sem,'genap')?'2':'1'; $mk=norm_mapel($nrow['nama_mapel']??'');
 if($lvl>=1 && $lvl<=6 && $mk){ $map[$lvl][$semno][$mk]=$nrow['nilai_akhir']??''; if(!empty($nrow['tahun_ajaran'])) $years[$lvl]=$nrow['tahun_ajaran']; }
}
$xb=[416,485,555,632,710,779,849,918,987,1057,1126,1195,1266];
$xcent=[]; for($i=0;$i<12;$i++) $xcent[]=(($xb[$i]+$xb[$i+1])/2);
foreach($subject_rows as $ri=>$sub){ $y=170+$ri*20; foreach(range(1,6) as $lvl){ foreach([1,2] as $sem){ $col=($lvl-1)*2+($sem-1); $val=$map[$lvl][$sem][$sub]??''; if($val!=='') echo '<span class="ov center" style="left:'.($xcent[$col]-20).'pt;top:'.($y-5).'pt;width:40pt">'.h($val).'</span>'; } } }
foreach(range(1,6) as $lvl){ if(!empty($years[$lvl])){ $col=$lvl-1; $x=$xcent[$col*2]+($xcent[$col*2+1]-$xcent[$col*2])/2; echo '<span class="ov center" style="left:'.($x-48).'pt;top:103pt;width:96pt">'.h($years[$lvl]).'</span>'; } }
for($lvl=1;$lvl<=6;$lvl++){ $vals=[]; foreach([1,2] as $sem) foreach($subject_rows as $sub) if(isset($map[$lvl][$sem][$sub]) && is_numeric($map[$lvl][$sem][$sub])) $vals[]=(float)$map[$lvl][$sem][$sub]; if($vals){$sum=array_sum($vals);$avg=$sum/count($vals);$col=$lvl-1;$x=$xcent[$col*2]+($xcent[$col*2+1]-$xcent[$col*2])/2; echo '<span class="ov center" style="left:'.($x-48).'pt;top:410pt;width:96pt">'.h(round($sum,2)).'</span>'; echo '<span class="ov center" style="left:'.($x-48).'pt;top:430pt;width:96pt">'.h(number_format($avg,2,',','.')).'</span>'; } }
?>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>
</div></main>
</body></html>
