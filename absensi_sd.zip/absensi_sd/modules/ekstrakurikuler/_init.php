<?php
require_once __DIR__ . '/../../config/auth.php';
wajib_login();
wajib_role('Admin','Operator','Guru');
require_once __DIR__ . '/../../config/database.php';

function esk_h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function esk_clean($v){ $v=trim((string)$v); return $v===''?null:$v; }
function esk_redirect($url){ header('Location: '.$url); exit; }

$eskul_id = (int)($_GET['id_ekskul'] ?? $_POST['id_ekskul'] ?? 0);
$ta = null;
$qta = mysqli_query($koneksi,"SELECT * FROM tahun_ajaran WHERE aktif=1 ORDER BY id_tahun_ajaran DESC LIMIT 1");
if($qta) $ta=mysqli_fetch_assoc($qta);
$ta_id=(int)($ta['id_tahun_ajaran']??0);

$eskul=[];
$q=mysqli_query($koneksi,"SELECT e.*, g.nama AS nama_pembina FROM ekstrakurikuler e LEFT JOIN guru g ON g.id_guru=e.id_guru_pembina WHERE e.status='Aktif' ORDER BY e.nama_ekskul");
if($q) while($r=mysqli_fetch_assoc($q)) $eskul[]=$r;
if(!$eskul_id && !empty($eskul)) $eskul_id=(int)$eskul[0]['id_ekskul'];

function esk_layout_start($title){
    global $eskul_id,$eskul;
    $page_title=$title.' - Absensi SDN Ciburayut 01';
    require __DIR__.'/../../includes/header.php';
    require __DIR__.'/../../includes/sidebar.php';
}
function esk_layout_end(){ echo '</main></body></html>'; }
function esk_selector(){
    global $eskul,$eskul_id;
    echo '<form method="get" class="eskul-filter"><label>Ekstrakurikuler</label><select name="id_ekskul" onchange="this.form.submit()">';
    if(!$eskul) echo '<option value="">Belum ada ekstrakurikuler</option>';
    foreach($eskul as $e) echo '<option value="'.(int)$e['id_ekskul'].'" '.((int)$e['id_ekskul']===$eskul_id?'selected':'').'>'.esk_h($e['nama_ekskul']).' — '.esk_h($e['nama_pembina']??'').'</option>';
    echo '</select></form>';
}
?>
