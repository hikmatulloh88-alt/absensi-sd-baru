<?php $menu_aktif=$menu_aktif??'dashboard'; ?><aside class="sidebar">
<div class="sidebar-header"><div class="logo">AS</div><div><h2>Absensi SD</h2><p>SDN CIBURAYUT 01</p></div></div>
<nav class="sidebar-menu">
<a href="/absensi_sd/index.php" class="menu-item <?=$menu_aktif==='dashboard'?'active':''?>">🏠 Dashboard</a>
<div class="menu-title">MASTER DATA</div>
<a href="/absensi_sd/modules/siswa/index.php" class="menu-item">👨‍🎓 Data Siswa</a>
<a href="/absensi_sd/modules/guru/index.php" class="menu-item">👥 Data Guru & Karyawan</a>
<a href="/absensi_sd/modules/kelas/index.php" class="menu-item">🏫 Data Kelas</a>
<a href="/absensi_sd/modules/buku_induk/index.php" class="menu-item">📖 Buku Induk</a>
<a href="/absensi_sd/modules/mata_pelajaran/index.php" class="menu-item">📚 Mata Pelajaran</a>
<div class="menu-title">ABSENSI</div>
<a href="/absensi_sd/modules/absensi/index.php" class="menu-item">📝 Absensi Siswa</a>
<a href="/absensi_sd/modules/absensi/scan_qr.php" class="menu-item" style="padding-left:34px;font-size:13px;">📷 Scan QR Kehadiran</a>
<a href="/absensi_sd/modules/absensi/riwayat.php" class="menu-item" style="padding-left:34px;font-size:13px;">📋 Riwayat Absensi</a>
<a href="/absensi_sd/modules/guru/absensi.php" class="menu-item">👤 Absensi Guru & Karyawan</a>
<a href="/absensi_sd/modules/rekap/index.php" class="menu-item <?=$menu_aktif==='rekap'?'active':''?>">📋 Rekap Absensi</a>
<a href="#" class="menu-item">🖨️ Cetak Kartu Absensi</a>
<div class="menu-title">NILAI</div>
<a href="/absensi_sd/modules/nilai/index.php" class="menu-item">📊 Nilai Siswa</a>
<a href="#" class="menu-item">• Nilai Gasal</a><a href="#" class="menu-item">• Nilai Genap</a>
<div class="menu-title">LAPORAN</div>
<a href="#" class="menu-item">📄 Laporan</a><a href="#" class="menu-item">🖨️ Cetak Buku Induk (Masal)</a>
<div class="menu-title">PENGATURAN</div>
<a href="#" class="menu-item">⚙️ Pengaturan</a><a href="#" class="menu-item">👥 Pengguna</a><a href="#" class="menu-item logout">🚪 Keluar</a>
</nav></aside>