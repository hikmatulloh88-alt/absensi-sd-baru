<?php
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator', 'Guru');
require_once "../../config/database.php";

$menu_aktif = 'rekap';
$page_title = 'Rekap Absensi - SDN Ciburayut 01';

function h($v){
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

/* Struktur tabel */
$cols_siswa = [];
$q = mysqli_query($koneksi, "SHOW COLUMNS FROM absensi_siswa");
if ($q) while($r=mysqli_fetch_assoc($q)) $cols_siswa[]=$r['Field'];

$cols_guru = [];
$q = mysqli_query($koneksi, "SHOW COLUMNS FROM absensi_guru");
if ($q) while($r=mysqli_fetch_assoc($q)) $cols_guru[]=$r['Field'];

$hasS = function($f) use (&$cols_siswa){return in_array($f,$cols_siswa,true);};
$hasG = function($f) use (&$cols_guru){return in_array($f,$cols_guru,true);};

$tanggal_awal = $_GET['tanggal_awal'] ?? date('Y-m-01');
$tanggal_akhir = $_GET['tanggal_akhir'] ?? date('Y-m-d');
$id_kelas = (int)($_GET['id_kelas'] ?? 0);
$id_tahun = (int)($_GET['id_tahun_ajaran'] ?? 0);
$cetak = ($_GET['cetak'] ?? '') === '1';

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/',$tanggal_awal)) $tanggal_awal=date('Y-m-01');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/',$tanggal_akhir)) $tanggal_akhir=date('Y-m-d');
// Rentang terbalik menghasilkan laporan kosong yang membingungkan. Tukar
// otomatis agar laporan dan PDF tetap memuat periode yang dimaksud pengguna.
if ($tanggal_awal > $tanggal_akhir) {
    [$tanggal_awal, $tanggal_akhir] = [$tanggal_akhir, $tanggal_awal];
}

/* Tahun ajaran */
$tahun=[];
$q=mysqli_query($koneksi,"SELECT id_tahun_ajaran,tahun_ajaran,semester,aktif FROM tahun_ajaran ORDER BY aktif DESC,id_tahun_ajaran DESC");
if($q) while($r=mysqli_fetch_assoc($q)) $tahun[]=$r;
if(!$id_tahun && $tahun) $id_tahun=(int)$tahun[0]['id_tahun_ajaran'];

/* Kelas */
$kelas=[];
$q=mysqli_query($koneksi,"SELECT id_kelas,nama_kelas,tingkat FROM kelas ORDER BY tingkat,nama_kelas");
if($q) while($r=mysqli_fetch_assoc($q)) $kelas[]=$r;

/* Rekap siswa: tampilkan seluruh siswa aktif lalu hitung status dalam rentang tanggal */
$rekap_siswa=[];
$totS=['Hadir'=>0,'Sakit'=>0,'Izin'=>0,'Alpa'=>0];

if($hasS('id_siswa') && $hasS('tanggal') && $hasS('status')){
    $where="s.status_siswa='Aktif'";
    if($id_kelas>0) $where.=" AND s.id_kelas=".$id_kelas;

    $sql="SELECT s.id_siswa,s.nis,s.nisn,s.nama_siswa,k.nama_kelas
          FROM siswa s
          LEFT JOIN kelas k ON k.id_kelas=s.id_kelas
          WHERE $where
          ORDER BY k.tingkat,k.nama_kelas,s.nama_siswa";

    $qS=mysqli_query($koneksi,$sql);

    if($qS){
        while($s=mysqli_fetch_assoc($qS)){
            $rekap_siswa[(int)$s['id_siswa']]=[
                'nis'=>$s['nis'],
                'nisn'=>$s['nisn'],
                'nama_siswa'=>$s['nama_siswa'],
                'nama_kelas'=>$s['nama_kelas'],
                'Hadir'=>0,'Sakit'=>0,'Izin'=>0,'Alpa'=>0
            ];
        }
    }

    if($rekap_siswa){
        $sqlA="SELECT id_siswa,status,COUNT(*) jumlah
               FROM absensi_siswa
               WHERE tanggal BETWEEN ? AND ?";
        $va=[$tanggal_awal,$tanggal_akhir];
        $ta="ss";

        if($hasS('id_tahun_ajaran') && $id_tahun>0){
            $sqlA.=" AND id_tahun_ajaran=?";
            $va[]=$id_tahun; $ta.="i";
        }

        if($id_kelas>0 && $hasS('id_kelas')){
            $sqlA.=" AND id_kelas=?";
            $va[]=$id_kelas; $ta.="i";
        }

        $sqlA.=" GROUP BY id_siswa,status";

        $st=mysqli_prepare($koneksi,$sqlA);
        if($st){
            mysqli_stmt_bind_param($st,$ta,...$va);
            mysqli_stmt_execute($st);
            $rr=mysqli_stmt_get_result($st);

            if($rr){
                while($r=mysqli_fetch_assoc($rr)){
                    $sid=(int)$r['id_siswa'];
                    $status=strtolower(trim($r['status']));
                    $n=(int)$r['jumlah'];

                    if(isset($rekap_siswa[$sid])){
                        if($status==='hadir') $rekap_siswa[$sid]['Hadir']=$n;
                        elseif($status==='sakit') $rekap_siswa[$sid]['Sakit']=$n;
                        elseif($status==='izin') $rekap_siswa[$sid]['Izin']=$n;
                        elseif($status==='alpa'||$status==='alpha') $rekap_siswa[$sid]['Alpa']=$n;
                    }
                }
            }
        }
    }

    foreach($rekap_siswa as $r){
        $totS['Hadir'] += $r['Hadir'];
        $totS['Sakit'] += $r['Sakit'];
        $totS['Izin'] += $r['Izin'];
        $totS['Alpa'] += $r['Alpa'];
    }
}

/* Rekap guru */
$rekap_guru=[];
$totG=['Hadir'=>0,'Sakit'=>0,'Izin'=>0,'Alpa'=>0];

if($hasG('id_guru') && $hasG('tanggal') && $hasG('status')){
    $qG=mysqli_query($koneksi,"SELECT id_guru,nama,nama_guru,nip,nuptk,jabatan,jenis_ptk
                              FROM guru
                              WHERE status='Aktif'
                              ORDER BY nama ASC");
    if($qG){
        while($g=mysqli_fetch_assoc($qG)){
            $rekap_guru[(int)$g['id_guru']]=[
                'nama'=>$g['nama']?:($g['nama_guru']??'-'),
                'nip'=>$g['nip']??'-',
                'jabatan'=>$g['jabatan']??'-',
                'jenis_ptk'=>$g['jenis_ptk']??'-',
                'Hadir'=>0,'Sakit'=>0,'Izin'=>0,'Alpa'=>0
            ];
        }
    }

    if($rekap_guru){
        $sqlA="SELECT id_guru,status,COUNT(*) jumlah
                FROM absensi_guru
                WHERE tanggal BETWEEN ? AND ?";
        $va=[$tanggal_awal,$tanggal_akhir];
        $ta="ss";

        if($hasG('id_tahun_ajaran') && $id_tahun>0){
            $sqlA.=" AND id_tahun_ajaran=?";
            $va[]=$id_tahun; $ta.="i";
        }
        $sqlA.=" GROUP BY id_guru,status";

        $st=mysqli_prepare($koneksi,$sqlA);
        if($st){
            mysqli_stmt_bind_param($st,$ta,...$va);
            mysqli_stmt_execute($st);
            $rr=mysqli_stmt_get_result($st);
            if($rr){
                while($r=mysqli_fetch_assoc($rr)){
                    $idg=(int)$r['id_guru'];
                    $status=strtolower(trim($r['status']));
                    $n=(int)$r['jumlah'];

                    if(isset($rekap_guru[$idg])){
                        if($status==='hadir')$rekap_guru[$idg]['Hadir']=$n;
                        elseif($status==='sakit')$rekap_guru[$idg]['Sakit']=$n;
                        elseif($status==='izin')$rekap_guru[$idg]['Izin']=$n;
                        elseif($status==='alpa'||$status==='alpha')$rekap_guru[$idg]['Alpa']=$n;
                    }
                }
            }
        }
    }

    foreach($rekap_guru as $r){
        $totG['Hadir'] += $r['Hadir'];
        $totG['Sakit'] += $r['Sakit'];
        $totG['Izin'] += $r['Izin'];
        $totG['Alpa'] += $r['Alpa'];
    }
}

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>
<style>
.rp{max-width:1500px}.ph{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}.ph h1{margin:0 0 6px}.ph p{margin:0}
.card{background:#fff;border-radius:18px;box-shadow:0 8px 25px rgba(15,35,70,.07);padding:20px;margin-bottom:20px}
.filters{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
label{display:block;font-size:13px;font-weight:600;color:#334155;margin-bottom:7px}.fc{width:100%;height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:0 11px;background:#fff}
.btn{display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:10px;padding:11px 16px;font-weight:600;text-decoration:none;cursor:pointer}.pri{background:linear-gradient(135deg,#2388f5,#1265dc);color:#fff}.sec{background:#eef3f9;color:#334155}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px}.stat{padding:16px;border-radius:13px;background:#f7f9fc}.stat strong{display:block;font-size:24px;color:#17233c}.stat span{font-size:12px;color:#64748b}
.tabs{display:flex;gap:8px;margin-bottom:15px}.tab{padding:9px 14px;border-radius:9px;background:#eef3f9;color:#475569;text-decoration:none;font-size:13px;font-weight:600}.tab.active{background:#2388f5;color:#fff}
.tw{overflow-x:auto}.dt{width:100%;border-collapse:collapse;min-width:950px}.dt th{background:#f7f9fc;color:#64748b;font-size:12px;text-transform:uppercase;padding:12px;text-align:left}.dt td{padding:11px 12px;border-bottom:1px solid #edf1f6}.nm{font-weight:700;color:#17233c}.sub{font-size:12px;color:#94a3b8;margin-top:3px}
.num{text-align:center;font-weight:700}.total{background:#fbfdff;font-weight:800}
@media(max-width:1000px){.filters{grid-template-columns:1fr 1fr}.stats{grid-template-columns:1fr 1fr}}@media(max-width:600px){.filters,.stats{grid-template-columns:1fr}.ph{align-items:flex-start;flex-direction:column;gap:10px}}
@media print{
 @page{size:A4 landscape;margin:10mm}
 body{background:#fff!important}
 .sidebar,.no-print,.ph,.filter-card{display:none!important}
 .main-content{margin:0!important;padding:0!important}
 .rp{max-width:none!important}
 .card{box-shadow:none!important;border-radius:0!important;padding:0!important;margin:0 0 7mm!important}
 .print-title{display:block!important}
 .stats{break-inside:avoid}
 .dt{min-width:0!important;font-size:9px}
 .dt th,.dt td{padding:5px 6px!important}
}
</style>

<main class="main-content"><div class="rp">

<div class="ph"><div><h1>Rekap Absensi</h1><p>Rekapitulasi kehadiran siswa serta guru & karyawan berdasarkan periode.</p></div>
<a class="btn pri no-print" href="?tanggal_awal=<?=urlencode($tanggal_awal)?>&amp;tanggal_akhir=<?=urlencode($tanggal_akhir)?>&amp;id_kelas=<?=$id_kelas?>&amp;id_tahun_ajaran=<?=$id_tahun?>&amp;cetak=1">🖨️ Cetak / Simpan PDF</a></div>

<div class="card filter-card no-print">
<form method="get">
<div class="filters">
<div><label>Tanggal Awal</label><input class="fc" type="date" name="tanggal_awal" value="<?=h($tanggal_awal)?>"></div>
<div><label>Tanggal Akhir</label><input class="fc" type="date" name="tanggal_akhir" value="<?=h($tanggal_akhir)?>"></div>
<div><label>Kelas</label><select class="fc" name="id_kelas"><option value="0">Semua Kelas</option><?php foreach($kelas as $k):?><option value="<?=$k['id_kelas']?>" <?=$id_kelas===(int)$k['id_kelas']?'selected':''?>>Kelas <?=h($k['nama_kelas'])?></option><?php endforeach;?></select></div>
<?php if($tahun):?><div><label>Tahun Ajaran / Semester</label><select class="fc" name="id_tahun_ajaran"><?php foreach($tahun as $t):?><option value="<?=$t['id_tahun_ajaran']?>" <?=$id_tahun===(int)$t['id_tahun_ajaran']?'selected':''?>><?=h($t['tahun_ajaran'])?> - <?=h($t['semester'])?></option><?php endforeach;?></select></div><?php endif;?>
</div>
<div style="margin-top:15px;display:flex;gap:8px"><button class="btn pri">🔎 Tampilkan Rekap</button><a class="btn sec" href="index.php">Reset</a></div>
</form>
</div>

<div class="stats">
<div class="stat"><strong><?=$totS['Hadir']?></strong><span>Total Hadir Siswa</span></div>
<div class="stat"><strong><?=$totS['Sakit']?></strong><span>Total Sakit Siswa</span></div>
<div class="stat"><strong><?=$totS['Izin']?></strong><span>Total Izin Siswa</span></div>
<div class="stat"><strong><?=$totS['Alpa']?></strong><span>Total Alpa Siswa</span></div>
</div>

<div class="card print-title" style="display:none">
<div style="text-align:center;border-bottom:2px solid #17233c;padding-bottom:10px;margin-bottom:14px">
<strong style="font-size:18px">LAPORAN REKAP KEHADIRAN SISWA, GURU &amp; KARYAWAN</strong><br>
<span>SDN CIBURAYUT 01</span><br>
<span>Periode <?=h(date('d-m-Y', strtotime($tanggal_awal)))?> s.d. <?=h(date('d-m-Y', strtotime($tanggal_akhir)))?></span>
</div>
</div>

<div class="tabs"><span class="tab active">👨‍🎓 Rekap Siswa</span><span class="tab">👥 Rekap Guru & Karyawan</span></div>

<div class="card">
<div class="tw">
<table class="dt">
<thead><tr><th>No</th><th>NIS/NISN</th><th>Nama Siswa</th><th>Kelas</th><th>Hadir</th><th>Sakit</th><th>Izin</th><th>Alpa</th><th>Total</th></tr></thead>
<tbody>
<?php if($rekap_siswa):$no=1;foreach($rekap_siswa as $r):$total=$r['Hadir']+$r['Sakit']+$r['Izin']+$r['Alpa'];?>
<tr>
<td><?=$no++?></td><td><?=h($r['nis']?:'-')?><div class="sub">NISN: <?=h($r['nisn']?:'-')?></div></td>
<td><div class="nm"><?=h($r['nama_siswa'])?></div></td><td><?=h($r['nama_kelas']?:'-')?></td>
<td class="num"><?=$r['Hadir']?></td><td class="num"><?=$r['Sakit']?></td><td class="num"><?=$r['Izin']?></td><td class="num"><?=$r['Alpa']?></td><td class="num total"><?=$total?></td>
</tr>
<?php endforeach;else:?><tr><td colspan="9" style="text-align:center;padding:40px;color:#94a3b8">Belum ada data siswa.</td></tr><?php endif;?>
</tbody>
</table>
</div>
</div>

<div class="card">
<h2 style="margin-top:0">👥 Rekap Guru & Karyawan</h2>
<div class="tw"><table class="dt">
<thead><tr><th>No</th><th>NIP</th><th>Nama</th><th>Jabatan</th><th>Jenis PTK</th><th>Hadir</th><th>Sakit</th><th>Izin</th><th>Alpa</th><th>Total</th></tr></thead>
<tbody>
<?php if($rekap_guru):$no=1;foreach($rekap_guru as $r):$total=$r['Hadir']+$r['Sakit']+$r['Izin']+$r['Alpa'];?>
<tr><td><?=$no++?></td><td><?=h($r['nip'])?></td><td><div class="nm"><?=h($r['nama'])?></div></td><td><?=h($r['jabatan'])?></td><td><?=h($r['jenis_ptk'])?></td><td class="num"><?=$r['Hadir']?></td><td class="num"><?=$r['Sakit']?></td><td class="num"><?=$r['Izin']?></td><td class="num"><?=$r['Alpa']?></td><td class="num total"><?=$total?></td></tr>
<?php endforeach;else:?><tr><td colspan="10" style="text-align:center;padding:40px;color:#94a3b8">Belum ada data guru/karyawan.</td></tr><?php endif;?>
</tbody>
</table></div>
</div>

<?php if($cetak): ?>
<script>
// Dibuka dari tombol Cetak / Simpan PDF atau menu Laporan & Cetak.
// Dialog cetak browser menyediakan pilihan "Save as PDF" tanpa library tambahan.
window.addEventListener('load', function(){ window.print(); });
</script>
<?php endif; ?>
</div></main>
</body></html>
