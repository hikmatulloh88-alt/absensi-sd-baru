<?php
/* STEP 31: Proteksi akses Data Kelas sesuai role */
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator', 'Guru');

require_once "../../config/database.php";

$menu_aktif = 'kelas';
$page_title = 'Data Kelas - Absensi SDN Ciburayut 01';

$pesan = '';
$tipe_pesan = '';
$mode_edit = false;

$data_edit = [
    'id_kelas' => '',
    'nama_kelas' => '',
    'tingkat' => '',
    'id_wali_kelas' => '',
    'id_tahun_ajaran' => '',
    'ruang' => ''
];

function h($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

/* SIMPAN / UPDATE */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? '';

    if ($aksi === 'simpan') {
        $id_kelas = (int)($_POST['id_kelas'] ?? 0);
        $nama_kelas = trim($_POST['nama_kelas'] ?? '');
        $tingkat = (int)($_POST['tingkat'] ?? 0);
        $id_wali_kelas = (int)($_POST['id_wali_kelas'] ?? 0);
        $id_tahun_ajaran = (int)($_POST['id_tahun_ajaran'] ?? 0);

        if ($nama_kelas === '' || $tingkat < 1 || $tingkat > 6) {
            $pesan = 'Nama kelas dan tingkat 1-6 wajib diisi.';
            $tipe_pesan = 'error';
        } else {
            try {
                if ($id_kelas > 0) {
                    $sql = "UPDATE kelas
                            SET nama_kelas = ?, tingkat = ?,
                                id_wali_kelas = NULLIF(?,0),
                                id_tahun_ajaran = NULLIF(?,0)
                            WHERE id_kelas = ?";
                    $stmt = mysqli_prepare($koneksi, $sql);
                    mysqli_stmt_bind_param(
                        $stmt,
                        "siiii",
                        $nama_kelas,
                        $tingkat,
                        $id_wali_kelas,
                        $id_tahun_ajaran,
                        $id_kelas
                    );
                } else {
                    $sql = "INSERT INTO kelas
                            (nama_kelas, tingkat, id_wali_kelas, id_tahun_ajaran)
                            VALUES (?, ?, NULLIF(?,0), NULLIF(?,0))";
                    $stmt = mysqli_prepare($koneksi, $sql);
                    mysqli_stmt_bind_param(
                        $stmt,
                        "siii",
                        $nama_kelas,
                        $tingkat,
                        $id_wali_kelas,
                        $id_tahun_ajaran
                    );
                }

                if ($stmt && mysqli_stmt_execute($stmt)) {
                    header("Location: index.php?sukses=1");
                    exit;
                }

                $pesan = 'Data kelas gagal disimpan.';
                $tipe_pesan = 'error';
            } catch (Throwable $e) {
                $pesan = 'Data kelas gagal disimpan. Pastikan data belum duplikat.';
                $tipe_pesan = 'error';
            }
        }
    }

    if ($aksi === 'hapus') {
        $id_hapus = (int)($_POST['id_kelas'] ?? 0);

        if ($id_hapus > 0) {
            try {
                $stmt = mysqli_prepare($koneksi, "DELETE FROM kelas WHERE id_kelas = ?");
                mysqli_stmt_bind_param($stmt, "i", $id_hapus);

                if (mysqli_stmt_execute($stmt)) {
                    header("Location: index.php?hapus=1");
                    exit;
                }

                $pesan = 'Data kelas tidak dapat dihapus. Mungkin sudah dipakai siswa/absensi.';
                $tipe_pesan = 'error';
            } catch (Throwable $e) {
                $pesan = 'Data kelas tidak dapat dihapus karena masih digunakan oleh data lain.';
                $tipe_pesan = 'error';
            }
        }
    }
}

if (isset($_GET['sukses'])) {
    $pesan = 'Data kelas berhasil disimpan.';
    $tipe_pesan = 'success';
}

if (isset($_GET['hapus'])) {
    $pesan = 'Data kelas berhasil dihapus.';
    $tipe_pesan = 'success';
}

/* EDIT */
if (isset($_GET['edit'])) {
    $id_edit = (int)$_GET['edit'];

    if ($id_edit > 0) {
        $stmt = mysqli_prepare($koneksi, "SELECT * FROM kelas WHERE id_kelas = ?");
        mysqli_stmt_bind_param($stmt, "i", $id_edit);
        mysqli_stmt_execute($stmt);
        $hasil = mysqli_stmt_get_result($stmt);

        if ($hasil && mysqli_num_rows($hasil) === 1) {
            $data_edit = mysqli_fetch_assoc($hasil);
            $mode_edit = true;
        }
    }
}

/* GURU */
$daftar_guru = [];
$q_guru = mysqli_query(
    $koneksi,
    "SELECT id_guru, nama
     FROM guru
     WHERE status = 'Aktif'
     ORDER BY nama ASC"
);
if ($q_guru) {
    while ($row = mysqli_fetch_assoc($q_guru)) {
        $daftar_guru[] = $row;
    }
}

/* TAHUN AJARAN */
$daftar_tahun = [];
$q_tahun = mysqli_query(
    $koneksi,
    "SELECT id_tahun_ajaran, tahun_ajaran, semester, aktif
     FROM tahun_ajaran
     ORDER BY aktif DESC, id_tahun_ajaran DESC"
);
if ($q_tahun) {
    while ($row = mysqli_fetch_assoc($q_tahun)) {
        $daftar_tahun[] = $row;
    }
}

/* DATA KELAS */
$q_kelas = mysqli_query(
    $koneksi,
    "SELECT id_kelas, nama_kelas, tingkat, id_wali_kelas, id_tahun_ajaran
     FROM kelas
     ORDER BY tingkat ASC, nama_kelas ASC"
);

$jumlah_kelas = 0;
if ($q_kelas) {
    $jumlah_kelas = mysqli_num_rows($q_kelas);
}

/* Fungsi informasi tambahan */
function ambil_nama_guru($koneksi, $id_guru) {
    $id_guru = (int)$id_guru;
    if ($id_guru <= 0) return 'Belum ditentukan';

    $stmt = mysqli_prepare($koneksi, "SELECT nama FROM guru WHERE id_guru = ?");
    if (!$stmt) return 'Belum ditentukan';

    mysqli_stmt_bind_param($stmt, "i", $id_guru);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = $result ? mysqli_fetch_assoc($result) : null;

    return $row ? $row['nama'] : 'Belum ditentukan';
}

function ambil_tahun_ajaran($koneksi, $id_tahun) {
    $id_tahun = (int)$id_tahun;
    if ($id_tahun <= 0) return '-';

    $stmt = mysqli_prepare(
        $koneksi,
        "SELECT tahun_ajaran, semester FROM tahun_ajaran WHERE id_tahun_ajaran = ?"
    );

    if (!$stmt) return '-';

    mysqli_stmt_bind_param($stmt, "i", $id_tahun);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = $result ? mysqli_fetch_assoc($result) : null;

    if (!$row) return '-';

    return $row['tahun_ajaran'] . ' - ' . $row['semester'];
}

function hitung_siswa_kelas($koneksi, $id_kelas) {
    $id_kelas = (int)$id_kelas;
    $stmt = mysqli_prepare(
        $koneksi,
        "SELECT COUNT(*) AS total FROM siswa WHERE id_kelas = ?"
    );

    if (!$stmt) return 0;

    mysqli_stmt_bind_param($stmt, "i", $id_kelas);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = $result ? mysqli_fetch_assoc($result) : null;

    return $row ? (int)$row['total'] : 0;
}

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>

<style>
.kelas-page {
    max-width: 1400px;
}

.page-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    margin-bottom: 24px;
}

.page-head h1 {
    margin-bottom: 6px;
}

.page-head p {
    margin: 0;
}

.btn-primary,
.btn-secondary,
.btn-danger {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 7px;
    border: 0;
    border-radius: 10px;
    padding: 11px 16px;
    text-decoration: none;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
}

.btn-primary {
    background: linear-gradient(135deg, #2388f5, #1265dc);
    color: #fff;
    box-shadow: 0 8px 18px rgba(18,101,220,.22);
}

.btn-secondary {
    background: #eef3f9;
    color: #334155;
}

.btn-danger {
    background: #fff0f1;
    color: #c92f47;
}

.alert {
    padding: 13px 15px;
    border-radius: 11px;
    margin-bottom: 18px;
    font-size: 14px;
}

.alert-success {
    background: #ecfdf3;
    color: #18794e;
    border: 1px solid #ccefdc;
}

.alert-error {
    background: #fff1f2;
    color: #be123c;
    border: 1px solid #fecdd3;
}

.form-card,
.data-panel {
    background: #fff;
    border-radius: 18px;
    box-shadow: 0 8px 25px rgba(15, 35, 70, .07);
    padding: 24px;
    margin-bottom: 22px;
}

.form-title {
    margin: 0 0 5px;
}

.form-subtitle {
    margin: 0 0 20px;
    color: #64748b;
    font-size: 14px;
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 15px;
}

.form-group {
    display: flex;
    flex-direction: column;
    gap: 7px;
}

.form-label {
    font-size: 13px;
    font-weight: 600;
    color: #334155;
}

.form-control {
    width: 100%;
    min-height: 42px;
    border: 1px solid #dbe4ef;
    border-radius: 10px;
    padding: 9px 11px;
    outline: none;
    background: #fff;
    font: inherit;
}

.form-control:focus {
    border-color: #2388f5;
    box-shadow: 0 0 0 3px rgba(35,136,245,.10);
}

.form-actions {
    display: flex;
    gap: 9px;
    margin-top: 20px;
}

.kelas-summary {
    display: flex;
    gap: 12px;
    align-items: center;
    color: #64748b;
    font-size: 14px;
    margin-bottom: 10px;
}

.table-wrap {
    overflow-x: auto;
}

.data-table {
    width: 100%;
    border-collapse: collapse;
    min-width: 900px;
}

.data-table th {
    text-align: left;
    background: #f7f9fc;
    color: #64748b;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: .5px;
    padding: 13px 12px;
}

.data-table td {
    padding: 14px 12px;
    border-bottom: 1px solid #edf1f6;
    font-size: 14px;
    color: #334155;
}

.data-table tr:hover td {
    background: #fbfdff;
}

.nama-kelas {
    font-weight: 700;
    color: #17233c;
}

.sub-text {
    font-size: 12px;
    color: #94a3b8;
    margin-top: 3px;
}

.badge {
    display: inline-flex;
    padding: 5px 9px;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 700;
    background: #eef4ff;
    color: #1d64d8;
}

.badge-siswa {
    background: #eefbf4;
    color: #16804a;
}

.aksi {
    display: flex;
    gap: 7px;
}

@media (max-width: 900px) {
    .form-grid {
        grid-template-columns: 1fr 1fr;
    }
}

@media (max-width: 650px) {
    .page-head {
        align-items: flex-start;
        flex-direction: column;
    }

    .form-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<main class="main-content">
    <div class="kelas-page">

        <div class="page-head">
            <div>
                <h1>Data Kelas</h1>
                <p>Kelola rombongan belajar dan wali kelas SDN Ciburayut 01.</p>
            </div>

            <a href="index.php?tambah=1" class="btn-primary">
                ➕ Tambah Kelas
            </a>
        </div>

        <?php if ($pesan !== ''): ?>
            <div class="alert <?= $tipe_pesan === 'success' ? 'alert-success' : 'alert-error'; ?>">
                <?= h($pesan); ?>
            </div>
        <?php endif; ?>

        <?php if ($mode_edit || isset($_GET['tambah'])): ?>
            <div class="form-card">
                <h2 class="form-title">
                    <?= $mode_edit ? 'Edit Data Kelas' : 'Tambah Kelas Baru'; ?>
                </h2>

                <p class="form-subtitle">
                    Data kelas akan menjadi referensi untuk siswa dan absensi.
                </p>

                <form method="post">
                    <input type="hidden" name="aksi" value="simpan">
                    <input type="hidden" name="id_kelas" value="<?= (int)$data_edit['id_kelas']; ?>">

                    <div class="form-grid">

                        <div class="form-group">
                            <label class="form-label">Nama Kelas *</label>
                            <input type="text"
                                   name="nama_kelas"
                                   class="form-control"
                                   placeholder="Contoh: 1A"
                                   required
                                   value="<?= h($data_edit['nama_kelas']); ?>">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Tingkat *</label>
                            <select name="tingkat" class="form-control" required>
                                <option value="">Pilih tingkat</option>
                                <?php for ($i = 1; $i <= 6; $i++): ?>
                                    <option value="<?= $i; ?>"
                                        <?= (int)$data_edit['tingkat'] === $i ? 'selected' : ''; ?>>
                                        Kelas <?= $i; ?>
                                    </option>
                                <?php endfor; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Wali Kelas</label>
                            <select name="id_wali_kelas" class="form-control">
                                <option value="0">Belum ditentukan</option>
                                <?php foreach ($daftar_guru as $guru): ?>
                                    <option value="<?= (int)$guru['id_guru']; ?>"
                                        <?= (int)$data_edit['id_wali_kelas'] === (int)$guru['id_guru'] ? 'selected' : ''; ?>>
                                        <?= h($guru['nama']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Tahun Ajaran</label>
                            <select name="id_tahun_ajaran" class="form-control">
                                <option value="0">Belum ditentukan</option>
                                <?php foreach ($daftar_tahun as $tahun): ?>
                                    <option value="<?= (int)$tahun['id_tahun_ajaran']; ?>"
                                        <?= (int)$data_edit['id_tahun_ajaran'] === (int)$tahun['id_tahun_ajaran'] ? 'selected' : ''; ?>>
                                        <?= h($tahun['tahun_ajaran']); ?> - <?= h($tahun['semester']); ?>
                                        <?= (int)$tahun['aktif'] === 1 ? ' (Aktif)' : ''; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn-primary">
                            💾 <?= $mode_edit ? 'Simpan Perubahan' : 'Simpan Kelas'; ?>
                        </button>
                        <a href="index.php" class="btn-secondary">Batal</a>
                    </div>
                </form>
            </div>
        <?php endif; ?>

        <div class="data-panel">
            <div class="kelas-summary">
                🏫 <strong><?= $jumlah_kelas; ?></strong> kelas terdaftar
            </div>

            <?php if (!$q_kelas): ?>
                <div class="alert alert-error" style="margin-top:15px;">
                    Data kelas tersimpan, tetapi tabel gagal dibaca:
                    <?= h(mysqli_error($koneksi)); ?>
                </div>
            <?php endif; ?>

            <div class="table-wrap">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kelas</th>
                            <th>Tingkat</th>
                            <th>Wali Kelas</th>
                            <th>Tahun Ajaran</th>
                            <th>Jumlah Siswa</th>
                            <th width="150">Aksi</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php if ($q_kelas && mysqli_num_rows($q_kelas) > 0): ?>
                            <?php $no = 1; ?>
                            <?php while ($kelas = mysqli_fetch_assoc($q_kelas)): ?>
                                <?php
                                $wali_kelas = ambil_nama_guru($koneksi, $kelas['id_wali_kelas']);
                                $tahun_info = ambil_tahun_ajaran($koneksi, $kelas['id_tahun_ajaran']);
                                $jumlah_siswa_kelas = hitung_siswa_kelas($koneksi, $kelas['id_kelas']);
                                ?>
                                <tr>
                                    <td><?= $no++; ?></td>

                                    <td>
                                        <div class="nama-kelas">
                                            Kelas <?= h($kelas['nama_kelas']); ?>
                                        </div>
                                    </td>

                                    <td>
                                        <span class="badge">
                                            Kelas <?= (int)$kelas['tingkat']; ?>
                                        </span>
                                    </td>

                                    <td><?= h($wali_kelas); ?></td>

                                    <td><?= h($tahun_info); ?></td>

                                    <td>
                                        <span class="badge badge-siswa">
                                            <?= $jumlah_siswa_kelas; ?> siswa
                                        </span>
                                    </td>

                                    <td>
                                        <div class="aksi">
                                            <a href="index.php?edit=<?= (int)$kelas['id_kelas']; ?>"
                                               class="btn-secondary">✏️</a>

                                            <form method="post"
                                                  onsubmit="return confirm('Hapus data kelas ini?');">
                                                <input type="hidden" name="aksi" value="hapus">
                                                <input type="hidden" name="id_kelas" value="<?= (int)$kelas['id_kelas']; ?>">
                                                <button type="submit" class="btn-danger">🗑️</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" style="text-align:center; padding:45px 15px; color:#94a3b8;">
                                    Belum ada data kelas.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</main>

</body>
</html>
