<?php
session_start();
require_once __DIR__ . '/../../config/auth.php';
wajib_login();
wajib_role('Admin');
require_once __DIR__ . '/../../config/database.php';

if (session_status() === PHP_SESSION_NONE) session_start();
$menu_aktif = 'pengguna';

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function col_exists($cols, $name){ return isset($cols[$name]); }
function q($koneksi, $v){ return mysqli_real_escape_string($koneksi, (string)$v); }

// Ambil struktur tabel users agar modul tetap aman terhadap variasi kolom.
$columns = [];
$res_cols = mysqli_query($koneksi, "SHOW COLUMNS FROM users");
if ($res_cols) {
    while ($c = mysqli_fetch_assoc($res_cols)) $columns[$c['Field']] = $c;
}
if (!$columns) {
    die('Tabel users belum tersedia di database absensi_sd.');
}

$id_col = col_exists($columns,'id_user') ? 'id_user' : (col_exists($columns,'id') ? 'id' : array_key_first($columns));
$user_col = col_exists($columns,'username') ? 'username' : null;
$pass_col = col_exists($columns,'password') ? 'password' : null;
$name_col = col_exists($columns,'nama') ? 'nama' : (col_exists($columns,'nama_user') ? 'nama_user' : null);
$role_col = col_exists($columns,'role') ? 'role' : (col_exists($columns,'level') ? 'level' : null);
$status_col = col_exists($columns,'status') ? 'status' : null;
$guru_col = col_exists($columns,'id_guru') ? 'id_guru' : null;

$alert = '';
$alert_type = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? '';

    if ($aksi === 'simpan') {
        $id = (int)($_POST['id'] ?? 0);
        $username = trim($_POST['username'] ?? '');
        $nama = trim($_POST['nama'] ?? '');
        $role = trim($_POST['role'] ?? 'Admin');
        $status = trim($_POST['status'] ?? 'Aktif');
        $password = (string)($_POST['password'] ?? '');
        $id_guru = (int)($_POST['id_guru'] ?? 0);

        if (!$user_col) {
            $alert='Kolom username tidak ditemukan pada tabel users.'; $alert_type='danger';
        } elseif ($username === '') {
            $alert='Username wajib diisi.'; $alert_type='danger';
        } elseif (!$id && $pass_col && $password === '') {
            $alert='Password wajib diisi untuk pengguna baru.'; $alert_type='danger';
        } else {
            $fields=[]; $values=[];
            $fields[]=$user_col; $values[]="'".q($koneksi,$username)."'";
            if ($name_col) { $fields[]=$name_col; $values[]="'".q($koneksi,$nama)."'"; }
            if ($role_col) { $fields[]=$role_col; $values[]="'".q($koneksi,$role)."'"; }
            if ($status_col) { $fields[]=$status_col; $values[]="'".q($koneksi,$status)."'"; }
            if ($guru_col) { $fields[]=$guru_col; $values[]=($id_guru>0 ? $id_guru : 'NULL'); }
            if ($pass_col && ($password !== '' || !$id)) {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $fields[]=$pass_col; $values[]="'".q($koneksi,$hash)."'";
            }

            if ($id > 0) {
                $sets=[];
                foreach ($fields as $i=>$f) $sets[]="`$f`={$values[$i]}";
                $sql="UPDATE users SET ".implode(',',$sets)." WHERE `$id_col`=$id LIMIT 1";
                $ok=mysqli_query($koneksi,$sql);
                $alert=$ok?'Data pengguna berhasil diperbarui.':'Gagal memperbarui pengguna: '.mysqli_error($koneksi);
                $alert_type=$ok?'success':'danger';
            } else {
                $sql="INSERT INTO users (`".implode('`,`',$fields)."`) VALUES (".implode(',',$values).")";
                $ok=mysqli_query($koneksi,$sql);
                $alert=$ok?'Pengguna baru berhasil ditambahkan.':'Gagal menambahkan pengguna: '.mysqli_error($koneksi);
                $alert_type=$ok?'success':'danger';
            }
        }
    }

    if ($aksi === 'hapus') {
        $id=(int)($_POST['id'] ?? 0);
        if ($id) {
            $ok=mysqli_query($koneksi,"DELETE FROM users WHERE `$id_col`=$id LIMIT 1");
            $alert=$ok?'Pengguna berhasil dihapus.':'Gagal menghapus pengguna: '.mysqli_error($koneksi);
            $alert_type=$ok?'success':'danger';
        }
    }
}

$edit=null;
if (isset($_GET['edit'])) {
    $id=(int)$_GET['edit'];
    $r=mysqli_query($koneksi,"SELECT * FROM users WHERE `$id_col`=$id LIMIT 1");
    $edit=$r?mysqli_fetch_assoc($r):null;
}

// Data guru aktif untuk relasi akun guru/karyawan bila kolom id_guru tersedia.
$guru=[];
if ($guru_col) {
    $rg=mysqli_query($koneksi,"SELECT id_guru,nama,nip,jabatan FROM guru WHERE status='Aktif' ORDER BY nama ASC");
    if($rg) while($g=mysqli_fetch_assoc($rg)) $guru[]=$g;
}

$list=[];
$select='*';
$rl=mysqli_query($koneksi,"SELECT $select FROM users ORDER BY `$id_col` DESC");
if($rl) while($r=mysqli_fetch_assoc($rl)) $list[]=$r;

include __DIR__ . '/../../includes/header.php';
include __DIR__ . '/../../includes/sidebar.php';
?>
<style>
.page-pengguna .wrap{width:100%;max-width:1280px;margin:0 auto}
.page-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;flex-wrap:wrap;margin-bottom:20px}
.page-pengguna h1{margin:0;color:#17233c;font-size:28px;line-height:1.25}
.page-pengguna .sub{color:#64748b;margin:6px 0 0;line-height:1.5}
.password-btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;background:linear-gradient(135deg,#2388f5,#1265dc);color:#fff;text-decoration:none;padding:11px 16px;border-radius:10px;font-weight:600;box-shadow:0 6px 15px rgba(35,136,245,.18)}
.password-btn:hover{background:#1265dc}
.grid{display:grid;grid-template-columns:minmax(300px,380px) minmax(0,1fr);gap:20px;align-items:start}
.card{min-width:0;background:#fff;border-radius:18px;box-shadow:0 8px 25px rgba(15,35,70,.07);padding:22px}
.card h3{margin:0 0 16px;color:#17233c}
.field{margin-bottom:13px}
.field label{display:block;font-size:13px;font-weight:600;color:#334155;margin-bottom:7px}
.field input,.field select{width:100%;box-sizing:border-box;height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:0 12px;background:#fff;max-width:100%;font-size:14px}
.btn{border:0;border-radius:10px;padding:11px 16px;font-weight:600;cursor:pointer}
.btn-primary{background:linear-gradient(135deg,#2388f5,#1265dc);color:#fff}
.btn-muted{background:#eef3f9;color:#334155;text-decoration:none}
.actions{display:flex;gap:8px;align-items:center;margin-top:16px;flex-wrap:wrap}
.alert{padding:13px 15px;border-radius:11px;margin-bottom:18px;font-size:14px;line-height:1.5}
.alert.success{background:#ecfdf3;color:#18794e;border:1px solid #ccefdc}
.alert.danger{background:#fff1f2;color:#be123c;border:1px solid #fecdd3}
.table-wrap{width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch}
.table{width:100%;min-width:620px;border-collapse:collapse;font-size:13px}
.table th,.table td{border:1px solid #dfe6ee;padding:10px 11px;text-align:left}
.table th{background:#f7f9fc;color:#526078;text-transform:uppercase;font-size:11px}
.badge{display:inline-block;padding:5px 9px;border-radius:999px;font-size:11px;font-weight:700;background:#e8eef8;color:#29456f}
.badge.on{background:#e7fbef;color:#157347}.badge.off{background:#feecec;color:#a12d2d}
.mini{font-size:11px;color:#7a8799}
.link-btn{color:#1f6feb;text-decoration:none;font-weight:700;margin-right:9px}
.danger-link{color:#d33;text-decoration:none;font-weight:700;border:0;background:transparent;cursor:pointer;padding:0}
@media (max-width:900px){.grid{grid-template-columns:1fr}.card{padding:18px}}
@media (max-width:600px){.page-pengguna h1{font-size:22px}.password-btn{width:100%;box-sizing:border-box}.card{border-radius:14px;padding:15px}.actions{flex-direction:column;align-items:stretch}}
</style>

<main class="main-content"><div class="page-pengguna"><div class="wrap">
    <div class="page-head">
        <div>
            <h1>👥 Pengguna Aplikasi</h1>
            <div class="sub">Kelola akun yang dapat masuk ke aplikasi Absensi SDN CIBURAYUT 01.</div>
        </div>
        <a class="password-btn" href="ganti_password.php">🔐 Ganti Password Saya</a>
    </div>

    <?php if($alert): ?><div class="alert <?=h($alert_type)?>"><?=h($alert)?></div><?php endif; ?>

    <div class="grid">
        <div class="card">
            <h3><?= $edit ? '✏️ Edit Pengguna' : '➕ Tambah Pengguna' ?></h3>
            <form method="post">
                <input type="hidden" name="aksi" value="simpan">
                <input type="hidden" name="id" value="<?=h($edit[$id_col] ?? 0)?>">
                <div class="field"><label>Username</label><input name="username" required value="<?=h($edit[$user_col] ?? '')?>"></div>
                <div class="field"><label>Nama Pengguna</label><input name="nama" value="<?=h($edit[$name_col] ?? '')?>"></div>
                <?php if($role_col): ?><div class="field"><label>Role</label><select name="role"><option <?= (($edit[$role_col]??'Admin')==='Admin'?'selected':'') ?>>Admin</option><option <?= (($edit[$role_col]??'')==='Guru'?'selected':'') ?>>Guru</option><option <?= (($edit[$role_col]??'')==='Operator'?'selected':'') ?>>Operator</option></select></div><?php endif; ?>
                <?php if($status_col): ?><div class="field"><label>Status</label><select name="status"><option <?= (($edit[$status_col]??'Aktif')==='Aktif'?'selected':'') ?>>Aktif</option><option <?= (($edit[$status_col]??'')==='Tidak Aktif'?'selected':'') ?>>Tidak Aktif</option></select></div><?php endif; ?>
                <?php if($guru_col): ?><div class="field"><label>Hubungkan ke Guru/Karyawan</label><select name="id_guru"><option value="0">-- Tidak dihubungkan --</option><?php foreach($guru as $g): ?><option value="<?=h($g['id_guru'])?>" <?= ((int)($edit[$guru_col]??0)===(int)$g['id_guru']?'selected':'') ?>><?=h($g['nama'])?><?= $g['nip'] ? ' — '.h($g['nip']) : '' ?></option><?php endforeach; ?></select></div><?php endif; ?>
                <?php if($pass_col): ?><div class="field"><label>Password <?= $edit ? '<span class="mini">(kosongkan jika tidak diubah)</span>' : '' ?></label><input type="password" name="password" <?= $edit?'':'required' ?>></div><?php endif; ?>
                <div class="actions"><button class="btn btn-primary" type="submit">💾 <?= $edit?'Simpan Perubahan':'Simpan Pengguna' ?></button><?php if($edit): ?><a class="btn btn-muted" href="index.php">Batal</a><?php endif; ?></div>
            </form>
        </div>

        <div class="card">
            <h3>📋 Daftar Pengguna</h3>
            <div class="table-wrap"><table class="table"><thead><tr><th>#</th><th>Username</th><th>Nama</th><?php if($role_col): ?><th>Role</th><?php endif; ?><?php if($status_col): ?><th>Status</th><?php endif; ?><th>Aksi</th></tr></thead><tbody>
                <?php if(!$list): ?><tr><td colspan="6">Belum ada data pengguna.</td></tr><?php else: foreach($list as $i=>$u): ?>
                    <tr><td><?= $i+1 ?></td><td><strong><?=h($u[$user_col]??'')?></strong></td><td><?=h($name_col?$u[$name_col]:'')?></td><?php if($role_col): ?><td><span class="badge"><?=h($u[$role_col]??'')?></span></td><?php endif; ?><?php if($status_col): ?><td><span class="badge <?= (($u[$status_col]??'')==='Aktif'?'on':'off') ?>"><?=h($u[$status_col]??'')?></span></td><?php endif; ?><td><a class="link-btn" href="?edit=<?=h($u[$id_col])?>">Edit</a><form method="post" style="display:inline" onsubmit="return confirm('Hapus pengguna ini?')"><input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id" value="<?=h($u[$id_col])?>"><button class="danger-link" type="submit">Hapus</button></form></td></tr>
                <?php endforeach; endif; ?>
            </tbody></table></div>
        </div>
    </div>
</div></div>
