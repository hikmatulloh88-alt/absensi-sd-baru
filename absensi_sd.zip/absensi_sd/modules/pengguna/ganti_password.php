<?php
session_start();
require_once __DIR__ . "/../../config/auth.php";
wajib_login();

require_once __DIR__ . "/../../config/database.php";

$user_id = (int)$_SESSION['user_id'];
$pesan = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password_lama = $_POST['password_lama'] ?? '';
    $password_baru = $_POST['password_baru'] ?? '';
    $konfirmasi = $_POST['konfirmasi_password'] ?? '';

    if ($password_lama === '' || $password_baru === '' || $konfirmasi === '') {
        $error = "Semua kolom password wajib diisi.";
    } elseif (strlen($password_baru) < 6) {
        $error = "Password baru minimal 6 karakter.";
    } elseif ($password_baru !== $konfirmasi) {
        $error = "Konfirmasi password tidak sama.";
    } else {
        $stmt = mysqli_prepare($koneksi, "SELECT password FROM users WHERE id_user = ? LIMIT 1");

        if (!$stmt) {
            $error = "Gagal menyiapkan pemeriksaan password.";
        } else {
            mysqli_stmt_bind_param($stmt, "i", $user_id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $user = mysqli_fetch_assoc($result);
            mysqli_stmt_close($stmt);

            if (!$user) {
                $error = "Data pengguna tidak ditemukan.";
            } elseif (!password_verify($password_lama, $user['password'])) {
                $error = "Password lama salah.";
            } else {
                $hash_baru = password_hash($password_baru, PASSWORD_DEFAULT);

                $update = mysqli_prepare($koneksi, "UPDATE users SET password = ? WHERE id_user = ?");
                if (!$update) {
                    $error = "Gagal menyiapkan perubahan password.";
                } else {
                    mysqli_stmt_bind_param($update, "si", $hash_baru, $user_id);

                    if (mysqli_stmt_execute($update)) {
                        $pesan = "Password berhasil diubah.";
                    } else {
                        $error = "Password gagal diubah.";
                    }

                    mysqli_stmt_close($update);
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ganti Password - Absensi SDN Ciburayut 01</title>
    <link rel="stylesheet" href="/absensi_sd/assets/css/main.css">
    <style>
        .password-page{
            margin-left:270px;
            min-height:100vh;
            padding:35px;
            background:#f5f7fb;
            box-sizing:border-box;
        }
        .password-box{
            max-width:650px;
            background:#fff;
            border-radius:18px;
            padding:28px;
            box-shadow:0 10px 30px rgba(15,35,70,.08);
        }
        .password-box h1{
            margin:0 0 8px;
            color:#17233c;
        }
        .password-box .sub{
            color:#64748b;
            margin-bottom:24px;
        }
        .alert{
            padding:12px 14px;
            border-radius:10px;
            margin-bottom:18px;
            font-weight:600;
        }
        .alert.success{background:#dcfce7;color:#166534}
        .alert.error{background:#fee2e2;color:#991b1b}
        .form-group{
            margin-bottom:18px;
        }
        .form-group label{
            display:block;
            margin-bottom:7px;
            font-weight:600;
            color:#334155;
        }
        .form-group input{
            width:100%;
            box-sizing:border-box;
            padding:12px 14px;
            border:1px solid #dbe2ea;
            border-radius:10px;
            outline:none;
            font-size:15px;
        }
        .form-group input:focus{
            border-color:#2388f5;
            box-shadow:0 0 0 3px rgba(35,136,245,.10);
        }
        .password-actions{
            display:flex;
            gap:10px;
            flex-wrap:wrap;
            margin-top:10px;
        }
        .btn{
            border:0;
            border-radius:10px;
            padding:12px 18px;
            cursor:pointer;
            text-decoration:none;
            font-weight:700;
            display:inline-block;
        }
        .btn-primary{background:#2388f5;color:#fff}
        .btn-secondary{background:#e2e8f0;color:#334155}
        @media (max-width: 900px){
            .password-page{margin-left:0;padding:20px}
        }
    </style>
</head>
<body>

<?php
// Sidebar yang sudah digunakan aplikasi.
require_once __DIR__ . "/../../includes/sidebar.php";
?>

<main class="password-page">
    <div class="password-box">
        <h1>🔐 Ganti Password</h1>
        <div class="sub">
            Ganti password akun: <strong><?= htmlspecialchars($_SESSION['username'] ?? 'Pengguna'); ?></strong>
        </div>

        <?php if ($pesan): ?>
            <div class="alert success"><?= htmlspecialchars($pesan); ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert error"><?= htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="post" autocomplete="off">
            <div class="form-group">
                <label>Password Lama</label>
                <input type="password" name="password_lama" required>
            </div>

            <div class="form-group">
                <label>Password Baru</label>
                <input type="password" name="password_baru" minlength="6" required>
            </div>

            <div class="form-group">
                <label>Konfirmasi Password Baru</label>
                <input type="password" name="konfirmasi_password" minlength="6" required>
            </div>

            <div class="password-actions">
                <button type="submit" class="btn btn-primary">Simpan Password</button>
                <a href="/absensi_sd/index.php" class="btn btn-secondary">Kembali</a>
            </div>
        </form>
    </div>
</main>

</body>
</html>
