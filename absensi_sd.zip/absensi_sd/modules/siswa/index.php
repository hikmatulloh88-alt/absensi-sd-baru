<?php
/* STEP 29: Proteksi akses Data Siswa sesuai role */
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator', 'Guru');

require_once "../../config/database.php";
require_once "../../config/dapodik.php";

// Memperbaiki siswa lama yang sudah memiliki Rombel Dapodik tetapi id_kelas masih kosong/salah.
$hasil_sinkron_kelas = dapodik_sync_siswa_kelas($koneksi);

$menu_aktif = 'siswa';
$page_title = 'Data Siswa - Absensi SDN Ciburayut 01';

$pesan = '';
$tipe_pesan = '';
$mode_edit = false;
$data_edit = [
    'id_siswa' => '',
    'nis' => '',
    'nisn' => '',
    'nik' => '',
    'nama_siswa' => '',
    'jenis_kelamin' => 'L',
    'tempat_lahir' => '',
    'tanggal_lahir' => '',
    'agama' => '',
    'alamat' => '',
    'nama_ayah' => '',
    'nama_ibu' => '',
    'nama_wali' => '',
    'no_kk' => '',
    'no_akta' => '',
    'no_kip' => '',
    'id_kelas' => '',
    'status_siswa' => 'Aktif'
];

function bersihkan_nilai($nilai) {
    $nilai = trim((string)$nilai);
    return $nilai === '' ? null : $nilai;
}

/* Cek apakah foto siswa sudah ada di assets/images/siswa/{id}.{ext} */
function cek_foto_siswa_ada($id_siswa) {
    $id = (int)$id_siswa;
    foreach (['jpg','jpeg','png','webp'] as $ext) {
        $path = __DIR__ . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'images' . DIRECTORY_SEPARATOR . 'siswa' . DIRECTORY_SEPARATOR . $id . '.' . $ext;
        $real = realpath($path);
        if ($real && is_file($real)) {
            $relative = str_replace(DIRECTORY_SEPARATOR, '/', substr($real, strlen(realpath(__DIR__ . '/../..'))));
            return '../../' . ltrim($relative, '/');
        }
    }
    return '';
}

function col_index_to_name_siswa($i){
    $name='';
    while($i>0){ $r=($i-1)%26; $name=chr(65+$r).$name; $i=intdiv($i-1,26); }
    return $name;
}

/* Buat file template/hasil xlsx sederhana tanpa library pihak ketiga */
function buat_xlsx_siswa($headers, $rows, $filename){
    if (!class_exists('ZipArchive')) { die('ZipArchive PHP belum aktif.'); }
    $tmp = tempnam(sys_get_temp_dir(), 'xlsx_');
    $zip = new ZipArchive();
    if ($zip->open($tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) { die('Gagal membuat file Excel.'); }

    $contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
</Types>';
    $rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>';
    $workbookRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
</Relationships>';
    $workbook = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets><sheet name="Data Siswa" sheetId="1" r:id="rId1"/></sheets>
</workbook>';

    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<sheetData>';
    $rowNum = 1;
    foreach (array_merge([$headers], $rows) as $rowData) {
        $xml .= '<row r="'.$rowNum.'">';
        $col = 1;
        foreach ($rowData as $value) {
            $ref = col_index_to_name_siswa($col).$rowNum;
            $value = (string)$value;
            $xml .= '<c r="'.$ref.'" t="inlineStr"><is><t xml:space="preserve">'.htmlspecialchars($value, ENT_XML1, 'UTF-8').'</t></is></c>';
            $col++;
        }
        $xml .= '</row>';
        $rowNum++;
    }
    $xml .= '</sheetData></worksheet>';

    $zip->addFromString('[Content_Types].xml', $contentTypes);
    $zip->addFromString('_rels/.rels', $rels);
    $zip->addFromString('xl/workbook.xml', $workbook);
    $zip->addFromString('xl/_rels/workbook.xml.rels', $workbookRels);
    $zip->addFromString('xl/worksheets/sheet1.xml', $xml);
    $zip->close();

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="'.$filename.'"');
    header('Content-Length: '.filesize($tmp));
    readfile($tmp);
    unlink($tmp);
    exit;
}

/* Baca isi file xlsx yang diupload */
function baca_xlsx_siswa($file){
    if (!class_exists('ZipArchive')) { return ['ok'=>false,'error'=>'ZipArchive PHP belum aktif.']; }
    $zip = new ZipArchive();
    if ($zip->open($file) !== true) { return ['ok'=>false,'error'=>'File Excel tidak dapat dibuka.']; }

    $shared = [];
    $shared_xml = $zip->getFromName('xl/sharedStrings.xml');
    if ($shared_xml !== false) {
        $ss = @simplexml_load_string($shared_xml);
        if ($ss) {
            foreach ($ss->si as $si) {
                $txt = '';
                if (isset($si->t)) { $txt = (string)$si->t; }
                else { foreach ($si->r as $run) { $txt .= (string)$run->t; } }
                $shared[] = $txt;
            }
        }
    }

    $sheet = $zip->getFromName('xl/worksheets/sheet1.xml');
    if ($sheet === false) { $zip->close(); return ['ok'=>false,'error'=>'Sheet pertama Excel tidak ditemukan.']; }

    $sx = @simplexml_load_string($sheet);
    if (!$sx) { $zip->close(); return ['ok'=>false,'error'=>'Isi Excel tidak dapat dibaca.']; }

    $rows = [];
    foreach ($sx->sheetData->row as $rowNode) {
        $row = [];
        foreach ($rowNode->c as $cell) {
            $ref = (string)$cell['r'];
            $type = (string)$cell['t'];
            $val = '';
            if ($type === 's' && isset($cell->v)) { $si = (int)$cell->v; $val = $shared[$si] ?? ''; }
            elseif ($type === 'inlineStr') {
                if (isset($cell->is->t)) { $val = (string)$cell->is->t; }
                else { foreach ($cell->is->r as $run) { $val .= (string)$run->t; } }
            } elseif (isset($cell->v)) { $val = (string)$cell->v; }

            preg_match('/^[A-Z]+/', $ref, $m);
            $letters = $m[0] ?? '';
            $idx = 0;
            for ($i = 0; $i < strlen($letters); $i++) { $idx = $idx * 26 + (ord($letters[$i]) - 64); }
            if ($idx > 0) { $row[$idx] = $val; }
        }
        if ($row) {
            ksort($row);
            $max = max(array_keys($row));
            $dense = [];
            for ($i = 1; $i <= $max; $i++) { $dense[] = $row[$i] ?? ''; }
            $rows[] = $dense;
        }
    }
    $zip->close();
    return ['ok'=>true,'rows'=>$rows];
}

/* Kolom template import, urut sesuai form Tambah Siswa */
$kolom_template_siswa = ['NIS','NISN','NIK','Nama Siswa','Jenis Kelamin (L/P)','Tempat Lahir','Tanggal Lahir (YYYY-MM-DD)','Agama','Alamat','Nama Ayah','Nama Ibu','Nama Wali','No KK','No Akta','No KIP','Nama Kelas','Wali Kelas (Otomatis dari Data Kelas)','Tahun Ajaran (Otomatis dari Data Kelas)','Status Siswa (Aktif/Lulus/Pindah/Tidak Aktif)'];

if (isset($_GET['unduh_template'])) {
    buat_xlsx_siswa($kolom_template_siswa, [['','','','Contoh Nama Siswa','L','Bogor','2016-05-10','Islam','Jl. Contoh No.1','','','','','','','Kelas 1','Otomatis dari Data Kelas','Otomatis dari Data Kelas','Aktif']], 'template_import_siswa.xlsx');
}

$pesan_import = '';
$tipe_pesan_import = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'import_excel') {
    if (!isset($_FILES['file_excel']) || $_FILES['file_excel']['error'] !== UPLOAD_ERR_OK) {
        $pesan_import='File Excel gagal diunggah. Coba lagi.'; $tipe_pesan_import='error';
    } elseif (!dapodik_ensure_columns($koneksi)) {
        $pesan_import='Struktur Data Siswa belum dapat dilengkapi. Periksa hak akses database.'; $tipe_pesan_import='error';
    } else {
        $baca=baca_xlsx_siswa($_FILES['file_excel']['tmp_name']);
        if(!$baca['ok']){ $pesan_import=$baca['error']; $tipe_pesan_import='error'; }
        else {
            $rows=$baca['rows']; $headerIndex=-1;
            foreach($rows as $ri=>$row){
                $joined=mb_strtolower(implode(' | ',array_map('strval',$row)),'UTF-8');
                if(str_contains($joined,'nisn') && str_contains($joined,'nama') && str_contains($joined,'rombel')){$headerIndex=$ri;break;}
            }
            if($headerIndex<0){$pesan_import='Header Dapodik tidak ditemukan. Gunakan file Daftar Peserta Didik dari Dapodik.';$tipe_pesan_import='error';}
            else {
                $hdr=$rows[$headerIndex];
                $normHeader=function($v){$v=mb_strtolower(trim((string)$v),'UTF-8');$v=str_replace(["\n","\r"],' ',$v);return preg_replace('/\s+/u',' ',$v);};
                $pos=[]; foreach($hdr as $i=>$h){$k=$normHeader($h); if($k!=='')$pos[$k][]=$i;}
                $at=function($r,$idx){return isset($r[$idx])?trim((string)$r[$idx]):'';};
                $first=function($r,$labels)use($pos,$normHeader,$at){foreach((array)$labels as $lab){$k=$normHeader($lab);if(isset($pos[$k][0])){ $v=$at($r,$pos[$k][0]); if($v!=='')return $v; }}return '';};
                $col=function($r,$oneBased)use($at){return $at($r,$oneBased-1);};
                $sukses=0;$gagal=0;$insert=0;$update=0;$kelas_baru=[];$baris_gagal=[];
                // Dapodik resmi: posisi stabil 25 Ayah, 31 Ibu, 37 Wali, 43 Rombel untuk format 66 kolom.
                for($i=$headerIndex+1;$i<count($rows);$i++){
                    $r=$rows[$i]; if(!array_filter($r,fn($x)=>trim((string)$x)!==''))continue;
                    $nama=$first($r,['Nama']); if($nama===''){$gagal++;$baris_gagal[]='Baris '.($i+1).': nama kosong';continue;}
                    $nis=bersihkan_nilai($first($r,['NIPD'])); $nisn=bersihkan_nilai($first($r,['NISN'])); $nik=bersihkan_nilai($first($r,['NIK']));
                    $jk=strtoupper($first($r,['JK'])); if(!in_array($jk,['L','P'],true))$jk='L';
                    $rombel='';
                    if(count($hdr)>=66)$rombel=$col($r,43); else $rombel=$first($r,['Rombel Saat Ini']);
                    $idkelas=dapodik_find_class_id($koneksi,$rombel,true);
                    if($rombel!=='' && $idkelas<=0){$gagal++;$baris_gagal[]='Baris '.($i+1).': rombel tidak dapat dibuat '.$rombel;continue;}
                    $vals=[
                      'nis'=>$nis,'nisn'=>$nisn,'nik'=>$nik,'nama_siswa'=>$nama,'jenis_kelamin'=>$jk,
                      'tempat_lahir'=>bersihkan_nilai($first($r,['Tempat Lahir'])),'tanggal_lahir'=>dapodik_date($first($r,['Tanggal Lahir'])),'agama'=>bersihkan_nilai($first($r,['Agama'])),'alamat'=>bersihkan_nilai($first($r,['Alamat'])),'id_kelas'=>$idkelas?:null,'status_siswa'=>'Aktif','rombel_dapodik'=>bersihkan_nilai($rombel),
                      'rt'=>bersihkan_nilai($first($r,['RT'])),'rw'=>bersihkan_nilai($first($r,['RW'])),'dusun'=>bersihkan_nilai($first($r,['Dusun'])),'kelurahan'=>bersihkan_nilai($first($r,['Kelurahan'])),'kecamatan'=>bersihkan_nilai($first($r,['Kecamatan'])),'kode_pos'=>bersihkan_nilai($first($r,['Kode Pos'])),'jenis_tinggal'=>bersihkan_nilai($first($r,['Jenis Tinggal'])),'alat_transportasi'=>bersihkan_nilai($first($r,['Alat Transportasi'])),'telepon'=>bersihkan_nilai($first($r,['Telepon'])),'hp'=>bersihkan_nilai($first($r,['HP'])),'email'=>bersihkan_nilai($first($r,['E-Mail'])),'skhun'=>bersihkan_nilai($first($r,['SKHUN'])),'penerima_kps'=>bersihkan_nilai($first($r,['Penerima KPS'])),'no_kps'=>bersihkan_nilai($first($r,['No. KPS'])),'no_kk'=>bersihkan_nilai($first($r,['No KK'])),'berat_badan'=>bersihkan_nilai($first($r,['Berat Badan'])),'tinggi_badan'=>bersihkan_nilai($first($r,['Tinggi Badan'])),'lingkar_kepala'=>bersihkan_nilai($first($r,['Lingkar Kepala'])),'jml_saudara_kandung'=>bersihkan_nilai($first($r,['Jml. Saudara Kandung'])),'jarak_rumah_km'=>bersihkan_nilai($first($r,['Jarak Rumah ke Sekolah (KM)']))
                    ];
                    if(count($hdr)>=66){
                        $vals['nama_ayah']=bersihkan_nilai($col($r,25));$vals['ayah_tahun_lahir']=bersihkan_nilai($col($r,26));$vals['ayah_pendidikan']=bersihkan_nilai($col($r,27));$vals['ayah_pekerjaan']=bersihkan_nilai($col($r,28));$vals['ayah_penghasilan']=bersihkan_nilai($col($r,29));$vals['ayah_nik']=bersihkan_nilai($col($r,30));
                        $vals['nama_ibu']=bersihkan_nilai($col($r,31));$vals['ibu_tahun_lahir']=bersihkan_nilai($col($r,32));$vals['ibu_pendidikan']=bersihkan_nilai($col($r,33));$vals['ibu_pekerjaan']=bersihkan_nilai($col($r,34));$vals['ibu_penghasilan']=bersihkan_nilai($col($r,35));$vals['ibu_nik']=bersihkan_nilai($col($r,36));
                        $vals['nama_wali']=bersihkan_nilai($col($r,37));$vals['wali_tahun_lahir']=bersihkan_nilai($col($r,38));$vals['wali_pendidikan']=bersihkan_nilai($col($r,39));$vals['wali_pekerjaan']=bersihkan_nilai($col($r,40));$vals['wali_penghasilan']=bersihkan_nilai($col($r,41));$vals['wali_nik']=bersihkan_nilai($col($r,42));
                        $vals['no_peserta_ujian']=bersihkan_nilai($col($r,44));$vals['no_ijazah']=bersihkan_nilai($col($r,45));$vals['penerima_kip']=bersihkan_nilai($col($r,46));$vals['nomor_kip']=bersihkan_nilai($col($r,47));$vals['nama_di_kip']=bersihkan_nilai($col($r,48));$vals['nomor_kks']=bersihkan_nilai($col($r,49));$vals['no_registrasi_akta_lahir']=bersihkan_nilai($col($r,50));$vals['bank']=bersihkan_nilai($col($r,51));$vals['nomor_rekening_bank']=bersihkan_nilai($col($r,52));$vals['rekening_atas_nama']=bersihkan_nilai($col($r,53));$vals['layak_pip']=bersihkan_nilai($col($r,54));$vals['alasan_layak_pip']=bersihkan_nilai($col($r,55));$vals['kebutuhan_khusus']=bersihkan_nilai($col($r,56));$vals['sekolah_asal']=bersihkan_nilai($col($r,57));$vals['anak_ke']=bersihkan_nilai($col($r,58));$vals['lintang']=bersihkan_nilai($col($r,59));$vals['bujur']=bersihkan_nilai($col($r,60));
                    } else {
                        $vals['nama_ayah']=bersihkan_nilai($first($r,['Data Ayah']));$vals['ayah_tahun_lahir']=bersihkan_nilai($col($r,26));$vals['ayah_pendidikan']=bersihkan_nilai($col($r,27));$vals['ayah_pekerjaan']=bersihkan_nilai($col($r,28));$vals['ayah_penghasilan']=bersihkan_nilai($col($r,29));$vals['ayah_nik']=bersihkan_nilai($col($r,30));
                        $vals['nama_ibu']=bersihkan_nilai($first($r,['Data Ibu']));$vals['ibu_tahun_lahir']=bersihkan_nilai($col($r,32));$vals['ibu_pendidikan']=bersihkan_nilai($col($r,33));$vals['ibu_pekerjaan']=bersihkan_nilai($col($r,34));$vals['ibu_penghasilan']=bersihkan_nilai($col($r,35));$vals['ibu_nik']=bersihkan_nilai($col($r,36));
                        $vals['anak_ke']=bersihkan_nilai($col($r,38));$vals['lintang']=bersihkan_nilai($col($r,39));$vals['bujur']=bersihkan_nilai($col($r,40));
                    }
                    // Cari siswa lama tanpa membuat duplikat.
                    $existingId=0;
                    foreach([['nisn',$nisn],['nik',$nik],['nis',$nis]] as [$field,$value]){
                        if($existingId||$value===null||$value==='')continue;
                        $st=mysqli_prepare($koneksi,"SELECT id_siswa FROM siswa WHERE `$field`=? LIMIT 1"); if($st){mysqli_stmt_bind_param($st,'s',$value);mysqli_stmt_execute($st);$rr=mysqli_stmt_get_result($st);if($rr&&($x=mysqli_fetch_assoc($rr)))$existingId=(int)$x['id_siswa'];}
                    }
                    if($existingId){
                        // Field kosong dari Dapodik tidak menghapus data manual yang sudah ada.
                        $sets=[];$params=[];$types='';foreach($vals as $f=>$v){if($v===null||$v==='')continue;$sets[]="`$f`=?";$params[]=$v;$types.='s';}
                        if($sets){$params[]=$existingId;$types.='i';$st=mysqli_prepare($koneksi,'UPDATE siswa SET '.implode(',',$sets).' WHERE id_siswa=?');if($st&&mysqli_stmt_bind_param($st,$types,...$params)&&mysqli_stmt_execute($st)){$sukses++;$update++;}else{$gagal++;$baris_gagal[]='Baris '.($i+1).': gagal update '.($st?mysqli_stmt_error($st):mysqli_error($koneksi));}}else{$sukses++;$update++;}
                    } else {
                        $fields=array_keys($vals);$marks=implode(',',array_fill(0,count($fields),'?'));$types=str_repeat('s',count($fields));$params=array_values($vals);$st=mysqli_prepare($koneksi,'INSERT INTO siswa (`'.implode('`,`',$fields).'`) VALUES ('.$marks.')');
                        if($st&&mysqli_stmt_bind_param($st,$types,...$params)&&mysqli_stmt_execute($st)){$sukses++;$insert++;}else{$gagal++;$baris_gagal[]='Baris '.($i+1).': gagal insert '.($st?mysqli_stmt_error($st):mysqli_error($koneksi));}
                    }
                }
                $pesan_import="$sukses siswa diproses (insert $insert, update $update).";
                $pesan_import.=' Rombel Dapodik dipetakan ke Data Kelas dan disimpan di master siswa.';
                if($gagal)$pesan_import.=" Gagal $gagal baris: ".implode('; ',array_slice($baris_gagal,0,5)).(count($baris_gagal)>5?'; ...':'');
                $tipe_pesan_import=$sukses>0?'success':'error';
            }
        }
    }
}

/* Upload foto siswa massal — nama file harus NIS, NISN, atau ID Siswa */
$pesan_foto = '';
$tipe_pesan_foto = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'upload_foto_massal') {
    if (empty($_FILES['foto_massal']) || empty($_FILES['foto_massal']['name'][0])) {
        $pesan_foto = 'Belum ada file foto yang dipilih.';
        $tipe_pesan_foto = 'error';
    } else {
        // Peta NIS/NISN/ID siswa -> id_siswa, untuk mencocokkan nama file
        $peta_siswa = [];
        $qs = mysqli_query($koneksi, "SELECT id_siswa, nis, nisn FROM siswa");
        if ($qs) {
            while ($s = mysqli_fetch_assoc($qs)) {
                $peta_siswa[(string)$s['id_siswa']] = (int)$s['id_siswa'];
                if (!empty($s['nis'])) $peta_siswa[trim($s['nis'])] = (int)$s['id_siswa'];
                if (!empty($s['nisn'])) $peta_siswa[trim($s['nisn'])] = (int)$s['id_siswa'];
            }
        }

        $folder_tujuan = __DIR__ . '/../../assets/images/siswa/';
        if (!is_dir($folder_tujuan)) { @mkdir($folder_tujuan, 0755, true); }

        $ekstensi_diizinkan = ['jpg','jpeg','png','webp'];
        $sukses_foto = 0; $gagal_foto = 0; $detail_gagal_foto = [];
        $jumlah_file = count($_FILES['foto_massal']['name']);

        for ($i = 0; $i < $jumlah_file; $i++) {
            $nama_asli = $_FILES['foto_massal']['name'][$i];
            $tmp_path = $_FILES['foto_massal']['tmp_name'][$i];
            $error_upload = $_FILES['foto_massal']['error'][$i];

            if ($error_upload !== UPLOAD_ERR_OK) { $gagal_foto++; $detail_gagal_foto[] = "$nama_asli: gagal diunggah"; continue; }

            $info = pathinfo($nama_asli);
            $kode = trim($info['filename'] ?? '');
            $ext = strtolower($info['extension'] ?? '');

            if (!in_array($ext, $ekstensi_diizinkan, true)) { $gagal_foto++; $detail_gagal_foto[] = "$nama_asli: format tidak didukung"; continue; }
            if (!isset($peta_siswa[$kode])) { $gagal_foto++; $detail_gagal_foto[] = "$nama_asli: tidak ada siswa dengan NIS/NISN/ID \"$kode\""; continue; }

            $id_siswa_tujuan = $peta_siswa[$kode];
            $tujuan = $folder_tujuan . $id_siswa_tujuan . '.' . $ext;

            // Hapus foto lama dengan ekstensi lain agar tidak duplikat/ambigu
            foreach ($ekstensi_diizinkan as $e) {
                $lama = $folder_tujuan . $id_siswa_tujuan . '.' . $e;
                if ($e !== $ext && is_file($lama)) { @unlink($lama); }
            }

            if (@move_uploaded_file($tmp_path, $tujuan)) { $sukses_foto++; }
            else { $gagal_foto++; $detail_gagal_foto[] = "$nama_asli: gagal disimpan ke server"; }
        }

        $pesan_foto = "$sukses_foto foto berhasil diunggah." . ($gagal_foto > 0 ? " $gagal_foto gagal (".implode('; ', array_slice($detail_gagal_foto,0,5)).(count($detail_gagal_foto)>5?'; ...':'').")" : '');
        $tipe_pesan_foto = $gagal_foto > 0 && $sukses_foto === 0 ? 'error' : 'success';
    }
}

/* Upload foto satu siswa (dari tombol 📷 di baris tabel) */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'upload_foto_satu') {
    $id_siswa_foto = (int)($_POST['id_siswa'] ?? 0);
    if ($id_siswa_foto <= 0) {
        $pesan_foto = 'Siswa tidak ditemukan.';
        $tipe_pesan_foto = 'error';
    } elseif (empty($_FILES['foto_satu']) || $_FILES['foto_satu']['error'] !== UPLOAD_ERR_OK) {
        $pesan_foto = 'Foto gagal diunggah. Coba lagi.';
        $tipe_pesan_foto = 'error';
    } else {
        $ekstensi_diizinkan_satu = ['jpg','jpeg','png','webp'];
        $info_satu = pathinfo($_FILES['foto_satu']['name']);
        $ext_satu = strtolower($info_satu['extension'] ?? '');

        if (!in_array($ext_satu, $ekstensi_diizinkan_satu, true)) {
            $pesan_foto = 'Format foto tidak didukung. Gunakan JPG, JPEG, PNG, atau WEBP.';
            $tipe_pesan_foto = 'error';
        } else {
            $folder_tujuan_satu = __DIR__ . '/../../assets/images/siswa/';
            if (!is_dir($folder_tujuan_satu)) { @mkdir($folder_tujuan_satu, 0755, true); }

            foreach ($ekstensi_diizinkan_satu as $e) {
                $lama_satu = $folder_tujuan_satu . $id_siswa_foto . '.' . $e;
                if (is_file($lama_satu)) { @unlink($lama_satu); }
            }

            $tujuan_satu = $folder_tujuan_satu . $id_siswa_foto . '.' . $ext_satu;
            if (@move_uploaded_file($_FILES['foto_satu']['tmp_name'], $tujuan_satu)) {
                $pesan_foto = 'Foto siswa berhasil diperbarui. Disimpan di: ' . str_replace('\\', '/', realpath($tujuan_satu)) . ' (folder modul: ' . str_replace('\\', '/', __DIR__) . ')';
                $tipe_pesan_foto = 'success';
            } else {
                $pesan_foto = 'Gagal menyimpan foto ke server.';
                $tipe_pesan_foto = 'error';
            }
        }
    }
}


/* SIMPAN / UPDATE */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? '';

    if ($aksi === 'simpan') {
        $id_siswa       = (int)($_POST['id_siswa'] ?? 0);
        $nis            = bersihkan_nilai($_POST['nis'] ?? '');
        $nisn           = bersihkan_nilai($_POST['nisn'] ?? '');
        $nik            = bersihkan_nilai($_POST['nik'] ?? '');
        $nama_siswa     = trim($_POST['nama_siswa'] ?? '');
        $jenis_kelamin  = $_POST['jenis_kelamin'] ?? 'L';
        $tempat_lahir   = bersihkan_nilai($_POST['tempat_lahir'] ?? '');
        $tanggal_lahir  = bersihkan_nilai($_POST['tanggal_lahir'] ?? '');
        $agama          = bersihkan_nilai($_POST['agama'] ?? '');
        $alamat         = bersihkan_nilai($_POST['alamat'] ?? '');
        $nama_ayah      = bersihkan_nilai($_POST['nama_ayah'] ?? '');
        $nama_ibu       = bersihkan_nilai($_POST['nama_ibu'] ?? '');
        $nama_wali      = bersihkan_nilai($_POST['nama_wali'] ?? '');
        $no_kk          = bersihkan_nilai($_POST['no_kk'] ?? '');
        $no_akta        = bersihkan_nilai($_POST['no_akta'] ?? '');
        $no_kip         = bersihkan_nilai($_POST['no_kip'] ?? '');
        $id_kelas       = (int)($_POST['id_kelas'] ?? 0);
        $status_siswa   = $_POST['status_siswa'] ?? 'Aktif';

        if ($nama_siswa === '') {
            $pesan = 'Nama siswa wajib diisi.';
            $tipe_pesan = 'error';
        } elseif (!in_array($jenis_kelamin, ['L', 'P'], true)) {
            $pesan = 'Jenis kelamin tidak valid.';
            $tipe_pesan = 'error';
        } elseif (!in_array($status_siswa, ['Aktif', 'Lulus', 'Pindah', 'Tidak Aktif'], true)) {
            $pesan = 'Status siswa tidak valid.';
            $tipe_pesan = 'error';
        } else {
            try {
                if ($id_siswa > 0) {
                    $sql = "UPDATE siswa SET
                                nis = ?, nisn = ?, nik = ?, nama_siswa = ?, jenis_kelamin = ?,
                                tempat_lahir = ?, tanggal_lahir = ?, agama = ?, alamat = ?,
                                nama_ayah = ?, nama_ibu = ?, nama_wali = ?, no_kk = ?,
                                no_akta = ?, no_kip = ?, id_kelas = NULLIF(?, 0),
                                status_siswa = ?
                            WHERE id_siswa = ?";

                    $stmt = mysqli_prepare($koneksi, $sql);
                    mysqli_stmt_bind_param(
                        $stmt,
                        "sssssssssssssssisi",
                        $nis, $nisn, $nik, $nama_siswa, $jenis_kelamin,
                        $tempat_lahir, $tanggal_lahir, $agama, $alamat,
                        $nama_ayah, $nama_ibu, $nama_wali, $no_kk,
                        $no_akta, $no_kip, $id_kelas, $status_siswa,
                        $id_siswa
                    );
                } else {
                    $sql = "INSERT INTO siswa (
                                nis, nisn, nik, nama_siswa, jenis_kelamin,
                                tempat_lahir, tanggal_lahir, agama, alamat,
                                nama_ayah, nama_ibu, nama_wali, no_kk,
                                no_akta, no_kip, id_kelas, status_siswa
                            ) VALUES (
                                ?, ?, ?, ?, ?,
                                ?, ?, ?, ?,
                                ?, ?, ?, ?,
                                ?, ?, NULLIF(?, 0), ?
                            )";

                    $stmt = mysqli_prepare($koneksi, $sql);
                    mysqli_stmt_bind_param(
                        $stmt,
                        "sssssssssssssssis",
                        $nis, $nisn, $nik, $nama_siswa, $jenis_kelamin,
                        $tempat_lahir, $tanggal_lahir, $agama, $alamat,
                        $nama_ayah, $nama_ibu, $nama_wali, $no_kk,
                        $no_akta, $no_kip, $id_kelas, $status_siswa
                    );
                }

                if ($stmt && mysqli_stmt_execute($stmt)) {
                    header("Location: index.php?sukses=1");
                    exit;
                }

                $pesan = 'Data gagal disimpan. Periksa kemungkinan NISN/NIK sudah digunakan.';
                $tipe_pesan = 'error';
            } catch (Throwable $e) {
                $pesan = 'Data gagal disimpan. Pastikan struktur database sesuai.';
                $tipe_pesan = 'error';
            }
        }
    }

    if ($aksi === 'hapus_massal') {
        $ids_hapus = $_POST['id_siswa_massal'] ?? [];
        if (!is_array($ids_hapus)) { $ids_hapus = []; }

        $ids_hapus = array_values(array_unique(array_filter(array_map('intval', $ids_hapus), function($id){
            return $id > 0;
        })));

        if (count($ids_hapus) === 0) {
            header("Location: index.php?hapus_massal=0");
            exit;
        }

        $folder_foto_massal = __DIR__ . '/../../assets/images/siswa/';
        $berhasil_hapus = 0;
        $gagal_hapus = 0;

        mysqli_begin_transaction($koneksi);
        try {
            $stmt_hapus_massal = mysqli_prepare($koneksi, "DELETE FROM siswa WHERE id_siswa = ?");
            if (!$stmt_hapus_massal) {
                throw new Exception('Gagal menyiapkan proses penghapusan.');
            }

            foreach ($ids_hapus as $id_hapus_massal) {
                mysqli_stmt_bind_param($stmt_hapus_massal, "i", $id_hapus_massal);
                if (mysqli_stmt_execute($stmt_hapus_massal) && mysqli_stmt_affected_rows($stmt_hapus_massal) > 0) {
                    $berhasil_hapus++;
                    foreach (['jpg','jpeg','png','webp'] as $ext_foto) {
                        $file_foto = $folder_foto_massal . $id_hapus_massal . '.' . $ext_foto;
                        if (is_file($file_foto)) { @unlink($file_foto); }
                    }
                } else {
                    $gagal_hapus++;
                }
            }

            mysqli_commit($koneksi);
            header("Location: index.php?hapus_massal=" . $berhasil_hapus . "&gagal_massal=" . $gagal_hapus);
            exit;
        } catch (Throwable $e) {
            mysqli_rollback($koneksi);
            $pesan = 'Penghapusan massal gagal. Data tidak diubah.';
            $tipe_pesan = 'error';
        }
    }

    if ($aksi === 'hapus') {
        $id_hapus = (int)($_POST['id_siswa'] ?? 0);

        if ($id_hapus > 0) {
            try {
                $stmt = mysqli_prepare($koneksi, "DELETE FROM siswa WHERE id_siswa = ?");
                mysqli_stmt_bind_param($stmt, "i", $id_hapus);

                if (mysqli_stmt_execute($stmt)) {
                    header("Location: index.php?hapus=1");
                    exit;
                }

                $pesan = 'Data siswa tidak dapat dihapus.';
                $tipe_pesan = 'error';
            } catch (Throwable $e) {
                $pesan = 'Data siswa tidak dapat dihapus. Data mungkin sudah dipakai pada modul lain.';
                $tipe_pesan = 'error';
            }
        }
    }
}

if (isset($_GET['sukses'])) {
    $pesan = 'Data siswa berhasil disimpan.';
    $tipe_pesan = 'success';
}

if (isset($_GET['hapus'])) {
    $pesan = 'Data siswa berhasil dihapus.';
    $tipe_pesan = 'success';
}

if (isset($_GET['hapus_massal'])) {
    $jumlah_hapus_massal = (int)$_GET['hapus_massal'];
    $jumlah_gagal_massal = (int)($_GET['gagal_massal'] ?? 0);
    if ($jumlah_hapus_massal > 0) {
        $pesan = $jumlah_hapus_massal . ' data siswa berhasil dihapus secara massal.'
            . ($jumlah_gagal_massal > 0 ? ' ' . $jumlah_gagal_massal . ' data gagal dihapus.' : '');
        $tipe_pesan = 'success';
    } else {
        $pesan = 'Tidak ada siswa yang dipilih.';
        $tipe_pesan = 'error';
    }
}

/* DATA UNTUK FORM EDIT */
if (isset($_GET['edit'])) {
    $id_edit = (int)$_GET['edit'];

    if ($id_edit > 0) {
        $stmt = mysqli_prepare($koneksi, "SELECT * FROM siswa WHERE id_siswa = ?");
        mysqli_stmt_bind_param($stmt, "i", $id_edit);
        mysqli_stmt_execute($stmt);
        $hasil_edit = mysqli_stmt_get_result($stmt);

        if ($hasil_edit && mysqli_num_rows($hasil_edit) === 1) {
            $data_edit = mysqli_fetch_assoc($hasil_edit);
            $mode_edit = true;
        }
    }
}

/* DATA KELAS */
$daftar_kelas = [];
$q_kelas = mysqli_query(
    $koneksi,
    "SELECT id_kelas, nama_kelas, tingkat
     FROM kelas
     ORDER BY tingkat ASC, nama_kelas ASC"
);

if ($q_kelas) {
    while ($baris = mysqli_fetch_assoc($q_kelas)) {
        $daftar_kelas[] = $baris;
    }
}

/* PENCARIAN SISWA */
$cari = trim($_GET['cari'] ?? '');
$cari_sql = mysqli_real_escape_string($koneksi, $cari);

$sql_siswa = "SELECT
                s.id_siswa,
                s.nis,
                s.nisn,
                s.nama_siswa,
                s.jenis_kelamin,
                s.status_siswa,
                k.nama_kelas,
                k.id_wali_kelas,
                g.nama AS nama_wali_kelas,
                k.id_tahun_ajaran,
                ta.tahun_ajaran,
                ta.semester
              FROM siswa s
              LEFT JOIN kelas k ON k.id_kelas = s.id_kelas
              LEFT JOIN guru g ON g.id_guru = k.id_wali_kelas
              LEFT JOIN tahun_ajaran ta ON ta.id_tahun_ajaran = k.id_tahun_ajaran";

if ($cari !== '') {
    $sql_siswa .= " WHERE
                    s.nama_siswa LIKE '%$cari_sql%'
                    OR s.nis LIKE '%$cari_sql%'
                    OR s.nisn LIKE '%$cari_sql%'";
}

$sql_siswa .= " ORDER BY s.nama_siswa ASC";

$q_siswa = mysqli_query($koneksi, $sql_siswa);
$jumlah_data = $q_siswa ? mysqli_num_rows($q_siswa) : 0;

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>

<style>
.siswa-page {
    max-width: 1400px;
}

.page-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    margin-bottom: 24px;
}

.page-head h1 {
    margin-bottom: 6px;
}

.page-head p {
    margin: 0;
}

.btn-primary,
.btn-secondary,
.btn-danger {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 7px;
    border: 0;
    border-radius: 10px;
    padding: 11px 16px;
    text-decoration: none;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
}

.btn-primary {
    background: linear-gradient(135deg, #2388f5, #1265dc);
    color: #fff;
    box-shadow: 0 8px 18px rgba(18,101,220,.22);
}

.btn-secondary {
    background: #eef3f9;
    color: #334155;
}

.btn-danger {
    background: #fff0f1;
    color: #c92f47;
}

.data-panel {
    background: #fff;
    border-radius: 18px;
    box-shadow: 0 8px 25px rgba(15, 35, 70, .07);
    padding: 22px;
    margin-bottom: 22px;
}

.toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    flex-wrap: wrap;
}

.search-form {
    display: flex;
    gap: 8px;
    flex: 1;
    max-width: 560px;
}

.search-form input {
    width: 100%;
    height: 42px;
    border: 1px solid #dbe4ef;
    border-radius: 10px;
    padding: 0 13px;
    outline: none;
}

.search-form input:focus,
.form-control:focus {
    border-color: #2388f5;
    box-shadow: 0 0 0 3px rgba(35,136,245,.10);
}

.data-count {
    color: #64748b;
    font-size: 14px;
}

.bulk-delete-bar {
    display: none;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    flex-wrap: wrap;
    margin-top: 14px;
    padding: 12px 14px;
    border: 1px solid #fee2e2;
    background: #fff7f7;
    border-radius: 12px;
}

.bulk-delete-bar.active {
    display: flex;
}

.bulk-delete-info {
    color: #7f1d1d;
    font-size: 14px;
    font-weight: 600;
}

.bulk-delete-actions {
    display: flex;
    align-items: center;
    gap: 8px;
}

.btn-danger.bulk {
    background: #dc3545;
    color: #fff;
    box-shadow: 0 6px 14px rgba(220,53,69,.18);
}


.select-all-toggle {
    display:inline-flex; align-items:center; gap:9px; cursor:pointer; user-select:none;
    font-weight:700; color:#334155; margin-right:14px;
}
.select-all-toggle input { position:absolute; opacity:0; pointer-events:none; }
.toggle-slider { position:relative; width:42px; height:24px; border-radius:999px; background:#cbd5e1; transition:.2s; flex:0 0 auto; }
.toggle-slider:after { content:""; position:absolute; width:18px; height:18px; left:3px; top:3px; border-radius:50%; background:#fff; box-shadow:0 1px 3px rgba(0,0,0,.2); transition:.2s; }
.select-all-toggle input:checked + .toggle-slider { background:#2563eb; }
.select-all-toggle input:checked + .toggle-slider:after { transform:translateX(18px); }
.select-all-toggle input:indeterminate + .toggle-slider { background:#94a3b8; }
.toggle-label { white-space:nowrap; }
.bulk-selected-text { color:#475569; }

.select-col {
    width: 42px;
    text-align: center !important;
}

.siswa-check,
#checkAllSiswa {
    width: 17px;
    height: 17px;
    cursor: pointer;
    accent-color: #dc3545;
}

.alert {
    padding: 13px 15px;
    border-radius: 11px;
    margin-bottom: 18px;
    font-size: 14px;
}

.alert-success {
    background: #ecfdf3;
    color: #18794e;
    border: 1px solid #ccefdc;
}

.alert-error {
    background: #fff1f2;
    color: #be123c;
    border: 1px solid #fecdd3;
}

.table-wrap {
    overflow-x: auto;
    margin-top: 18px;
}

.data-table {
    width: 100%;
    border-collapse: collapse;
    min-width: 900px;
}

.data-table th {
    text-align: left;
    background: #f7f9fc;
    color: #64748b;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: .5px;
    padding: 13px 12px;
}

.data-table td {
    padding: 14px 12px;
    border-bottom: 1px solid #edf1f6;
    font-size: 14px;
    color: #334155;
}

.data-table tr:hover td {
    background: #fbfdff;
}

.nama-siswa {
    font-weight: 700;
    color: #17233c;
}

.sub-text {
    font-size: 12px;
    color: #94a3b8;
    margin-top: 3px;
}

.badge {
    display: inline-flex;
    align-items: center;
    padding: 5px 9px;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 700;
}

.badge-aktif {
    background: #eaf7ef;
    color: #16804a;
}

.badge-lain {
    background: #eef2f7;
    color: #64748b;
}

.aksi {
    display: flex;
    gap: 7px;
}

.form-card {
    background: #fff;
    border-radius: 18px;
    box-shadow: 0 8px 25px rgba(15, 35, 70, .07);
    padding: 24px;
    margin-bottom: 22px;
}

.form-title {
    margin: 0 0 5px;
    color: #17233c;
}

.form-subtitle {
    margin: 0 0 20px;
    color: #64748b;
    font-size: 14px;
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 15px;
}

.form-group {
    display: flex;
    flex-direction: column;
    gap: 7px;
}

.form-group.full {
    grid-column: 1 / -1;
}

.form-label {
    font-size: 13px;
    font-weight: 600;
    color: #334155;
}

.form-control {
    width: 100%;
    min-height: 42px;
    border: 1px solid #dbe4ef;
    border-radius: 10px;
    padding: 9px 11px;
    outline: none;
    background: #fff;
    font: inherit;
}

textarea.form-control {
    min-height: 80px;
    resize: vertical;
}

.form-actions {
    display: flex;
    gap: 9px;
    margin-top: 20px;
}

@media (max-width: 1000px) {
    .form-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}

@media (max-width: 700px) {
    .page-head {
        align-items: flex-start;
        flex-direction: column;
    }

    .form-grid {
        grid-template-columns: 1fr;
    }

    .form-group.full {
        grid-column: auto;
    }

    .search-form {
        max-width: none;
        width: 100%;
    }
}
</style>

<main class="main-content">
    <div class="siswa-page">

        <div class="page-head">
            <div>
                <h1>Data Siswa</h1>
                <p>Kelola data peserta didik SDN Ciburayut 01.</p>
            </div>

            <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <button type="button" id="btnToggleFoto" class="btn-primary" style="background:#fff;color:#1677e8;border:1px solid #1677e8;">
                    📷 Upload Foto Massal
                </button>
                <button type="button" id="btnToggleImport" class="btn-primary" style="background:#fff;color:#1677e8;border:1px solid #1677e8;">
                    📥 Import Excel
                </button>
                <button type="button" id="btnToggleHapusMassal" class="btn-primary" style="background:#fff;color:#dc3545;border:1px solid #f1aeb5;">
                    🗑️ Hapus Banyak Data
                </button>
                <a href="index.php?tambah=1" class="btn-primary">
                    ➕ Tambah Siswa
                </a>
            </div>
        </div>

        <?php if ($pesan_foto !== ''): ?>
            <div class="alert <?= $tipe_pesan_foto === 'success' ? 'alert-success' : 'alert-error'; ?>">
                <?= htmlspecialchars($pesan_foto); ?>
            </div>
        <?php endif; ?>

        <div id="panelFoto" class="form-card" style="display:none;">
            <h2 class="form-title">📷 Upload Foto Siswa Massal</h2>
            <p class="form-subtitle">
                Pilih banyak foto sekaligus. <strong>Nama file harus sesuai NIS, NISN, atau ID Siswa</strong> (contoh: <code>1023.jpg</code> atau <code>7.png</code>), supaya sistem otomatis mencocokkan foto ke siswa yang benar. Format yang didukung: JPG, JPEG, PNG, WEBP.
            </p>
            <form method="post" action="index.php" enctype="multipart/form-data" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
                <input type="hidden" name="aksi" value="upload_foto_massal">
                <input type="file" name="foto_massal[]" accept=".jpg,.jpeg,.png,.webp" multiple required>
                <button type="submit" class="btn-primary">⬆️ Upload Semua Foto</button>
            </form>
        </div>

        <?php if ($pesan_import !== ''): ?>
            <div class="alert <?= $tipe_pesan_import === 'success' ? 'alert-success' : 'alert-error'; ?>">
                <?= htmlspecialchars($pesan_import); ?>
            </div>
        <?php endif; ?>

        <div id="panelImport" class="form-card" style="display:none;">
            <h2 class="form-title">📥 Import Data Siswa Massal (Excel)</h2>
            <p class="form-subtitle">
                Bisa upload <strong>file Daftar Peserta Didik Dapodik asli</strong> maupun template aplikasi. Sistem mendeteksi header Dapodik otomatis, termasuk file yang memiliki baris informasi sebelum header. Data Dapodik disimpan ke MASTER DATA SISWA; kelas dicocokkan otomatis dari kolom Rombel Saat Ini. Wali kelas dan tahun ajaran tetap mengikuti pengaturan pada menu Data Kelas.
            </p>
            <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:16px;">
                <a href="index.php?unduh_template=1" class="btn-primary" style="background:#eef3f9;color:#334155;">⬇️ Download Template Excel</a>
            </div>
            <form method="post" action="index.php" enctype="multipart/form-data" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
                <input type="hidden" name="aksi" value="import_excel">
                <input type="file" name="file_excel" accept=".xlsx" required>
                <button type="submit" class="btn-primary">⬆️ Upload & Import</button>
            </form>
        </div>

        <div id="panelHapusMassal" class="bulk-delete-bar">
            <div class="bulk-delete-info">
                <label class="select-all-toggle" title="Pilih atau batalkan semua siswa yang tampil">
                    <input type="checkbox" id="togglePilihSemua" role="switch">
                    <span class="toggle-slider"></span>
                    <span class="toggle-label">Pilih Semua</span>
                </label>
                <span class="bulk-selected-text"><span id="jumlahDipilih">0</span> data terpilih.</span>
            </div>
            <div class="bulk-delete-actions">
                <button type="button" class="btn-secondary" id="btnBatalHapusMassal">Batal</button>
                <button type="button" class="btn-danger bulk" id="btnEksekusiHapusMassal">🗑️ Hapus Data Terpilih</button>
            </div>
        </div>

        <script>
        document.getElementById('btnToggleFoto').addEventListener('click', function(){
            var panel = document.getElementById('panelFoto');
            panel.style.display = (panel.style.display === 'none' || !panel.style.display) ? 'block' : 'none';
        });
        document.getElementById('btnToggleImport').addEventListener('click', function(){
            var panel = document.getElementById('panelImport');
            panel.style.display = (panel.style.display === 'none' || !panel.style.display) ? 'block' : 'none';
        });

        (function(){
            var toggle = document.getElementById('btnToggleHapusMassal');
            var panel = document.getElementById('panelHapusMassal');
            var checkAll = document.getElementById('checkAllSiswa');
            var togglePilihSemua = document.getElementById('togglePilihSemua');
            var countEl = document.getElementById('jumlahDipilih');
            var btnHapus = document.getElementById('btnEksekusiHapusMassal');
            var btnBatal = document.getElementById('btnBatalHapusMassal');

            function checks() {
                return Array.prototype.slice.call(document.querySelectorAll('.siswa-check'));
            }

            function updateBulkUI() {
                var selected = checks().filter(function(c){ return c.checked; });
                countEl.textContent = selected.length;
                panel.classList.toggle('active', panel.dataset.enabled === '1');
                if (checkAll) {
                    var all = checks();
                    checkAll.checked = all.length > 0 && selected.length === all.length;
                    checkAll.indeterminate = selected.length > 0 && selected.length < all.length;
                }
                if (togglePilihSemua) {
                    var allToggle = checks();
                    togglePilihSemua.checked = allToggle.length > 0 && selected.length === allToggle.length;
                    togglePilihSemua.indeterminate = selected.length > 0 && selected.length < allToggle.length;
                }
            }

            toggle.addEventListener('click', function(){
                var open = panel.dataset.enabled === '1';
                panel.dataset.enabled = open ? '0' : '1';
                panel.classList.toggle('active', !open);
                if (!open) window.scrollTo({top: panel.getBoundingClientRect().top + window.pageYOffset - 100, behavior:'smooth'});
            });

            if (togglePilihSemua) {
                togglePilihSemua.addEventListener('change', function(){
                    if (panel.dataset.enabled !== '1') {
                        panel.dataset.enabled = '1';
                        panel.classList.add('active');
                    }
                    checks().forEach(function(c){ c.checked = togglePilihSemua.checked; });
                    if (checkAll) {
                        checkAll.checked = togglePilihSemua.checked;
                        checkAll.indeterminate = false;
                    }
                    updateBulkUI();
                });
            }

            if (checkAll) {
                checkAll.addEventListener('change', function(){
                    if (panel.dataset.enabled !== '1') {
                        panel.dataset.enabled = '1';
                        panel.classList.add('active');
                    }
                    checks().forEach(function(c){ c.checked = checkAll.checked; });
                    updateBulkUI();
                });
            }

            document.addEventListener('change', function(e){
                if (e.target.classList && e.target.classList.contains('siswa-check')) {
                    if (panel.dataset.enabled !== '1') {
                        panel.dataset.enabled = '1';
                        panel.classList.add('active');
                    }
                    updateBulkUI();
                }
            });

            btnBatal.addEventListener('click', function(){
                checks().forEach(function(c){ c.checked = false; });
                if (checkAll) { checkAll.checked = false; checkAll.indeterminate = false; }
                if (togglePilihSemua) { togglePilihSemua.checked = false; togglePilihSemua.indeterminate = false; }
                panel.dataset.enabled = '0';
                panel.classList.remove('active');
                updateBulkUI();
            });

            btnHapus.addEventListener('click', function(){
                var selected = checks().filter(function(c){ return c.checked; });
                if (!selected.length) {
                    alert('Silakan pilih minimal satu siswa yang akan dihapus.');
                    return;
                }

                var nama = selected.slice(0, 5).map(function(c){
                    var tr = c.closest('tr');
                    var el = tr ? tr.querySelector('.nama-siswa') : null;
                    return el ? el.textContent.trim() : '';
                }).filter(Boolean);

                var teks = 'Yakin ingin menghapus ' + selected.length + ' data siswa?\n\n';
                if (nama.length) teks += nama.join('\n') + (selected.length > 5 ? '\n... dan lainnya' : '') + '\n\n';
                teks += 'Data yang dihapus tidak dapat dikembalikan.';
                if (!confirm(teks)) return;

                var form = document.createElement('form');
                form.method = 'post';
                form.action = 'index.php';

                var aksi = document.createElement('input');
                aksi.type = 'hidden';
                aksi.name = 'aksi';
                aksi.value = 'hapus_massal';
                form.appendChild(aksi);

                selected.forEach(function(c){
                    var input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = 'id_siswa_massal[]';
                    input.value = c.value;
                    form.appendChild(input);
                });

                document.body.appendChild(form);
                form.submit();
            });

            updateBulkUI();
        })();
        </script>

        <?php if ($pesan !== ''): ?>
            <div class="alert <?= $tipe_pesan === 'success' ? 'alert-success' : 'alert-error'; ?>">
                <?= htmlspecialchars($pesan); ?>
            </div>
        <?php endif; ?>

        <?php if ($mode_edit || isset($_GET['tambah'])): ?>
            <div class="form-card">
                <h2 class="form-title">
                    <?= $mode_edit ? 'Edit Data Siswa' : 'Tambah Siswa Baru'; ?>
                </h2>
                <p class="form-subtitle">
                    Isi data utama siswa. Data dapat dilengkapi kembali melalui Buku Induk.
                </p>

                <form method="post" action="index.php">
                    <input type="hidden" name="aksi" value="simpan">
                    <input type="hidden" name="id_siswa" value="<?= (int)$data_edit['id_siswa']; ?>">

                    <div class="form-grid">

                        <div class="form-group">
                            <label class="form-label">NIS</label>
                            <input type="text" name="nis" class="form-control"
                                   value="<?= htmlspecialchars($data_edit['nis'] ?? ''); ?>">
                        </div>

                        <div class="form-group">
                            <label class="form-label">NISN</label>
                            <input type="text" name="nisn" class="form-control"
                                   value="<?= htmlspecialchars($data_edit['nisn'] ?? ''); ?>">
                        </div>

                        <div class="form-group">
                            <label class="form-label">NIK</label>
                            <input type="text" name="nik" class="form-control"
                                   value="<?= htmlspecialchars($data_edit['nik'] ?? ''); ?>">
                        </div>

                        <div class="form-group full">
                            <label class="form-label">Nama Siswa *</label>
                            <input type="text" name="nama_siswa" class="form-control" required
                                   value="<?= htmlspecialchars($data_edit['nama_siswa'] ?? ''); ?>">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Jenis Kelamin *</label>
                            <select name="jenis_kelamin" class="form-control" required>
                                <option value="L" <?= ($data_edit['jenis_kelamin'] ?? '') === 'L' ? 'selected' : ''; ?>>Laki-laki</option>
                                <option value="P" <?= ($data_edit['jenis_kelamin'] ?? '') === 'P' ? 'selected' : ''; ?>>Perempuan</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Tempat Lahir</label>
                            <input type="text" name="tempat_lahir" class="form-control"
                                   value="<?= htmlspecialchars($data_edit['tempat_lahir'] ?? ''); ?>">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Tanggal Lahir</label>
                            <input type="date" name="tanggal_lahir" class="form-control"
                                   value="<?= htmlspecialchars($data_edit['tanggal_lahir'] ?? ''); ?>">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Agama</label>
                            <select name="agama" class="form-control">
                                <?php
                                $agama_list = ['Islam', 'Kristen', 'Katolik', 'Hindu', 'Buddha', 'Khonghucu'];
                                $agama_sekarang = $data_edit['agama'] ?? '';
                                ?>
                                <option value="">Pilih agama</option>
                                <?php foreach ($agama_list as $agama): ?>
                                    <option value="<?= htmlspecialchars($agama); ?>" <?= $agama_sekarang === $agama ? 'selected' : ''; ?>>
                                        <?= htmlspecialchars($agama); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Kelas</label>
                            <select name="id_kelas" class="form-control">
                                <option value="0">Belum ditentukan</option>
                                <?php foreach ($daftar_kelas as $kelas): ?>
                                    <option value="<?= (int)$kelas['id_kelas']; ?>"
                                        <?= (int)($data_edit['id_kelas'] ?? 0) === (int)$kelas['id_kelas'] ? 'selected' : ''; ?>>
                                        Kelas <?= htmlspecialchars($kelas['nama_kelas']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Status Siswa</label>
                            <?php $status_sekarang = $data_edit['status_siswa'] ?? 'Aktif'; ?>
                            <select name="status_siswa" class="form-control">
                                <?php foreach (['Aktif', 'Lulus', 'Pindah', 'Tidak Aktif'] as $status): ?>
                                    <option value="<?= htmlspecialchars($status); ?>" <?= $status_sekarang === $status ? 'selected' : ''; ?>>
                                        <?= htmlspecialchars($status); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group full">
                            <label class="form-label">Alamat</label>
                            <textarea name="alamat" class="form-control"><?= htmlspecialchars($data_edit['alamat'] ?? ''); ?></textarea>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Nama Ayah</label>
                            <input type="text" name="nama_ayah" class="form-control"
                                   value="<?= htmlspecialchars($data_edit['nama_ayah'] ?? ''); ?>">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Nama Ibu</label>
                            <input type="text" name="nama_ibu" class="form-control"
                                   value="<?= htmlspecialchars($data_edit['nama_ibu'] ?? ''); ?>">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Nama Wali</label>
                            <input type="text" name="nama_wali" class="form-control"
                                   value="<?= htmlspecialchars($data_edit['nama_wali'] ?? ''); ?>">
                        </div>

                        <div class="form-group">
                            <label class="form-label">No. KK</label>
                            <input type="text" name="no_kk" class="form-control"
                                   value="<?= htmlspecialchars($data_edit['no_kk'] ?? ''); ?>">
                        </div>

                        <div class="form-group">
                            <label class="form-label">No. Akta</label>
                            <input type="text" name="no_akta" class="form-control"
                                   value="<?= htmlspecialchars($data_edit['no_akta'] ?? ''); ?>">
                        </div>

                        <div class="form-group">
                            <label class="form-label">No. KIP</label>
                            <input type="text" name="no_kip" class="form-control"
                                   value="<?= htmlspecialchars($data_edit['no_kip'] ?? ''); ?>">
                        </div>

                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn-primary">
                            💾 <?= $mode_edit ? 'Simpan Perubahan' : 'Simpan Siswa'; ?>
                        </button>

                        <a href="index.php" class="btn-secondary">Batal</a>
                    </div>
                </form>
            </div>
        <?php endif; ?>

        <div class="data-panel">
            <div class="toolbar">
                <form method="get" class="search-form">
                    <input type="text" name="cari"
                           value="<?= htmlspecialchars($cari); ?>"
                           placeholder="Cari nama, NIS, atau NISN...">
                    <button type="submit" class="btn-primary">🔎 Cari</button>
                </form>

                <div class="data-count">
                    Menampilkan <strong><?= $jumlah_data; ?></strong> siswa
                </div>
            </div>

            <div class="table-wrap">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th class="select-col"><input type="checkbox" id="checkAllSiswa" title="Pilih semua siswa"></th>
                            <th>No</th>
                            <th>Foto</th>
                            <th>NIS / NISN</th>
                            <th>Nama Siswa</th>
                            <th>JK</th>
                            <th>Kelas</th>
                            <th>Wali Kelas</th>
                            <th>Tahun Ajaran</th>
                            <th>Status</th>
                            <th width="150">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($q_siswa && mysqli_num_rows($q_siswa) > 0): ?>
                            <?php $no = 1; ?>
                            <?php while ($siswa = mysqli_fetch_assoc($q_siswa)): ?>
                                <tr>
                                    <td class="select-col">
                                        <input type="checkbox" class="siswa-check" name="siswa_pilih[]" value="<?= (int)$siswa['id_siswa']; ?>" aria-label="Pilih <?= htmlspecialchars($siswa['nama_siswa']); ?>">
                                    </td>
                                    <td><?= $no++; ?></td>
                                    <td>
                                        <?php $foto_thumb = cek_foto_siswa_ada($siswa['id_siswa']); ?>
                                        <?php if ($foto_thumb): ?>
                                            <img src="<?= htmlspecialchars($foto_thumb); ?>" alt="Foto" style="width:36px;height:36px;border-radius:50%;object-fit:cover;display:block;">
                                        <?php else: ?>
                                            <span style="width:36px;height:36px;border-radius:50%;background:#eef2f7;color:#94a3b8;display:flex;align-items:center;justify-content:center;font-size:16px;">👤</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?= htmlspecialchars($siswa['nis'] ?: '-'); ?>
                                        <div class="sub-text">
                                            NISN: <?= htmlspecialchars($siswa['nisn'] ?: '-'); ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="nama-siswa">
                                            <?= htmlspecialchars($siswa['nama_siswa']); ?>
                                        </div>
                                    </td>
                                    <td><?= $siswa['jenis_kelamin'] === 'L' ? 'L' : 'P'; ?></td>
                                    <td><?= htmlspecialchars($siswa['nama_kelas'] ?: 'Belum ditentukan'); ?></td>
                                    <td>
                                        <strong><?= htmlspecialchars($siswa['nama_wali_kelas'] ?: 'Belum ditentukan'); ?></strong>
                                    </td>
                                    <td><?= htmlspecialchars(($siswa['tahun_ajaran'] ?? '') ? (($siswa['tahun_ajaran'] ?? '') . ' - ' . ($siswa['semester'] ?? '')) : '-'); ?></td>
                                    <td>
                                        <span class="badge <?= $siswa['status_siswa'] === 'Aktif' ? 'badge-aktif' : 'badge-lain'; ?>">
                                            <?= htmlspecialchars($siswa['status_siswa']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="aksi">
                                            <a href="index.php?edit=<?= (int)$siswa['id_siswa']; ?>" class="btn-secondary">
                                                ✏️
                                            </a>

                                            <form method="post" action="index.php" enctype="multipart/form-data" style="display:inline;">
                                                <input type="hidden" name="aksi" value="upload_foto_satu">
                                                <input type="hidden" name="id_siswa" value="<?= (int)$siswa['id_siswa']; ?>">
                                                <input type="file" name="foto_satu" accept=".jpg,.jpeg,.png,.webp" style="display:none;" onchange="this.form.submit()">
                                                <button type="button" class="btn-secondary" title="Upload Foto" onclick="this.previousElementSibling.click()">📷</button>
                                            </form>

                                            <form method="post" action="index.php"
                                                  onsubmit="return confirm('Hapus data siswa ini?');">
                                                <input type="hidden" name="aksi" value="hapus">
                                                <input type="hidden" name="id_siswa" value="<?= (int)$siswa['id_siswa']; ?>">
                                                <button type="submit" class="btn-danger">🗑️</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="9" style="text-align:center; padding:45px 15px; color:#94a3b8;">
                                    Belum ada data siswa.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</main>

</body>
</html>
