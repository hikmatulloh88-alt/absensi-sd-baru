<?php
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin');
require_once "../../config/database.php";
require_once "../../config/theme.php";

$menu_aktif = 'pengaturan';
$page_title = 'Pengaturan & Profil Sekolah - SDN Ciburayut 01';
function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

/* Ambil struktur tabel sekolah agar kompatibel dengan database lama. */
$fields = [];
$qf = mysqli_query($koneksi, "SHOW COLUMNS FROM sekolah");
if ($qf) while ($r = mysqli_fetch_assoc($qf)) $fields[] = $r['Field'];
$has = fn($f) => in_array($f, $fields, true);

/* Pastikan minimal ada satu data profil. */
$cek = mysqli_query($koneksi, "SELECT * FROM sekolah ORDER BY id_sekolah ASC LIMIT 1");
$sekolah = $cek ? mysqli_fetch_assoc($cek) : null;
if (!$sekolah) {
    $insertCols = []; $insertVals = [];
    $defaults = ['nama_sekolah'=>'SDN CIBURAYUT 01','desa'=>'Ciburayut','kecamatan'=>'Cigombong','kabupaten'=>'Bogor','provinsi'=>'Jawa Barat'];
    foreach($defaults as $f=>$v) if($has($f)){ $insertCols[]=$f; $insertVals[]="'".mysqli_real_escape_string($koneksi,$v)."'"; }
    if ($insertCols) {
        mysqli_query($koneksi, "INSERT INTO sekolah (".implode(',',$insertCols).") VALUES (".implode(',',$insertVals).")");
        $cek = mysqli_query($koneksi, "SELECT * FROM sekolah ORDER BY id_sekolah ASC LIMIT 1");
        $sekolah = $cek ? mysqli_fetch_assoc($cek) : null;
    }
}

$id = (int)($sekolah['id_sekolah'] ?? 0);
$pesan = ''; $error = '';

/* SIMPAN PROFIL SEKOLAH */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form_type'] ?? '') === 'profil' && $id > 0) {
    $nama_sekolah = trim($_POST['nama_sekolah'] ?? '');
    if ($nama_sekolah === '') {
        $error = 'Nama sekolah wajib diisi.';
    } else {
        $data = [];
        $map = [
            'nama_sekolah'=>'Nama Sekolah','npsn'=>'NPSN','alamat'=>'Alamat','desa'=>'Desa/Kelurahan',
            'kecamatan'=>'Kecamatan','kabupaten'=>'Kabupaten','provinsi'=>'Provinsi','kode_pos'=>'Kode Pos',
            'kepala_sekolah'=>'Kepala Sekolah','nip_kepala_sekolah'=>'NIP Kepala Sekolah'
        ];
        foreach ($map as $field=>$label) if ($has($field)) $data[$field] = trim($_POST[$field] ?? '');

        if (isset($_FILES['logo']) && $_FILES['logo']['error'] !== UPLOAD_ERR_NO_FILE && $has('logo')) {
            $file = $_FILES['logo'];
            $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
            $mime = function_exists('mime_content_type') ? mime_content_type($file['tmp_name']) : '';
            if (!isset($allowed[$mime])) $error = 'Logo harus berformat JPG, PNG, atau WEBP.';
            elseif ($file['size'] > 2 * 1024 * 1024) $error = 'Ukuran logo maksimal 2 MB.';
            else {
                $uploadDir = __DIR__ . '/../../uploads/sekolah';
                if (!is_dir($uploadDir)) @mkdir($uploadDir, 0777, true);
                if (!is_dir($uploadDir)) $error = 'Folder upload logo tidak dapat dibuat.';
                else {
                    $filename = 'logo_sekolah_' . $id . '_' . time() . '.' . $allowed[$mime];
                    if (!move_uploaded_file($file['tmp_name'], $uploadDir . '/' . $filename)) $error = 'Logo gagal disimpan.';
                    else $data['logo'] = 'uploads/sekolah/' . $filename;
                }
            }
        }

        if (!$error && $data) {
            $sets=[]; $vals=[];
            foreach($data as $field=>$value){ $sets[]="`$field`=?"; $vals[]=$value; }
            $stmt=mysqli_prepare($koneksi,"UPDATE sekolah SET ".implode(',',$sets)." WHERE id_sekolah=?");
            if($stmt){
                $types=str_repeat('s',count($vals)).'i'; $vals[]=$id;
                mysqli_stmt_bind_param($stmt,$types,...$vals);
                if(mysqli_stmt_execute($stmt)){
                    $pesan='Profil sekolah berhasil disimpan.';
                    $cek=mysqli_query($koneksi,"SELECT * FROM sekolah WHERE id_sekolah=$id LIMIT 1");
                    $sekolah=$cek?mysqli_fetch_assoc($cek):$sekolah;
                } else $error='Gagal menyimpan profil sekolah: '.mysqli_error($koneksi);
                mysqli_stmt_close($stmt);
            } else $error='Query pembaruan profil gagal dibuat.';
        }
    }
}

/* SIMPAN TEMA */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form_type'] ?? '') === 'tema') {
    $tema = trim($_POST['theme_name'] ?? 'navy');
    $available = tema_tersedia();
    if (!isset($available[$tema]) && $tema !== 'custom') $tema = 'navy';

    if (isset($_FILES['theme_css']) && $_FILES['theme_css']['error'] !== UPLOAD_ERR_NO_FILE) {
        $file = $_FILES['theme_css'];
        $ext = strtolower(pathinfo($file['name'] ?? '', PATHINFO_EXTENSION));
        $contents = @file_get_contents($file['tmp_name']);
        if ($ext !== 'css') $error = 'File tema harus berformat .CSS.';
        elseif ($file['size'] > 1024 * 1024) $error = 'Ukuran file tema maksimal 1 MB.';
        elseif ($contents === false || trim($contents) === '') $error = 'File tema kosong atau tidak dapat dibaca.';
        elseif (preg_match('/<\/?script\b|javascript\s*:/i', $contents)) $error = 'File tema ditolak karena mengandung konten yang tidak diizinkan.';
        else {
            $uploadDir = __DIR__ . '/../../uploads/themes';
            if (!is_dir($uploadDir)) @mkdir($uploadDir, 0777, true);
            if (!is_dir($uploadDir)) $error = 'Folder upload tema tidak dapat dibuat.';
            else {
                $filename = 'custom_theme_' . $id . '_' . time() . '.css';
                if (!file_put_contents($uploadDir . '/' . $filename, $contents)) $error = 'File tema gagal disimpan.';
                else {
                    $path = 'uploads/themes/' . $filename;
                    $stmt = mysqli_prepare($koneksi, "UPDATE app_theme_settings SET theme_name='custom', custom_css=? WHERE id=1");
                    if($stmt){ mysqli_stmt_bind_param($stmt,'s',$path); mysqli_stmt_execute($stmt); mysqli_stmt_close($stmt); $pesan='Tema kustom berhasil diunggah dan diterapkan.'; }
                    else $error='Pengaturan tema gagal disimpan.';
                }
            }
        }
    } elseif (!$error) {
        if ($tema === 'custom') {
            $custom = tema_custom_css($koneksi);
            if ($custom === '') { $error = 'Belum ada tema kustom. Unggah file CSS terlebih dahulu.'; }
            else $tema = 'custom';
        }
        if (!$error) {
            $stmt = mysqli_prepare($koneksi, "UPDATE app_theme_settings SET theme_name=?, custom_css=CASE WHEN ?='custom' THEN custom_css ELSE NULL END WHERE id=1");
            if($stmt){ mysqli_stmt_bind_param($stmt,'ss',$tema,$tema); mysqli_stmt_execute($stmt); mysqli_stmt_close($stmt); $pesan='Tema aplikasi berhasil diganti.'; }
            else $error='Pengaturan tema gagal disimpan.';
        }
    }
}

$theme_name = tema_setting($koneksi);
$theme_custom = tema_custom_css($koneksi);
$logoWeb = !empty($sekolah['logo']) ? '../../' . ltrim($sekolah['logo'], '/') : '';
require_once '../../includes/header.php';
require_once '../../includes/sidebar.php';
?>

<main class="main-content">
<div class="pengaturan-inner">
    <div style="margin-bottom:20px;">
        <h1 style="margin:0 0 6px;font-size:28px;">Pengaturan & Profil Sekolah</h1>
        <div style="color:#64748b;">Kelola identitas sekolah, logo, dan tampilan aplikasi yang digunakan pada laporan, rapor, buku induk, dan dokumen cetak.</div>
    </div>

    <?php if($pesan): ?><div style="background:#ecfdf5;border:1px solid #a7f3d0;color:#065f46;padding:12px 14px;border-radius:12px;margin-bottom:16px;">✅ <?=h($pesan)?></div><?php endif; ?>
    <?php if($error): ?><div style="background:#fef2f2;border:1px solid #fecaca;color:#991b1b;padding:12px 14px;border-radius:12px;margin-bottom:16px;">⚠️ <?=h($error)?></div><?php endif; ?>

    <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="form_type" value="profil">
        <div style="display:grid;grid-template-columns:minmax(0,1.7fr) minmax(280px,.9fr);gap:20px;align-items:start;">
            <div class="card" style="padding:22px;">
                <h3 style="margin-top:0;">Identitas Sekolah</h3>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
                <?php $inputs=['nama_sekolah'=>'Nama Sekolah','npsn'=>'NPSN','alamat'=>'Alamat','desa'=>'Desa/Kelurahan','kecamatan'=>'Kecamatan','kabupaten'=>'Kabupaten','provinsi'=>'Provinsi','kode_pos'=>'Kode Pos','kepala_sekolah'=>'Kepala Sekolah','nip_kepala_sekolah'=>'NIP Kepala Sekolah']; foreach($inputs as $f=>$label): if(!$has($f)) continue; ?>
                    <div style="grid-column:<?=in_array($f,['alamat'])?'1 / -1':'auto'?>;">
                        <label style="display:block;font-weight:700;margin-bottom:7px;"><?=h($label)?></label>
                        <?php if($f==='alamat'): ?><textarea name="<?=$f?>" rows="3" style="width:100%;box-sizing:border-box;padding:11px 12px;border:1px solid #dbe3ef;border-radius:10px;"><?=h($sekolah[$f]??'')?></textarea>
                        <?php else: ?><input type="text" name="<?=$f?>" value="<?=h($sekolah[$f]??'')?>" style="width:100%;box-sizing:border-box;padding:11px 12px;border:1px solid #dbe3ef;border-radius:10px;"><?php endif; ?>
                    </div>
                <?php endforeach; ?>
                </div>
                <div style="margin-top:20px;display:flex;justify-content:flex-end;"><button type="submit" style="border:0;background:#0f172a;color:#fff;padding:11px 20px;border-radius:10px;font-weight:700;cursor:pointer;">💾 Simpan Profil Sekolah</button></div>
            </div>
            <div class="card" style="padding:22px;">
                <h3 style="margin-top:0;">Logo Sekolah</h3>
                <div style="border:1px dashed #cbd5e1;border-radius:14px;padding:18px;text-align:center;background:#f8fafc;">
                    <?php if($logoWeb): ?><img src="<?=h($logoWeb)?>" alt="Logo Sekolah" style="max-width:160px;max-height:160px;object-fit:contain;margin-bottom:12px;">
                    <?php else: ?><div style="font-size:56px;margin-bottom:8px;">🏫</div><div style="color:#64748b;margin-bottom:12px;">Belum ada logo</div><?php endif; ?>
                    <?php if($has('logo')): ?><input type="file" name="logo" accept="image/png,image/jpeg,image/webp" style="width:100%;"><div style="font-size:12px;color:#64748b;margin-top:8px;">JPG/PNG/WEBP, maksimal 2 MB.</div><?php endif; ?>
                </div>
            </div>
        </div>
    </form>

    <section class="card theme-panel" style="padding:22px;">
        <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
            <div><h3 style="margin:0 0 5px;">🎨 Ganti Tema Aplikasi</h3><div style="color:#64748b;font-size:13px;">Pilih tema bawaan atau unggah tema CSS buatan sendiri. Tema akan diterapkan ke seluruh halaman aplikasi.</div></div>
            <div style="font-size:12px;padding:7px 10px;border-radius:999px;background:#eef2ff;color:#4338ca;font-weight:700;">Aktif: <?=h($theme_name==='custom'?'Tema Kustom':(tema_tersedia()[$theme_name]['label']??$theme_name))?></div>
        </div>

        <form method="post" enctype="multipart/form-data" style="margin-top:18px;">
            <input type="hidden" name="form_type" value="tema">
            <div class="theme-grid">
            <?php $swatches=['navy'=>['#102a56','#1265dc'],'emerald'=>['#064e3b','#059669'],'purple'=>['#3b176d','#6d28d9'],'sunset'=>['#7c2d12','#ea580c'],'slate'=>['#1e293b','#475569']]; foreach(tema_tersedia() as $key=>$info): ?>
                <div class="theme-option"><input type="radio" name="theme_name" id="theme_<?=$key?>" value="<?=$key?>" <?=$theme_name===$key?'checked':''?>><label for="theme_<?=$key?>"><div class="theme-swatch" style="--sw1:<?=$swatches[$key][0]?>;--sw2:<?=$swatches[$key][1]?>"></div><div class="theme-name"><?=$info['icon']?> <?=h($info['label'])?></div></label></div>
            <?php endforeach; ?>
            <div class="theme-option"><input type="radio" name="theme_name" id="theme_custom" value="custom" <?=$theme_name==='custom'?'checked':''?>><label for="theme_custom"><div class="theme-swatch" style="--sw1:#0f172a;--sw2:#e2e8f0"></div><div class="theme-name">🧩 Tema Kustom</div></label></div>
            </div>

            <div class="theme-upload" style="margin-top:16px;">
                <div style="font-weight:800;margin-bottom:5px;">Upload Tema Sendiri</div>
                <input type="file" name="theme_css" accept=".css,text/css" style="max-width:100%;">
                <div class="theme-help">Gunakan file <strong>.css</strong> maksimal 1 MB. Untuk membuat tema, cukup ubah variabel <code>--theme-primary</code>, <code>--theme-sidebar-1</code>, <code>--theme-sidebar-2</code>, <code>--theme-sidebar-3</code>, dan <code>--theme-page</code>. Setelah diunggah, pilih “Tema Kustom” atau tema kustom akan langsung diterapkan.</div>
                <?php if($theme_custom): ?><div style="margin-top:9px;font-size:12px;color:#475569;">📄 File tema kustom sudah tersedia: <strong><?=h(basename($theme_custom))?></strong></div><?php endif; ?>
            </div>
            <div style="margin-top:16px;display:flex;justify-content:flex-end;"><button type="submit" style="border:0;background:var(--theme-primary-2);color:#fff;padding:11px 20px;border-radius:10px;font-weight:800;cursor:pointer;">🎨 Simpan & Terapkan Tema</button></div>
        </form>
    </section>
</div>
</main>

<style>
@media (max-width:900px){ .main-content form > div{grid-template-columns:1fr !important;} }
</style>
</body>
</html>
