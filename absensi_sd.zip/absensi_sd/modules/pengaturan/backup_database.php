<?php
session_start();

if (empty($_SESSION['user_id'])) {
    header("Location: /absensi_sd/login.php");
    exit;
}

// Hanya Admin yang boleh melakukan backup database.
if (strtolower($_SESSION['role'] ?? '') !== 'admin') {
    http_response_code(403);
    die("Akses ditolak. Backup database hanya dapat dilakukan oleh Admin.");
}

require_once __DIR__ . "/../../config/database.php";

$database = "absensi_sd";
$filename = $database . "_backup_" . date("Y-m-d_H-i-s") . ".sql";

header("Content-Type: application/sql; charset=utf-8");
header("Content-Disposition: attachment; filename=\"" . $filename . "\"");
header("Pragma: no-cache");
header("Expires: 0");

function q($value) {
    return "'" . str_replace(["\\", "'"], ["\\\\", "\\'"], $value) . "'";
}

echo "-- Backup Database: " . $database . PHP_EOL;
echo "-- Tanggal: " . date("Y-m-d H:i:s") . PHP_EOL;
echo "-- Dibuat oleh Aplikasi Absensi SDN Ciburayut 01" . PHP_EOL;
echo "-- ----------------------------------------" . PHP_EOL . PHP_EOL;

$tables_result = mysqli_query($koneksi, "SHOW TABLES");
if (!$tables_result) {
    die("-- Gagal membaca daftar tabel: " . mysqli_error($koneksi));
}

while ($row = mysqli_fetch_row($tables_result)) {
    $table = $row[0];

    $create_result = mysqli_query($koneksi, "SHOW CREATE TABLE `$table`");
    if (!$create_result) {
        continue;
    }

    $create = mysqli_fetch_assoc($create_result);
    $create_sql = $create['Create Table'] ?? '';

    echo "-- Table: `$table`" . PHP_EOL;
    echo "DROP TABLE IF EXISTS `$table`;" . PHP_EOL;
    echo $create_sql . ";" . PHP_EOL . PHP_EOL;

    $data_result = mysqli_query($koneksi, "SELECT * FROM `$table`");
    if ($data_result && mysqli_num_rows($data_result) > 0) {
        $fields = mysqli_num_fields($data_result);
        $field_names = [];

        while ($field = mysqli_fetch_field($data_result)) {
            $field_names[] = "`" . str_replace("`", "``", $field->name) . "`";
        }

        while ($data = mysqli_fetch_row($data_result)) {
            $values = [];

            foreach ($data as $value) {
                if ($value === null) {
                    $values[] = "NULL";
                } else {
                    $values[] = q($value);
                }
            }

            echo "INSERT INTO `$table` (" . implode(", ", $field_names) . ") VALUES (" . implode(", ", $values) . ");" . PHP_EOL;
        }

        echo PHP_EOL;
    }
}

echo "-- Selesai." . PHP_EOL;
exit;
?>
