<?php
require_once "../../config/auth.php";
wajib_login();
wajib_role('Admin', 'Operator', 'Guru');
require_once "../../config/database.php";

$menu_aktif = 'mapel';
$page_title = 'Mata Pelajaran - Absensi SDN Ciburayut 01';

$pesan = '';
$tipe_pesan = '';
$mode_edit = false;

/* Sinkronkan master mata pelajaran dengan tabel PRESTASI BELAJAR pada template Buku Induk.
 * Urutan/nama mengikuti PDF sumber: PPKN, Pendidikan Agama, Bahasa Indonesia,
 * Matematika, IPA, IPS, Seni Budaya, Penjaskes, Bahasa Inggris, B. Daerah.
 */
$mapel_buku_induk = [
    ['PPKN','PPKN','UMUM'],
    ['Pendidikan Agama','AGAMA','UMUM'],
    ['Bahasa Indonesia','BIN','UMUM'],
    ['Matematika','MTK','UMUM'],
    ['Ilmu Pengetahuan Alam','IPA','UMUM'],
    ['Ilmu Pengetahuan Sosial','IPS','UMUM'],
    ['Seni Budaya','SB','UMUM'],
    ['Penjaskes','PJOK','UMUM'],
    ['Bahasa Inggris','BING','UMUM'],
    ['B. Daerah','BDA','MUATAN LOKAL']
];

/* Jalankan otomatis agar halaman langsung sesuai template Buku Induk. */
foreach ($mapel_buku_induk as $m) {
    $nama_m = $m[0]; $kode_m = $m[1]; $kel_m = $m[2];
    $st_sync = mysqli_prepare($koneksi, "SELECT id_mapel FROM mata_pelajaran WHERE nama_mapel=? LIMIT 1");
    if ($st_sync) {
        mysqli_stmt_bind_param($st_sync, 's', $nama_m);
        mysqli_stmt_execute($st_sync);
        $rr_sync = mysqli_stmt_get_result($st_sync);
        $ada_sync = $rr_sync ? mysqli_fetch_assoc($rr_sync) : null;
        if (!$ada_sync) {
            $ins_sync = mysqli_prepare($koneksi, "INSERT INTO mata_pelajaran (kode_mapel,nama_mapel,kelompok,status) VALUES (?,?,?,'Aktif')");
            if ($ins_sync) {
                mysqli_stmt_bind_param($ins_sync, 'sss', $kode_m, $nama_m, $kel_m);
                mysqli_stmt_execute($ins_sync);
            }
        }
    }
}


$data_edit = [
    'id_mapel' => '',
    'kode_mapel' => '',
    'nama_mapel' => '',
    'kelompok' => '',
    'status' => 'Aktif'
];

function h($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function clean($v) {
    $v = trim((string)$v);
    return $v === '' ? null : $v;
}

/* SIMPAN / UPDATE */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? '';

    if ($aksi === 'simpan') {
        $id_mapel = (int)($_POST['id_mapel'] ?? 0);
        $kode     = clean($_POST['kode_mapel'] ?? '');
        $nama     = trim($_POST['nama_mapel'] ?? '');
        $kelompok = clean($_POST['kelompok'] ?? '');
        $status   = $_POST['status'] ?? 'Aktif';

        if ($nama === '') {
            $pesan = 'Nama mata pelajaran wajib diisi.';
            $tipe_pesan = 'error';
        } elseif (!in_array($status, ['Aktif', 'Tidak Aktif'], true)) {
            $pesan = 'Status mata pelajaran tidak valid.';
            $tipe_pesan = 'error';
        } else {
            if ($id_mapel > 0) {
                $sql = "UPDATE mata_pelajaran
                        SET kode_mapel = ?, nama_mapel = ?, kelompok = ?, status = ?
                        WHERE id_mapel = ?";
                $stmt = mysqli_prepare($koneksi, $sql);

                if ($stmt) {
                    mysqli_stmt_bind_param(
                        $stmt,
                        "ssssi",
                        $kode, $nama, $kelompok, $status, $id_mapel
                    );
                }
            } else {
                $sql = "INSERT INTO mata_pelajaran
                        (kode_mapel, nama_mapel, kelompok, status)
                        VALUES (?, ?, ?, ?)";
                $stmt = mysqli_prepare($koneksi, $sql);

                if ($stmt) {
                    mysqli_stmt_bind_param(
                        $stmt,
                        "ssss",
                        $kode, $nama, $kelompok, $status
                    );
                }
            }

            if (!empty($stmt) && mysqli_stmt_execute($stmt)) {
                header("Location: index.php?sukses=1");
                exit;
            }

            $pesan = 'Data mata pelajaran gagal disimpan: ' . mysqli_error($koneksi);
            $tipe_pesan = 'error';
        }
    }

    if ($aksi === 'hapus') {
        $id_hapus = (int)($_POST['id_mapel'] ?? 0);

        if ($id_hapus > 0) {
            $stmt = mysqli_prepare($koneksi, "DELETE FROM mata_pelajaran WHERE id_mapel = ?");

            if ($stmt) {
                mysqli_stmt_bind_param($stmt, "i", $id_hapus);

                if (mysqli_stmt_execute($stmt)) {
                    header("Location: index.php?hapus=1");
                    exit;
                }
            }

            $pesan = 'Mata pelajaran tidak dapat dihapus: ' . mysqli_error($koneksi);
            $tipe_pesan = 'error';
        }
    }
}

if (isset($_GET['sukses'])) {
    $pesan = 'Mata pelajaran berhasil disimpan.';
    $tipe_pesan = 'success';
}

if (isset($_GET['hapus'])) {
    $pesan = 'Mata pelajaran berhasil dihapus.';
    $tipe_pesan = 'success';
}

/* EDIT */
if (isset($_GET['edit'])) {
    $id_edit = (int)$_GET['edit'];

    if ($id_edit > 0) {
        $stmt = mysqli_prepare($koneksi, "SELECT id_mapel, kode_mapel, nama_mapel, kelompok, status FROM mata_pelajaran WHERE id_mapel = ?");

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "i", $id_edit);
            mysqli_stmt_execute($stmt);
            $hasil = mysqli_stmt_get_result($stmt);

            if ($hasil && mysqli_num_rows($hasil) === 1) {
                $data_edit = mysqli_fetch_assoc($hasil);
                $mode_edit = true;
            }
        }
    }
}

/* DATA MATA PELAJARAN */
$q_mapel = mysqli_query(
    $koneksi,
    "SELECT id_mapel, kode_mapel, nama_mapel, kelompok, status
     FROM mata_pelajaran
     ORDER BY nama_mapel ASC"
);

$jumlah_mapel = $q_mapel ? mysqli_num_rows($q_mapel) : 0;

require_once "../../includes/header.php";
require_once "../../includes/sidebar.php";
?>

<style>
.mapel-page{max-width:1400px}
.page-head{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:24px}
.page-head h1{margin-bottom:6px}.page-head p{margin:0}
.btn-primary,.btn-secondary,.btn-danger{display:inline-flex;align-items:center;justify-content:center;gap:7px;border:0;border-radius:10px;padding:11px 16px;text-decoration:none;font-size:14px;font-weight:600;cursor:pointer}
.btn-primary{background:linear-gradient(135deg,#2388f5,#1265dc);color:#fff;box-shadow:0 8px 18px rgba(18,101,220,.22)}
.btn-secondary{background:#eef3f9;color:#334155}.btn-danger{background:#fff0f1;color:#c92f47}
.alert{padding:13px 15px;border-radius:11px;margin-bottom:18px;font-size:14px}
.alert-success{background:#ecfdf3;color:#18794e;border:1px solid #ccefdc}
.alert-error{background:#fff1f2;color:#be123c;border:1px solid #fecdd3}
.form-card,.data-panel{background:#fff;border-radius:18px;box-shadow:0 8px 25px rgba(15,35,70,.07);padding:24px;margin-bottom:22px}
.form-title{margin:0 0 5px}.form-subtitle{margin:0 0 20px;color:#64748b;font-size:14px}
.form-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:15px}
.form-group{display:flex;flex-direction:column;gap:7px}.form-label{font-size:13px;font-weight:600;color:#334155}
.form-control{width:100%;min-height:42px;border:1px solid #dbe4ef;border-radius:10px;padding:9px 11px;outline:none;background:#fff;font:inherit}
.form-control:focus{border-color:#2388f5;box-shadow:0 0 0 3px rgba(35,136,245,.10)}
.form-actions{display:flex;gap:9px;margin-top:20px}
.toolbar{display:flex;align-items:center;justify-content:space-between;gap:15px;flex-wrap:wrap;margin-bottom:16px}
.data-count{color:#64748b;font-size:14px}.table-wrap{overflow-x:auto}
.data-table{width:100%;border-collapse:collapse;min-width:750px}
.data-table th{text-align:left;background:#f7f9fc;color:#64748b;font-size:12px;text-transform:uppercase;letter-spacing:.5px;padding:13px 12px}
.data-table td{padding:14px 12px;border-bottom:1px solid #edf1f6;font-size:14px;color:#334155}
.data-table tr:hover td{background:#fbfdff}.nama-mapel{font-weight:700;color:#17233c}
.badge{display:inline-flex;align-items:center;padding:5px 9px;border-radius:999px;font-size:12px;font-weight:700;background:#eef4ff;color:#1d64d8}
.badge-aktif{background:#eaf7ef;color:#16804a}.badge-lain{background:#eef2f7;color:#64748b}
.aksi{display:flex;gap:7px}
@media(max-width:850px){.form-grid{grid-template-columns:1fr 1fr}}
@media(max-width:600px){.page-head{align-items:flex-start;flex-direction:column}.form-grid{grid-template-columns:1fr}}
</style>

<main class="main-content">
<div class="mapel-page">

<div class="page-head">
<div>
<h1>Mata Pelajaran</h1>
<p>Kelola mata pelajaran yang digunakan dalam penilaian siswa.</p>
</div>
<div style="display:flex;gap:9px;align-items:center;flex-wrap:wrap">
<a href="index.php?tambah=1" class="btn-primary">➕ Tambah Mata Pelajaran</a>
<button type="button" class="btn-secondary" id="toggleUploadNilai" aria-expanded="false">📥 Upload Data Nilai <span id="toggleIcon">▸</span></button>
</div>
</div>

<div id="uploadNilaiPanel" class="form-card" style="display:none;border:1px solid #dbeafe;background:linear-gradient(180deg,#ffffff,#f8fbff)">
<h2 class="form-title">📥 Upload Data Nilai — Template Buku Induk</h2>
<p class="form-subtitle">Gunakan 10 mata pelajaran yang sama persis dengan tabel <strong>Prestasi Belajar</strong> pada Buku Induk.</p>
<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
<a class="btn-primary" href="../nilai/upload.php">⬆️ Buka Upload Data Nilai</a>
<a class="btn-secondary" href="../nilai/upload.php?download_template=1&format=buku_induk">⬇️ Download Template Nilai Buku Induk</a>
</div>
<div class="alert alert-success" style="margin-top:15px;margin-bottom:0">
<strong>Mapel template:</strong> PPKN • Pendidikan Agama • Bahasa Indonesia • Matematika • Ilmu Pengetahuan Alam • Ilmu Pengetahuan Sosial • Seni Budaya • Penjaskes • Bahasa Inggris • B. Daerah.
</div>
</div>

<?php if ($pesan !== ''): ?>
<div class="alert <?= $tipe_pesan === 'success' ? 'alert-success' : 'alert-error'; ?>"><?= h($pesan); ?></div>
<?php endif; ?>

<?php if ($mode_edit || isset($_GET['tambah'])): ?>
<div class="form-card">
<h2 class="form-title"><?= $mode_edit ? 'Edit Mata Pelajaran' : 'Tambah Mata Pelajaran'; ?></h2>
<p class="form-subtitle">Mata pelajaran ini menjadi referensi nilai Gasal dan Genap.</p>

<form method="post">
<input type="hidden" name="aksi" value="simpan">
<input type="hidden" name="id_mapel" value="<?= (int)$data_edit['id_mapel']; ?>">

<div class="form-grid">
<div class="form-group">
<label class="form-label">Kode Mapel</label>
<input type="text" name="kode_mapel" class="form-control" placeholder="Contoh: BIN" value="<?= h($data_edit['kode_mapel']); ?>">
</div>

<div class="form-group">
<label class="form-label">Nama Mata Pelajaran *</label>
<input type="text" name="nama_mapel" class="form-control" required placeholder="Contoh: Bahasa Indonesia" value="<?= h($data_edit['nama_mapel']); ?>">
</div>

<div class="form-group">
<label class="form-label">Kelompok</label>
<input type="text" name="kelompok" class="form-control" placeholder="Contoh: Umum" value="<?= h($data_edit['kelompok']); ?>">
</div>

<div class="form-group">
<label class="form-label">Status</label>
<select name="status" class="form-control">
<option value="Aktif" <?= $data_edit['status']==='Aktif'?'selected':''; ?>>Aktif</option>
<option value="Tidak Aktif" <?= $data_edit['status']==='Tidak Aktif'?'selected':''; ?>>Tidak Aktif</option>
</select>
</div>
</div>

<div class="form-actions">
<button type="submit" class="btn-primary">💾 <?= $mode_edit ? 'Simpan Perubahan' : 'Simpan Mata Pelajaran'; ?></button>
<a href="index.php" class="btn-secondary">Batal</a>
</div>
</form>
</div>
<?php endif; ?>

<div class="data-panel">

<?php if (!$q_mapel): ?>
<div class="alert alert-error">
Data mata pelajaran gagal dibaca: <?= h(mysqli_error($koneksi)); ?>
</div>
<?php endif; ?>

<div class="toolbar">
<div class="data-count">📚 <strong><?= $jumlah_mapel; ?></strong> mata pelajaran terdaftar</div>
</div>

<div class="table-wrap">
<table class="data-table">
<thead>
<tr>
<th>No</th>
<th>Kode</th>
<th>Nama Mata Pelajaran</th>
<th>Kelompok</th>
<th>Status</th>
<th width="150">Aksi</th>
</tr>
</thead>
<tbody>

<?php if ($q_mapel && mysqli_num_rows($q_mapel) > 0): ?>
<?php $no=1; while($mapel=mysqli_fetch_assoc($q_mapel)): ?>
<tr>
<td><?= $no++; ?></td>
<td><?= h($mapel['kode_mapel'] ?: '-'); ?></td>
<td><div class="nama-mapel"><?= h($mapel['nama_mapel']); ?></div></td>
<td><?= h($mapel['kelompok'] ?: '-'); ?></td>
<td><span class="badge <?= $mapel['status']==='Aktif'?'badge-aktif':'badge-lain'; ?>"><?= h($mapel['status']); ?></span></td>
<td>
<div class="aksi">
<a href="index.php?edit=<?= (int)$mapel['id_mapel']; ?>" class="btn-secondary">✏️</a>
<form method="post" onsubmit="return confirm('Hapus mata pelajaran ini?');">
<input type="hidden" name="aksi" value="hapus">
<input type="hidden" name="id_mapel" value="<?= (int)$mapel['id_mapel']; ?>">
<button type="submit" class="btn-danger">🗑️</button>
</form>
</div>
</td>
</tr>
<?php endwhile; ?>
<?php else: ?>
<tr><td colspan="6" style="text-align:center;padding:45px 15px;color:#94a3b8;">Belum ada mata pelajaran.</td></tr>
<?php endif; ?>

</tbody>
</table>
</div>
</div>

</div>
</main>

<script>
document.addEventListener('DOMContentLoaded', function(){
 const btn=document.getElementById('toggleUploadNilai');
 const panel=document.getElementById('uploadNilaiPanel');
 const icon=document.getElementById('toggleIcon');
 if(btn&&panel){btn.addEventListener('click',function(){
   const open=panel.style.display!=='none';
   panel.style.display=open?'none':'block';
   btn.setAttribute('aria-expanded',open?'false':'true');
   icon.textContent=open?'▸':'▾';
 });}
});
</script>
</body>
</html>
