# ABSENSI SD — BUILD 08

Fokus: integrasi Dapodik -> Data Siswa -> Kelas -> Wali Kelas -> Absensi/Nilai/Buku Induk.

Perbaikan utama:
- Import Dapodik mendukung format 46 dan 66 kolom.
- Header berulang Ayah/Ibu/Wali dibaca berdasarkan posisi resmi file Dapodik.
- Rombel disimpan di siswa.rombel_dapodik dan dipetakan otomatis ke Data Kelas.
- Kelas dibuat otomatis untuk rombel yang belum tersedia pada tahun ajaran aktif.
- Import menggunakan NISN -> NIK -> NIS untuk update, sehingga tidak membuat duplikat.
- Field kosong dari Dapodik tidak menghapus data manual yang sudah ada.
- Absensi dan Nilai tidak lagi boleh mengubah kelas master siswa.
- Auth redirect dibuat absolut agar tidak crash pada modul bertingkat.
- Schema bootstrap dijalankan otomatis dari config/database.php.
- Sidebar Absensi Siswa menjadi toggle berisi Input Absensi, Rekap Kehadiran, dan Cetak Kartu QR.
- Nested ZIP lama dikeluarkan dari deployment.

Catatan: tetap backup database sebelum deployment. Setelah memasang Build 08, import ulang file Dapodik terbaru agar rombel_dapodik dan id_kelas terisi pada siswa lama.
