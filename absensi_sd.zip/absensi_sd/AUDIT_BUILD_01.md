AUDIT BUILD 01 - ABSENSI SDN CIBURAYUT 01
==============================================

SOURCE: absensi_sd(5).zip

TEMUAN KRITIS YANG DIPERBAIKI
1. Empat modul nested menggunakan path ../../config dan ../../includes yang salah.
   Diperbaiki menjadi ../../../ sehingga tidak crash saat halaman dibuka:
   - absensi/modules/absensi_siswa
   - guru/modules/absensi_guru
   - buku_induk/modules/buku_induk
   - rekap/modules/rekap

2. Redirect wajib_login menggunakan ../login.php dan berisiko salah path pada modul bertingkat.
   Diperbaiki ke /absensi_sd/login.php.

3. Tabel absensi_siswa pada SQL menggunakan primary key id_absensi, sedangkan modul input
   hanya mengenali id_absensi_siswa. Diperbaiki agar mengenali id_absensi_siswa, id_absensi,
   atau id dan memakai primary key yang benar saat update.

4. Database dasar hanya mendefinisikan master sekolah/tahun/guru/kelas/siswa/mapel,
   sedangkan aplikasi juga membutuhkan users, nilai, absensi_guru, buku_induk.
   Ditambahkan config/schema_bootstrap.php untuk memastikan tabel inti tersedia.

5. Kolom nilai komponen yang diperlukan aplikasi (tugas, UTS, UAS, akhir, harian, rapor,
   keterangan) dipastikan tersedia.

6. Tahun ajaran diperbaiki agar semester Gasal dan Genap untuk tahun yang sama dapat
   disimpan berdampingan melalui unique gabungan tahun_ajaran + semester, bila struktur
   database lama masih memakai unique tahun_ajaran saja.

7. Admin awal hanya dibuat jika tabel users benar-benar kosong. Password default:
   username admin / password admin123. Segera ganti password setelah login.

ATURAN INTEGRASI MASTER
- Tabel siswa adalah MASTER data siswa.
- Absensi membaca id_siswa dari siswa; tidak membuat master siswa baru.
- Nilai membaca id_siswa dari siswa dan id_mapel dari mata_pelajaran.
- Buku Induk membaca id_siswa dari siswa.
- Kelas menyimpan id_wali_kelas -> guru.id_guru.
- Siswa menyimpan id_kelas -> kelas.id_kelas.
- Cetak Buku Induk membaca hubungan siswa -> kelas -> wali kelas.
- Upload nilai melakukan pencocokan siswa berdasarkan ID/NISN/nama dan tidak boleh
  membuat siswa baru secara otomatis.

HASIL VALIDASI KODE
- Seluruh file PHP: LULUS php -l (0 syntax error).
- 4 crash path nested: DIPERBAIKI.
- Primary key absensi_siswa: DIPERBAIKI.
- Database bootstrap: DITAMBAHKAN.

CATATAN
Pengujian runtime Apache + MySQL belum dapat dilakukan dari environment audit ini.
Karena itu status "100% runtime" baru boleh diberikan setelah diuji di localhost.
Versi ini disiapkan sebagai BUILD 01 AUDIT + HARDENING, bukan klaim release final.
