# ABSENSI SD BUILD 10 — FIX CRASH KELAS

Perbaikan utama:
- Menambahkan fungsi `dapodik_sync_siswa_kelas()` yang sebelumnya dipanggil tetapi tidak didefinisikan.
- Saat halaman Data Siswa dibuka, siswa lama yang memiliki `rombel_dapodik` akan dicocokkan ke master `kelas` dan `id_kelas` diperbarui.
- Kelas yang belum ada dibuat otomatis melalui helper Dapodik.
- Tidak mengubah siswa yang tidak memiliki `rombel_dapodik`.
- Menghapus require_once dapodik.php yang redundan setelah pemanggilan sinkronisasi.
- Seluruh file PHP dilint.

Cara pasang:
1. Backup database dan folder aplikasi.
2. Timpa source aplikasi dengan isi folder build ini.
3. Jangan import SQL baru hanya untuk perbaikan ini.
4. Buka Data Siswa.
5. Jika `rombel_dapodik` sudah tersimpan, kelas siswa lama akan disinkronkan otomatis.
