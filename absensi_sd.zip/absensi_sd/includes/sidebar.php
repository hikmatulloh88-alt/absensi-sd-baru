<?php
// Sidebar utama aplikasi Absensi SD
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$auth_file = __DIR__ . '/../config/auth.php';
if (file_exists($auth_file)) {
    require_once $auth_file;
}

$path_aktif = $_SERVER['REQUEST_URI'] ?? '';
$halaman_aktif = basename($_SERVER['PHP_SELF']);

$user_nama = $_SESSION['nama'] ?? $_SESSION['nama_user'] ?? $_SESSION['username'] ?? 'Pengguna';
$user_role = strtolower(trim((string)($_SESSION['role'] ?? '')));

$profil = null;
if (isset($koneksi) && $koneksi instanceof mysqli) {
    $q_profil = mysqli_query($koneksi, "SELECT * FROM sekolah LIMIT 1");
    if ($q_profil) {
        $profil = mysqli_fetch_assoc($q_profil);
    }
}
$nama_sekolah = $profil['nama_sekolah'] ?? 'SDN CIBURAYUT 01';
$logo_sekolah = trim((string)($profil['logo'] ?? ''));
$logo_sekolah_url = $logo_sekolah !== '' ? '/absensi_sd/' . ltrim($logo_sekolah, '/') : '';

function menu_diizinkan(string $menu): bool
{
    global $user_role;
    if ($user_role === 'admin') return true;
    return function_exists('izin_menu') ? izin_menu($menu) : false;
}

function menu_aktif(string $target): bool
{
    global $path_aktif;
    $target = ltrim($target, '/');
    $target_path = '/absensi_sd/' . $target;
    return strpos($path_aktif, $target_path) === 0;
}

function submenu_aktif(array $files): bool
{
    global $halaman_aktif;
    foreach ($files as $file) {
        if ($halaman_aktif === $file) return true;
    }
    return false;
}
?>

<aside class="sidebar">
    <div class="sidebar-header">
        <div class="sidebar-logo">
            <?php if ($logo_sekolah_url): ?>
                <img src="<?= htmlspecialchars($logo_sekolah_url, ENT_QUOTES, 'UTF-8'); ?>" alt="Logo Sekolah">
            <?php else: ?>
                <span>🎓</span>
            <?php endif; ?>
        </div>
        <div class="sidebar-brand">
            <h2>Absensi SD</h2>
            <p><?= htmlspecialchars($nama_sekolah); ?></p>
        </div>
    </div>

    <nav class="sidebar-menu">
        <!-- UTAMA -->
        <a href="/absensi_sd/index.php"
           class="menu-item <?= menu_aktif('index.php') ? 'active' : ''; ?>">
            <span class="menu-icon">🏠</span><span>Dashboard</span>
        </a>

        <!-- MASTER DATA -->
        <?php if (menu_diizinkan('siswa') || menu_diizinkan('guru') || menu_diizinkan('kelas') || menu_diizinkan('mapel')): ?>
            <div class="menu-title">MASTER DATA</div>

            <?php if (menu_diizinkan('siswa')): ?>
                <a href="/absensi_sd/modules/siswa/"
                   class="menu-item <?= menu_aktif('modules/siswa/') ? 'active' : ''; ?>">
                    <span class="menu-icon">👨‍🎓</span><span>Data Siswa</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('guru')): ?>
                <a href="/absensi_sd/modules/guru/"
                   class="menu-item <?= menu_aktif('modules/guru/') ? 'active' : ''; ?>">
                    <span class="menu-icon">👨‍🏫</span><span>Data Guru & Karyawan</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('kelas')): ?>
                <a href="/absensi_sd/modules/kelas/"
                   class="menu-item <?= menu_aktif('modules/kelas/') ? 'active' : ''; ?>">
                    <span class="menu-icon">🏫</span><span>Data Kelas</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('mapel')): ?>
                <a href="/absensi_sd/modules/mata_pelajaran/index.php"
                   class="menu-item <?= menu_aktif('modules/mata_pelajaran/index.php') ? 'active' : ''; ?>">
                    <span class="menu-icon">📚</span><span>Mata Pelajaran</span>
                </a>
            <?php endif; ?>
        <?php endif; ?>

        <!-- ABSENSI -->
        <?php if (menu_diizinkan('absensi_siswa') || menu_diizinkan('absensi_guru')): ?>
            <div class="menu-title">ABSENSI</div>

            <?php if (menu_diizinkan('absensi_siswa')): ?>
                <?php $absensi_open = menu_aktif('modules/absensi/') || menu_aktif('modules/rekap/'); ?>
                <div class="menu-group <?= $absensi_open ? 'open' : ''; ?>">
                    <button type="button" class="menu-item menu-group-trigger" aria-expanded="<?= $absensi_open ? 'true' : 'false'; ?>">
                        <span class="menu-icon">🗓️</span><span>Kehadiran Siswa</span><span class="menu-arrow">›</span>
                    </button>
                    <div class="submenu">
                        <a href="/absensi_sd/modules/absensi/index.php" class="submenu-item <?= menu_aktif('modules/absensi/index.php') ? 'active' : ''; ?>">
                            <span>✏️</span><span>Input Kehadiran</span>
                        </a>
                        <a href="/absensi_sd/modules/absensi/scan_qr.php" class="submenu-item <?= menu_aktif('modules/absensi/scan_qr.php') ? 'active' : ''; ?>">
                            <span>📷</span><span>Scan QR</span>
                        </a>
                        <?php if (menu_diizinkan('rekap_absensi')): ?>
                            <a href="/absensi_sd/modules/rekap/index.php" class="submenu-item <?= menu_aktif('modules/rekap/') ? 'active' : ''; ?>">
                                <span>📊</span><span>Rekap Kehadiran</span>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (menu_diizinkan('absensi_guru')): ?>
                <a href="/absensi_sd/modules/guru/absensi.php"
                   class="menu-item <?= $halaman_aktif === 'absensi.php' && strpos($path_aktif, '/modules/guru/') !== false ? 'active' : ''; ?>">
                    <span class="menu-icon">👤</span><span>Absensi Guru & Karyawan</span>
                </a>
            <?php endif; ?>
        <?php endif; ?>

        <!-- EKSTRAKURIKULER -->
        <?php if (menu_diizinkan('ekstrakurikuler')): ?>
            <div class="menu-title">EKSTRAKURIKULER</div>
            <?php $eskul_open = strpos($path_aktif, '/modules/ekstrakurikuler/') !== false; ?>
            <div class="menu-group <?= $eskul_open ? 'open' : ''; ?>">
                <button type="button" class="menu-item menu-group-trigger" aria-expanded="<?= $eskul_open ? 'true' : 'false'; ?>">
                    <span class="menu-icon">🏅</span><span>Guru Ekstrakurikuler</span><span class="menu-arrow">›</span>
                </button>
                <div class="submenu">
                    <a href="/absensi_sd/modules/ekstrakurikuler/kehadiran.php" class="submenu-item <?= menu_aktif('modules/ekstrakurikuler/kehadiran.php') ? 'active' : ''; ?>">
                        <span>🗓️</span><span>Kehadiran</span>
                    </a>
                    <a href="/absensi_sd/modules/ekstrakurikuler/kegiatan.php" class="submenu-item <?= menu_aktif('modules/ekstrakurikuler/kegiatan.php') ? 'active' : ''; ?>">
                        <span>📝</span><span>Isi Kegiatan Eskul</span>
                    </a>
                    <a href="/absensi_sd/modules/ekstrakurikuler/foto.php" class="submenu-item <?= menu_aktif('modules/ekstrakurikuler/foto.php') ? 'active' : ''; ?>">
                        <span>📷</span><span>Foto Kegiatan</span>
                    </a>
                    <a href="/absensi_sd/modules/ekstrakurikuler/laporan.php" class="submenu-item <?= menu_aktif('modules/ekstrakurikuler/laporan.php') ? 'active' : ''; ?>">
                        <span>🖨️</span><span>Cetak Laporan Kegiatan</span>
                    </a>
                </div>
            </div>
        <?php endif; ?>

        <!-- AKADEMIK -->
        <?php if (menu_diizinkan('buku_induk') || menu_diizinkan('nilai_siswa')): ?>
            <div class="menu-title">AKADEMIK</div>

            <?php if (menu_diizinkan('buku_induk')): ?>
                <a href="/absensi_sd/modules/buku_induk/"
                   class="menu-item <?= menu_aktif('modules/buku_induk/') && $halaman_aktif !== 'cetak_masal.php' ? 'active' : ''; ?>">
                    <span class="menu-icon">📖</span><span>Buku Induk</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('nilai_siswa')): ?>
                <?php $nilai_open = strpos($path_aktif, '/modules/nilai/') !== false; ?>
                <div class="menu-group <?= $nilai_open ? 'open' : ''; ?>">
                    <button type="button" class="menu-item menu-group-trigger" aria-expanded="<?= $nilai_open ? 'true' : 'false'; ?>">
                        <span class="menu-icon">📊</span><span>Nilai Siswa</span><span class="menu-arrow">›</span>
                    </button>
                    <div class="submenu">
                        <a href="/absensi_sd/modules/nilai/index.php" class="submenu-item <?= $halaman_aktif === 'index.php' && strpos($path_aktif, '/modules/nilai/') !== false ? 'active' : ''; ?>">
                            <span>📋</span><span>Daftar Nilai</span>
                        </a>
                        <?php if (menu_diizinkan('nilai_gasal')): ?>
                            <a href="/absensi_sd/modules/nilai/gasal.php" class="submenu-item <?= $halaman_aktif === 'gasal.php' ? 'active' : ''; ?>">
                                <span>📝</span><span>Nilai Gasal</span>
                            </a>
                        <?php endif; ?>
                        <?php if (menu_diizinkan('nilai_genap')): ?>
                            <a href="/absensi_sd/modules/nilai/genap.php" class="submenu-item <?= $halaman_aktif === 'genap.php' ? 'active' : ''; ?>">
                                <span>📝</span><span>Nilai Genap</span>
                            </a>
                        <?php endif; ?>
                        <?php if (menu_diizinkan('upload_nilai')): ?>
                            <a href="/absensi_sd/modules/nilai/upload.php" class="submenu-item <?= $halaman_aktif === 'upload.php' ? 'active' : ''; ?>">
                                <span>📤</span><span>Upload Nilai</span>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <!-- LAPORAN & CETAK : semua akses cetak dikumpulkan di satu pusat -->
        <?php if (menu_diizinkan('laporan') || menu_diizinkan('buku_induk_masal') || menu_diizinkan('kartu_absensi') || menu_diizinkan('absensi_guru') || menu_diizinkan('ekstrakurikuler')): ?>
            <div class="menu-title">LAPORAN &amp; CETAK</div>
            <a href="/absensi_sd/modules/laporan/pusat_cetak.php"
               class="menu-item <?= menu_aktif('modules/laporan/pusat_cetak.php') ? 'active' : ''; ?>">
                <span class="menu-icon">🖨️</span><span>Laporan &amp; Cetak</span>
            </a>
        <?php endif; ?>

        <!-- PENGATURAN -->
        <?php if (menu_diizinkan('pengguna') || $user_role === 'admin'): ?>
            <div class="menu-title">PENGATURAN</div>

            <?php if ($user_role === 'admin'): ?>
                <a href="/absensi_sd/modules/pengaturan/"
                   class="menu-item <?= menu_aktif('modules/pengaturan/') ? 'active' : ''; ?>">
                    <span class="menu-icon">⚙️</span><span>Pengaturan</span>
                </a>
            <?php endif; ?>

            <?php if (menu_diizinkan('pengguna')): ?>
                <a href="/absensi_sd/modules/pengguna/"
                   class="menu-item <?= menu_aktif('modules/pengguna/') ? 'active' : ''; ?>">
                    <span class="menu-icon">👥</span><span>Pengguna</span>
                </a>
            <?php endif; ?>
        <?php endif; ?>

        <a href="/absensi_sd/logout.php" class="menu-item logout">
            <span class="menu-icon">🚪</span><span>Keluar</span>
        </a>
    </nav>
</aside>

<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.menu-group-trigger').forEach(function (trigger) {
        trigger.addEventListener('click', function () {
            const group = trigger.closest('.menu-group');
            const open = !group.classList.contains('open');
            group.classList.toggle('open', open);
            trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
    });
});
</script>
