<?php
$page_title = $page_title ?? 'Aplikasi Absensi SDN Ciburayut 01';
$theme_name = 'navy';
$custom_theme_web = '';
if (isset($koneksi) && $koneksi instanceof mysqli) {
    $theme_cfg = __DIR__ . '/../config/theme.php';
    if (is_file($theme_cfg)) {
        require_once $theme_cfg;
        $theme_name = tema_setting($koneksi);
        if ($theme_name === 'custom') {
            $custom_path = tema_custom_css($koneksi);
            if ($custom_path !== '') $custom_theme_web = '/' . ltrim($custom_path, '/');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id" data-theme="<?= htmlspecialchars($theme_name, ENT_QUOTES, 'UTF-8'); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title); ?></title>
    <link rel="stylesheet" href="/absensi_sd/assets/css/main.css?v=<?= filemtime(__DIR__ . '/../assets/css/main.css'); ?>">
    <?php if ($custom_theme_web): ?>
        <link rel="stylesheet" href="<?= htmlspecialchars($custom_theme_web, ENT_QUOTES, 'UTF-8'); ?>?v=<?= time(); ?>">
    <?php endif; ?>
</head>
<body class="theme-<?= htmlspecialchars($theme_name, ENT_QUOTES, 'UTF-8'); ?>">
