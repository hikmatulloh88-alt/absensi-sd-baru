<?php
session_start();
require_once __DIR__ . '/config/database.php';

echo '<!doctype html><html lang="id"><head><meta charset="utf-8">
<title>Diagnosa Login</title>
<style>
body{font-family:Arial,sans-serif;background:#f4f7fb;padding:30px;color:#17233c}
.box{max-width:900px;margin:auto;background:#fff;padding:25px;border-radius:16px;box-shadow:0 8px 25px rgba(0,0,0,.08)}
h1{margin-top:0}.ok{color:#15803d}.bad{color:#b91c1c}
table{border-collapse:collapse;width:100%;margin-top:15px}td,th{border:1px solid #ddd;padding:10px;text-align:left}
th{background:#eef3f8}
pre{background:#f1f5f9;padding:15px;border-radius:10px;overflow:auto}
</style></head><body><div class="box">';
echo '<h1>🔎 Diagnosa Login & Role</h1>';

echo '<h3>1. Session PHP</h3>';
echo '<table>';
foreach ($_SESSION as $k=>$v) {
    if (is_scalar($v)) echo '<tr><th>'.htmlspecialchars($k).'</th><td>'.htmlspecialchars((string)$v).'</td></tr>';
}
echo '</table>';

echo '<h3>2. Data user dari database</h3>';
$uid = (int)($_SESSION['user_id'] ?? 0);
if ($uid > 0) {
    $q = mysqli_query($koneksi, "SELECT * FROM users WHERE id_user = ".$uid." LIMIT 1");
    if ($q && ($row=mysqli_fetch_assoc($q))) {
        echo '<table><tr><th>Kolom</th><th>Nilai</th></tr>';
        foreach ($row as $k=>$v) {
            if (stripos($k,'password') !== false) $v='[disembunyikan]';
            echo '<tr><td>'.htmlspecialchars($k).'</td><td>'.htmlspecialchars((string)$v).'</td></tr>';
        }
        echo '</table>';
    } else {
        echo '<p class="bad">User ID session tidak ditemukan di tabel users.</p>';
    }
} else {
    echo '<p class="bad">Session user_id kosong.</p>';
}

echo '<h3>3. Pemeriksaan role</h3>';
$role = strtolower(trim((string)($_SESSION['role'] ?? '')));
echo '<p>Role session terbaca: <strong>'.htmlspecialchars($role ?: '[KOSONG]').'</strong></p>';
echo '<p>Apakah dianggap Admin? <strong class="'.($role==='admin'?'ok':'bad').'">'.($role==='admin'?'YA ✅':'TIDAK ❌').'</strong></p>';

echo '<h3>4. Semua session</h3><pre>'.htmlspecialchars(print_r($_SESSION,true)).'</pre>';
echo '<p><strong>Setelah selesai, hapus file diagnosa ini dari folder absensi_sd.</strong></p>';
echo '</div></body></html>';
?>
