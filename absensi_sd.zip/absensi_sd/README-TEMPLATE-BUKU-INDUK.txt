BUKU INDUK TEMPLATE ASLI
=========================

Modul cetak Buku Induk menggunakan file PDF BUKU INDUK SDN CIBURAYUT 01 yang diberikan pengguna sebagai template visual.

Hasil cetak per siswa:
1. Halaman 1 - Letter Portrait: BUKU INDUK SISWA + A. KETERANGAN SISWA + B. KETERANGAN ORANG TUA/WALI SISWA
2. Halaman 2 - Letter Portrait: C. PERKEMBANGAN SISWA + D. BEA SISWA + E. MENINGGALKAN SEKOLAH + F. LAIN-LAIN
3. Halaman 3 - Letter Landscape: PRESTASI BELAJAR

Relasi wali kelas tetap berasal dari Data Kelas -> id_wali_kelas -> Data Guru.
Template visual tidak ditambahi elemen baru agar tetap mengikuti PDF sumber.

Jika database buku_induk belum mempunyai field tambahan yang dibutuhkan, tersedia:
database/update_buku_induk_template.sql
