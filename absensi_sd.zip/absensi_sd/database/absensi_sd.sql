CREATE DATABASE IF NOT EXISTS absensi_sd_ciburayut
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE absensi_sd_ciburayut;

CREATE TABLE sekolah (
    id_sekolah INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nama_sekolah VARCHAR(150) NOT NULL,
    npsn VARCHAR(20) NULL,
    alamat TEXT NULL,
    desa VARCHAR(100) NULL,
    kecamatan VARCHAR(100) NULL,
    kabupaten VARCHAR(100) NULL,
    provinsi VARCHAR(100) NULL,
    kode_pos VARCHAR(10) NULL,
    kepala_sekolah VARCHAR(150) NULL,
    nip_kepala_sekolah VARCHAR(30) NULL,
    logo VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE tahun_ajaran (
    id_tahun_ajaran INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    tahun_ajaran VARCHAR(20) NOT NULL UNIQUE,
    semester ENUM('Gasal','Genap') NOT NULL,
    aktif TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE guru (
    id_guru INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nip VARCHAR(30) NULL UNIQUE,
    nuptk VARCHAR(30) NULL UNIQUE,
    nik VARCHAR(30) NULL UNIQUE,
    nama VARCHAR(150) NOT NULL,
    jenis_kelamin ENUM('L','P') NOT NULL,
    jabatan VARCHAR(100) NULL,
    jenis_ptk VARCHAR(100) NULL,
    no_hp VARCHAR(30) NULL,
    alamat TEXT NULL,
    foto VARCHAR(255) NULL,
    status ENUM('Aktif','Tidak Aktif') NOT NULL DEFAULT 'Aktif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE kelas (
    id_kelas INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nama_kelas VARCHAR(50) NOT NULL,
    tingkat TINYINT UNSIGNED NOT NULL,
    id_wali_kelas INT UNSIGNED NULL,
    id_tahun_ajaran INT UNSIGNED NOT NULL,
    status ENUM('Aktif','Tidak Aktif') NOT NULL DEFAULT 'Aktif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_kelas_wali FOREIGN KEY (id_wali_kelas) REFERENCES guru(id_guru)
        ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT fk_kelas_tahun FOREIGN KEY (id_tahun_ajaran) REFERENCES tahun_ajaran(id_tahun_ajaran)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE siswa (
    id_siswa INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nis VARCHAR(30) NULL,
    nisn VARCHAR(30) NULL UNIQUE,
    nik VARCHAR(30) NULL UNIQUE,
    nama_siswa VARCHAR(150) NOT NULL,
    jenis_kelamin ENUM('L','P') NOT NULL,
    tempat_lahir VARCHAR(100) NULL,
    tanggal_lahir DATE NULL,
    agama VARCHAR(30) NULL,
    alamat TEXT NULL,
    nama_ayah VARCHAR(150) NULL,
    nama_ibu VARCHAR(150) NULL,
    nama_wali VARCHAR(150) NULL,
    no_kk VARCHAR(30) NULL,
    no_akta VARCHAR(50) NULL,
    no_kip VARCHAR(50) NULL,
    id_kelas INT UNSIGNED NULL,
    status_siswa ENUM('Aktif','Lulus','Pindah','Tidak Aktif') NOT NULL DEFAULT 'Aktif',
    foto VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_siswa_kelas FOREIGN KEY (id_kelas) REFERENCES kelas(id_kelas)
        ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE mata_pelajaran (
    id_mapel INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    kode_mapel VARCHAR(30) NULL UNIQUE,
    nama_mapel VARCHAR(100) NOT NULL,
    kelompok VARCHAR(100) NULL,
    status ENUM('Aktif','Tidak Aktif') NOT NULL DEFAULT 'Aktif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO sekolah (nama_sekolah, desa, kecamatan, kabupaten, provinsi)
VALUES ('SDN CIBURAYUT 01', 'Ciburayut', 'Cigombong', 'Bogor', 'Jawa Barat');

INSERT INTO tahun_ajaran (tahun_ajaran, semester, aktif)
VALUES ('2026/2027', 'Gasal', 1);

-- Kolom tambahan Dapodik (aman untuk instalasi baru; instalasi lama gunakan migrate_dapodik_lengkap.sql)
ALTER TABLE siswa
  ADD COLUMN rt VARCHAR(10) NULL,
  ADD COLUMN rw VARCHAR(10) NULL,
  ADD COLUMN dusun VARCHAR(100) NULL,
  ADD COLUMN kelurahan VARCHAR(150) NULL,
  ADD COLUMN kecamatan VARCHAR(150) NULL,
  ADD COLUMN kode_pos VARCHAR(10) NULL,
  ADD COLUMN jenis_tinggal VARCHAR(100) NULL,
  ADD COLUMN alat_transportasi VARCHAR(100) NULL,
  ADD COLUMN telepon VARCHAR(50) NULL,
  ADD COLUMN hp VARCHAR(50) NULL,
  ADD COLUMN email VARCHAR(150) NULL,
  ADD COLUMN skhun VARCHAR(100) NULL,
  ADD COLUMN penerima_kps VARCHAR(20) NULL,
  ADD COLUMN no_kps VARCHAR(80) NULL,
  ADD COLUMN ayah_tahun_lahir VARCHAR(10) NULL,
  ADD COLUMN ayah_pendidikan VARCHAR(100) NULL,
  ADD COLUMN ayah_pekerjaan VARCHAR(100) NULL,
  ADD COLUMN ayah_penghasilan VARCHAR(100) NULL,
  ADD COLUMN ayah_nik VARCHAR(30) NULL,
  ADD COLUMN ibu_tahun_lahir VARCHAR(10) NULL,
  ADD COLUMN ibu_pendidikan VARCHAR(100) NULL,
  ADD COLUMN ibu_pekerjaan VARCHAR(100) NULL,
  ADD COLUMN ibu_penghasilan VARCHAR(100) NULL,
  ADD COLUMN ibu_nik VARCHAR(30) NULL,
  ADD COLUMN anak_ke VARCHAR(10) NULL,
  ADD COLUMN lintang VARCHAR(50) NULL,
  ADD COLUMN bujur VARCHAR(50) NULL,
  ADD COLUMN berat_badan VARCHAR(30) NULL,
  ADD COLUMN tinggi_badan VARCHAR(30) NULL,
  ADD COLUMN lingkar_kepala VARCHAR(30) NULL,
  ADD COLUMN jml_saudara_kandung VARCHAR(30) NULL,
  ADD COLUMN jarak_rumah_km VARCHAR(30) NULL;
