USE absensi_sd_ciburayut;

CREATE TABLE IF NOT EXISTS absensi_siswa (
    id_absensi BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_siswa INT UNSIGNED NOT NULL,
    id_kelas INT UNSIGNED NOT NULL,
    id_tahun_ajaran INT UNSIGNED NOT NULL,
    tanggal DATE NOT NULL,
    status ENUM('Hadir','Sakit','Izin','Alpa') NOT NULL DEFAULT 'Hadir',
    keterangan VARCHAR(255) NULL,
    jam_masuk TIME NULL,
    jam_pulang TIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_absensi),
    UNIQUE KEY uk_absensi_siswa (id_siswa, tanggal),
    KEY idx_absensi_kelas (id_kelas),
    KEY idx_absensi_tahun (id_tahun_ajaran),
    CONSTRAINT fk_absensi_siswa_siswa FOREIGN KEY (id_siswa)
        REFERENCES siswa(id_siswa)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_absensi_siswa_kelas FOREIGN KEY (id_kelas)
        REFERENCES kelas(id_kelas)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_absensi_siswa_tahun FOREIGN KEY (id_tahun_ajaran)
        REFERENCES tahun_ajaran(id_tahun_ajaran)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
