-- Opsional: jalankan jika tabel buku_induk belum memiliki field tambahan.
-- Script ini TIDAK menghapus data lama.

CREATE TABLE IF NOT EXISTS buku_induk (
  id_buku_induk INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_siswa INT UNSIGNED NOT NULL UNIQUE,
  tinggi_badan VARCHAR(30) NULL,
  berat_badan VARCHAR(30) NULL,
  lingkar_kepala VARCHAR(30) NULL,
  jarak_rumah_ke_sekolah VARCHAR(50) NULL,
  golongan_darah VARCHAR(10) NULL,
  penyakit_pernah_diderita TEXT NULL,
  kelainan_jasmani TEXT NULL,
  asal_sekolah VARCHAR(150) NULL,
  nomor_peserta_ujian VARCHAR(80) NULL,
  nomor_ijazah VARCHAR(80) NULL,
  tanggal_ijazah VARCHAR(30) NULL,
  prestasi TEXT NULL,
  catatan_wali_kelas TEXT NULL,
  catatan_kepala_sekolah TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_buku_induk_siswa FOREIGN KEY (id_siswa) REFERENCES siswa(id_siswa) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;
