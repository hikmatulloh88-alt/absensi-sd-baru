-- Tambahkan komponen nilai untuk perhitungan otomatis.
-- Rumus:
-- Nilai Akhir = (Tugas x 30%) + (UTS x 30%) + (UAS x 40%)
-- Aman dijalankan berulang kali: hanya menambah kolom jika belum ada.

SET @db := DATABASE();

SET @sql := (
    SELECT IF(
        COUNT(*) = 0,
        'ALTER TABLE nilai ADD COLUMN nilai_tugas DECIMAL(5,2) NULL AFTER id_tahun_ajaran',
        'SELECT 1'
    )
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = @db
      AND TABLE_NAME = 'nilai'
      AND COLUMN_NAME = 'nilai_tugas'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := (
    SELECT IF(
        COUNT(*) = 0,
        'ALTER TABLE nilai ADD COLUMN nilai_uts DECIMAL(5,2) NULL AFTER nilai_tugas',
        'SELECT 1'
    )
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = @db
      AND TABLE_NAME = 'nilai'
      AND COLUMN_NAME = 'nilai_uts'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := (
    SELECT IF(
        COUNT(*) = 0,
        'ALTER TABLE nilai ADD COLUMN nilai_uas DECIMAL(5,2) NULL AFTER nilai_uts',
        'SELECT 1'
    )
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = @db
      AND TABLE_NAME = 'nilai'
      AND COLUMN_NAME = 'nilai_uas'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
