-- BUILD 08: migrasi aman, tidak menghapus data.
ALTER TABLE siswa ADD COLUMN rombel_dapodik VARCHAR(100) NULL;
-- Jika kolom sudah ada, lewati perintah di atas. Kolom Dapodik lainnya ditambahkan otomatis oleh config/schema_bootstrap.php.
