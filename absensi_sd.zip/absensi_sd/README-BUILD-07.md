# BUILD 07 - Sinkronisasi Rombel Dapodik

Perbaikan utama:
- Mendukung file Daftar Peserta Didik Dapodik 46 kolom dan 66 kolom (Dapodik 2026).
- Menangani header bertingkat Data Ayah/Data Ibu/Data Wali.
- Menyimpan Rombel Saat Ini ke `rombel_dapodik`.
- Mencocokkan Rombel Dapodik ke tabel kelas tanpa mensyaratkan status Aktif.
- Jika kelas belum ada, membuat kelas otomatis berdasarkan rombel.
- Data lama yang masih `Belum ditentukan` harus di-upload ulang dari file Dapodik agar NISN/NIK dipetakan kembali dan id_kelas diperbaiki.
- Data wali dan field Dapodik tambahan 2026 disimpan bila kolom tersedia.

Penting: jangan hapus database. Setelah mengganti source, upload ulang file Dapodik asli.
