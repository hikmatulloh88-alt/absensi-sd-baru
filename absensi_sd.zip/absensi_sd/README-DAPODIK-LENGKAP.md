# Integrasi Dapodik Lengkap

Importer Data Siswa sekarang menerima file `Daftar Peserta Didik` Dapodik asli.

## Sumber Master
Data siswa tetap berasal dari tabel `siswa`. Semua menu siswa membaca `id_siswa` dari master ini.

## Field Dapodik yang disimpan
NIPD, Nama, JK, NISN, Tempat/Tanggal Lahir, NIK, Agama, Alamat, RT/RW, Dusun, Kelurahan, Kecamatan, Kode Pos, Jenis Tinggal, Alat Transportasi, Telepon, HP, E-Mail, SKHUN, Penerima KPS, No. KPS, Data Ayah, tahun lahir/pendidikan/pekerjaan/penghasilan/NIK ayah, Data Ibu dan field ibu, Rombel Saat Ini, Anak ke-berapa, Lintang, Bujur, No KK, Berat Badan, Tinggi Badan, Lingkar Kepala, jumlah saudara kandung, dan jarak rumah ke sekolah.

Field yang memang tidak ada pada file Dapodik sumber tidak dibuat-buat oleh aplikasi.

## Pencocokan kelas
`K 5 A`, `K4`, `Kelas 5 A`, dan variasi penulisan kelas dinormalisasi agar dapat dicocokkan dengan Data Kelas. Jika kelas belum ada, siswa tetap diimpor tetapi `id_kelas` dikosongkan dan nama kelas dilaporkan agar operator dapat membuat/memperbaiki kelas.

## Anti duplikat
Prioritas pencarian siswa: NISN -> NIK -> NIPD/NIS. Jika ditemukan, data di-update. Jika tidak ditemukan, dibuat siswa baru.

## Buku Induk
Buku Induk menggunakan data master siswa sebagai fallback jika field Buku Induk belum pernah diisi. Dengan demikian data Dapodik tidak perlu diketik ulang.
