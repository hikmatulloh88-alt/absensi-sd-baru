BUILD 06 — AUDIT & DAPODIK IMPORT FIX

Perbaikan:
1. Import Dapodik 46 kolom dibaca berdasarkan struktur kolom resmi export Daftar Peserta Didik.
2. Kolom Ayah dan Ibu yang memiliki header berulang tidak lagi tertukar.
3. Rombel Saat Ini (contoh K 5 A) dinormalisasi dan dicocokkan otomatis ke Data Kelas.
4. Jika rombel belum ada, kelas aktif dibuat otomatis dan siswa langsung diberi id_kelas.
5. Data siswa lama dicari dengan NISN, NIK, lalu NIPD/NIS agar import ulang melakukan UPDATE, bukan duplikasi.
6. Field Dapodik lengkap ditambahkan ke tabel siswa, termasuk alias nama kolom dari migrasi lama agar modul lama tetap kompatibel.
7. Nilai kosong tidak menghapus identitas yang tidak tersedia? Import tetap mengikuti isi file; data yang tidak ada tidak dibuat-buat.
8. config/dapodik.php hanya memiliki satu deklarasi tiap helper; crash redeclare diperbaiki.
9. Semua file PHP telah diperiksa dengan php -l: 0 syntax error.
10. Data Siswa tetap menjadi master untuk menu lain.

CATATAN:
- Jangan mengganti database dengan SQL baru jika database lama sudah berisi data.
- Setelah memasang build, jalankan Import Dapodik asli untuk sinkronisasi kelas dan field lengkap.
- Wali kelas tetap diatur pada Data Kelas karena file Daftar Peserta Didik tidak menyediakan field wali kelas.
