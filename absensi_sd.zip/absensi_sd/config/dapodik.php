<?php
/**
 * Helper Dapodik terpusat.
 * Rombel Dapodik -> kelas master; Data Siswa tetap satu-satunya master siswa.
 */
function dapodik_norm_text($v){
    $v=mb_strtolower(trim((string)($v??'')),'UTF-8');
    $v=preg_replace('/\s+/u',' ',$v);
    $v=preg_replace('/^kelas\s*/iu','',$v);
    $v=preg_replace('/^k\s*/iu','',$v);
    return preg_replace('/[^a-z0-9]+/u','',$v);
}
function dapodik_clean($v){
    $v=trim((string)($v??''));
    return $v==='' ? null : $v;
}
function dapodik_date($v){
    $v=trim((string)($v??'')); if($v==='') return null;
    if(preg_match('/^\d{4}-\d{2}-\d{2}$/',$v)) return $v;
    if(is_numeric($v)){$n=(float)$v;if($n>20000&&$n<60000){$d=new DateTime('1899-12-30');$d->modify('+'.(int)$n.' days');return $d->format('Y-m-d');}}
    foreach(['d/m/Y','d-m-Y','Y/m/d','m/d/Y'] as $fmt){$d=DateTime::createFromFormat($fmt,$v);if($d)return $d->format('Y-m-d');}
    return $v;
}
function dapodik_class_label($name){
    $raw=trim((string)($name??'')); if($raw==='') return '';
    $raw=preg_replace('/\s+/u',' ', $raw);
    $raw=preg_replace('/^kelas\s*/iu','',$raw);
    $raw=preg_replace('/^k\s*/iu','',$raw);
    $raw=trim($raw);
    if(preg_match('/^([1-6])\s*([A-Za-z])$/u',$raw,$m)) return 'Kelas '.$m[1].' '.strtoupper($m[2]);
    if(preg_match('/^([1-6])$/u',$raw,$m)) return 'Kelas '.$m[1];
    return 'Kelas '.$raw;
}
function dapodik_ensure_tahun_aktif($db){
    $q=mysqli_query($db,"SELECT id_tahun_ajaran FROM tahun_ajaran WHERE aktif=1 ORDER BY id_tahun_ajaran DESC LIMIT 1");
    if($q&&($r=mysqli_fetch_assoc($q))) return (int)$r['id_tahun_ajaran'];
    $ta='2026/2027';$sem='Gasal';
    $st=mysqli_prepare($db,"SELECT id_tahun_ajaran FROM tahun_ajaran WHERE tahun_ajaran=? AND semester=? LIMIT 1");
    if($st){mysqli_stmt_bind_param($st,'ss',$ta,$sem);mysqli_stmt_execute($st);$rr=mysqli_stmt_get_result($st);if($rr&&($x=mysqli_fetch_assoc($rr))){$id=(int)$x['id_tahun_ajaran'];mysqli_query($db,"UPDATE tahun_ajaran SET aktif=0");mysqli_query($db,"UPDATE tahun_ajaran SET aktif=1 WHERE id_tahun_ajaran=$id");return $id;}}
    $st=mysqli_prepare($db,"INSERT INTO tahun_ajaran (tahun_ajaran,semester,aktif) VALUES (?,?,1)");
    if($st){mysqli_stmt_bind_param($st,'ss',$ta,$sem);if(mysqli_stmt_execute($st))return (int)mysqli_insert_id($db);}
    return 0;
}
function dapodik_ensure_columns($db){
    $defs=[
      'rombel_dapodik'=>"VARCHAR(100) NULL",'rt'=>"VARCHAR(10) NULL",'rw'=>"VARCHAR(10) NULL",'dusun'=>"VARCHAR(100) NULL",'kelurahan'=>"VARCHAR(150) NULL",'kecamatan'=>"VARCHAR(150) NULL",'kode_pos'=>"VARCHAR(10) NULL",'jenis_tinggal'=>"VARCHAR(100) NULL",'alat_transportasi'=>"VARCHAR(100) NULL",'telepon'=>"VARCHAR(50) NULL",'hp'=>"VARCHAR(50) NULL",'email'=>"VARCHAR(150) NULL",'skhun'=>"VARCHAR(100) NULL",'penerima_kps'=>"VARCHAR(20) NULL",'no_kps'=>"VARCHAR(80) NULL",
      'ayah_tahun_lahir'=>"VARCHAR(10) NULL",'ayah_pendidikan'=>"VARCHAR(100) NULL",'ayah_pekerjaan'=>"VARCHAR(100) NULL",'ayah_penghasilan'=>"VARCHAR(100) NULL",'ayah_nik'=>"VARCHAR(30) NULL",'ibu_tahun_lahir'=>"VARCHAR(10) NULL",'ibu_pendidikan'=>"VARCHAR(100) NULL",'ibu_pekerjaan'=>"VARCHAR(100) NULL",'ibu_penghasilan'=>"VARCHAR(100) NULL",'ibu_nik'=>"VARCHAR(30) NULL",
      'wali_tahun_lahir'=>"VARCHAR(10) NULL",'wali_pendidikan'=>"VARCHAR(100) NULL",'wali_pekerjaan'=>"VARCHAR(100) NULL",'wali_penghasilan'=>"VARCHAR(100) NULL",'wali_nik'=>"VARCHAR(30) NULL",
      'no_peserta_ujian'=>"VARCHAR(100) NULL",'no_ijazah'=>"VARCHAR(100) NULL",'penerima_kip'=>"VARCHAR(20) NULL",'nomor_kip'=>"VARCHAR(50) NULL",'nama_di_kip'=>"VARCHAR(150) NULL",'nomor_kks'=>"VARCHAR(50) NULL",'no_registrasi_akta_lahir'=>"VARCHAR(100) NULL",'bank'=>"VARCHAR(100) NULL",'nomor_rekening_bank'=>"VARCHAR(100) NULL",'rekening_atas_nama'=>"VARCHAR(150) NULL",'layak_pip'=>"VARCHAR(20) NULL",'alasan_layak_pip'=>"VARCHAR(255) NULL",'kebutuhan_khusus'=>"VARCHAR(150) NULL",'sekolah_asal'=>"VARCHAR(150) NULL",'anak_ke'=>"VARCHAR(10) NULL",'lintang'=>"VARCHAR(50) NULL",'bujur'=>"VARCHAR(50) NULL",'no_kk'=>"VARCHAR(30) NULL",'berat_badan'=>"VARCHAR(30) NULL",'tinggi_badan'=>"VARCHAR(30) NULL",'lingkar_kepala'=>"VARCHAR(30) NULL",'jml_saudara_kandung'=>"VARCHAR(30) NULL",'jarak_rumah_km'=>"VARCHAR(30) NULL"
    ];
    $q=mysqli_query($db,"SHOW COLUMNS FROM siswa"); if(!$q)return false; $existing=[]; while($r=mysqli_fetch_assoc($q))$existing[$r['Field']]=1;
    foreach($defs as $f=>$def){if(!isset($existing[$f])&&!mysqli_query($db,"ALTER TABLE siswa ADD COLUMN `$f` $def"))return false;}
    return true;
}

/**
 * Sinkronisasi kelas siswa lama berdasarkan rombel_dapodik.
 * Tidak mengubah siswa yang tidak memiliki rombel sumber.
 * Mengembalikan statistik agar halaman pemanggil dapat mengetahui hasilnya.
 */
function dapodik_sync_siswa_kelas($db){
    $stats = ['diperiksa'=>0,'disinkronkan'=>0,'kelas_dibuat'=>0,'gagal'=>0];

    if (!($db instanceof mysqli)) return $stats;

    // Pastikan kolom sumber tersedia pada database lama.
    if (!dapodik_ensure_columns($db)) return $stats;

    $q = mysqli_query($db, "SELECT id_siswa, id_kelas, rombel_dapodik FROM siswa WHERE status_siswa IN ('Aktif','Lulus','Pindah','Tidak Aktif') AND rombel_dapodik IS NOT NULL AND TRIM(rombel_dapodik) <> ''");
    if (!$q) return $stats;

    while ($s = mysqli_fetch_assoc($q)) {
        $stats['diperiksa']++;
        $idSiswa = (int)$s['id_siswa'];
        $rombel = trim((string)$s['rombel_dapodik']);
        if ($idSiswa <= 0 || $rombel === '') continue;

        $before = (int)($s['id_kelas'] ?? 0);
        $idKelas = dapodik_find_class_id($db, $rombel, true);

        if ($idKelas <= 0) {
            $stats['gagal']++;
            continue;
        }

        if ($before !== $idKelas) {
            $st = mysqli_prepare($db, "UPDATE siswa SET id_kelas=? WHERE id_siswa=?");
            if ($st) {
                mysqli_stmt_bind_param($st, 'ii', $idKelas, $idSiswa);
                if (mysqli_stmt_execute($st)) $stats['disinkronkan']++;
                else $stats['gagal']++;
                mysqli_stmt_close($st);
            } else {
                $stats['gagal']++;
            }
        }
    }

    return $stats;
}

function dapodik_find_class_id($db,$name,$auto_create=true){
    $target=dapodik_norm_text($name); if($target==='')return 0;
    $tahun=dapodik_ensure_tahun_aktif($db);
    $best=0;$bestScore=-1;
    $q=mysqli_query($db,"SELECT id_kelas,nama_kelas,tingkat,id_tahun_ajaran,status FROM kelas ORDER BY (id_tahun_ajaran=".(int)$tahun.") DESC, status='Aktif' DESC, tingkat,nama_kelas");
    if($q){while($r=mysqli_fetch_assoc($q)){
        $cand=dapodik_norm_text($r['nama_kelas']);$score=-1;
        if($cand===$target)$score=100;
        elseif($cand!==''&&(str_contains($cand,$target)||str_contains($target,$cand)))$score=85;
        if($score>$bestScore){$bestScore=$score;$best=(int)$r['id_kelas'];}
    }}
    if($bestScore>=85)return $best;
    if(!$auto_create)return 0;
    $label=dapodik_class_label($name); if($label==='')return 0;
    $tingkat=0;if(preg_match('/([1-6])/', $target,$m))$tingkat=(int)$m[1]; if($tingkat<1||$tingkat>6)return 0;
    $st=mysqli_prepare($db,"SELECT id_kelas FROM kelas WHERE nama_kelas=? AND id_tahun_ajaran=? LIMIT 1");
    if($st){mysqli_stmt_bind_param($st,'si',$label,$tahun);mysqli_stmt_execute($st);$rr=mysqli_stmt_get_result($st);if($rr&&($x=mysqli_fetch_assoc($rr)))return (int)$x['id_kelas'];}
    $st=mysqli_prepare($db,"INSERT INTO kelas(nama_kelas,tingkat,id_tahun_ajaran,status) VALUES(?,?,?,'Aktif')");
    if(!$st)return 0; mysqli_stmt_bind_param($st,'sii',$label,$tingkat,$tahun); return mysqli_stmt_execute($st)?(int)mysqli_insert_id($db):0;
}
?>