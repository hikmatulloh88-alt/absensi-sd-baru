<?php
/**
 * Bootstrap skema database.
 * Aman dipanggil setiap koneksi: CREATE/ALTER hanya dijalankan bila diperlukan.
 */
if (!isset($koneksi) || !($koneksi instanceof mysqli)) return;

/* Pastikan tabel dasar tersedia untuk database lama. */
mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS tahun_ajaran (id_tahun_ajaran INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, tahun_ajaran VARCHAR(20) NOT NULL, semester ENUM('Gasal','Genap') NOT NULL, aktif TINYINT(1) NOT NULL DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS mata_pelajaran (id_mapel INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, kode_mapel VARCHAR(30) NULL UNIQUE, nama_mapel VARCHAR(100) NOT NULL, kelompok VARCHAR(100) NULL, status ENUM('Aktif','Tidak Aktif') NOT NULL DEFAULT 'Aktif', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS guru (id_guru INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, nip VARCHAR(30) NULL, nuptk VARCHAR(30) NULL, nik VARCHAR(30) NULL, nama VARCHAR(150) NOT NULL, jenis_kelamin ENUM('L','P') NOT NULL DEFAULT 'L', jabatan VARCHAR(100) NULL, jenis_ptk VARCHAR(100) NULL, no_hp VARCHAR(30) NULL, alamat TEXT NULL, foto VARCHAR(255) NULL, tanda_tangan VARCHAR(255) NULL, status ENUM('Aktif','Tidak Aktif') NOT NULL DEFAULT 'Aktif', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

/* Kolom tanda tangan untuk database yang sudah terpasang sebelum fitur ini. */
$guru_cols = [];
$qgc = mysqli_query($koneksi, "SHOW COLUMNS FROM guru");
if ($qgc) while ($r = mysqli_fetch_assoc($qgc)) $guru_cols[$r['Field']] = true;
if (!isset($guru_cols['foto'])) {
    mysqli_query($koneksi, "ALTER TABLE guru ADD COLUMN foto VARCHAR(255) NULL");
}
if (!isset($guru_cols['tanda_tangan'])) {
    mysqli_query($koneksi, "ALTER TABLE guru ADD COLUMN tanda_tangan VARCHAR(255) NULL");
}
mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS kelas (id_kelas INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, nama_kelas VARCHAR(50) NOT NULL, tingkat TINYINT UNSIGNED NOT NULL, id_wali_kelas INT UNSIGNED NULL, id_tahun_ajaran INT UNSIGNED NOT NULL, status ENUM('Aktif','Tidak Aktif') NOT NULL DEFAULT 'Aktif', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

/* Tambahkan kolom master Dapodik ke siswa bila belum ada. */
$dap_cols=[
'rombel_dapodik'=>"VARCHAR(100) NULL",'rt'=>"VARCHAR(10) NULL",'rw'=>"VARCHAR(10) NULL",'dusun'=>"VARCHAR(100) NULL",'kelurahan'=>"VARCHAR(150) NULL",'kecamatan'=>"VARCHAR(150) NULL",'kode_pos'=>"VARCHAR(10) NULL",'jenis_tinggal'=>"VARCHAR(100) NULL",'alat_transportasi'=>"VARCHAR(100) NULL",'telepon'=>"VARCHAR(50) NULL",'hp'=>"VARCHAR(50) NULL",'email'=>"VARCHAR(150) NULL",'skhun'=>"VARCHAR(100) NULL",'penerima_kps'=>"VARCHAR(20) NULL",'no_kps'=>"VARCHAR(80) NULL",'ayah_tahun_lahir'=>"VARCHAR(10) NULL",'ayah_pendidikan'=>"VARCHAR(100) NULL",'ayah_pekerjaan'=>"VARCHAR(100) NULL",'ayah_penghasilan'=>"VARCHAR(100) NULL",'ayah_nik'=>"VARCHAR(30) NULL",'ibu_tahun_lahir'=>"VARCHAR(10) NULL",'ibu_pendidikan'=>"VARCHAR(100) NULL",'ibu_pekerjaan'=>"VARCHAR(100) NULL",'ibu_penghasilan'=>"VARCHAR(100) NULL",'ibu_nik'=>"VARCHAR(30) NULL",'wali_tahun_lahir'=>"VARCHAR(10) NULL",'wali_pendidikan'=>"VARCHAR(100) NULL",'wali_pekerjaan'=>"VARCHAR(100) NULL",'wali_penghasilan'=>"VARCHAR(100) NULL",'wali_nik'=>"VARCHAR(30) NULL",'no_peserta_ujian'=>"VARCHAR(100) NULL",'no_ijazah'=>"VARCHAR(100) NULL",'penerima_kip'=>"VARCHAR(20) NULL",'nomor_kip'=>"VARCHAR(50) NULL",'nama_di_kip'=>"VARCHAR(150) NULL",'nomor_kks'=>"VARCHAR(50) NULL",'no_registrasi_akta_lahir'=>"VARCHAR(100) NULL",'bank'=>"VARCHAR(100) NULL",'nomor_rekening_bank'=>"VARCHAR(100) NULL",'rekening_atas_nama'=>"VARCHAR(150) NULL",'layak_pip'=>"VARCHAR(20) NULL",'alasan_layak_pip'=>"VARCHAR(255) NULL",'kebutuhan_khusus'=>"VARCHAR(150) NULL",'sekolah_asal'=>"VARCHAR(150) NULL",'anak_ke'=>"VARCHAR(10) NULL",'lintang'=>"VARCHAR(50) NULL",'bujur'=>"VARCHAR(50) NULL",'no_kk'=>"VARCHAR(30) NULL",'berat_badan'=>"VARCHAR(30) NULL",'tinggi_badan'=>"VARCHAR(30) NULL",'lingkar_kepala'=>"VARCHAR(30) NULL",'jml_saudara_kandung'=>"VARCHAR(30) NULL",'jarak_rumah_km'=>"VARCHAR(30) NULL"];
$qdc=mysqli_query($koneksi,"SHOW COLUMNS FROM siswa"); $existing=[]; if($qdc) while($r=mysqli_fetch_assoc($qdc))$existing[$r['Field']]=1; foreach($dap_cols as $c=>$def) if(!isset($existing[$c])) mysqli_query($koneksi,"ALTER TABLE siswa ADD COLUMN `$c` $def");


mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS users (
    id_user INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    nama VARCHAR(150) NOT NULL,
    role ENUM('Admin','Operator','Guru') NOT NULL DEFAULT 'Guru',
    id_guru INT UNSIGNED NULL,
    status ENUM('Aktif','Tidak Aktif') NOT NULL DEFAULT 'Aktif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY idx_users_guru (id_guru)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS buku_induk (
    id_buku_induk INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_siswa INT UNSIGNED NOT NULL UNIQUE,
    tinggi_badan VARCHAR(30) NULL, berat_badan VARCHAR(30) NULL, lingkar_kepala VARCHAR(30) NULL,
    jarak_rumah_ke_sekolah VARCHAR(50) NULL, golongan_darah VARCHAR(10) NULL,
    penyakit_pernah_diderita TEXT NULL, kelainan_jasmani TEXT NULL, asal_sekolah VARCHAR(150) NULL,
    nomor_peserta_ujian VARCHAR(80) NULL, nomor_ijazah VARCHAR(80) NULL, tanggal_ijazah VARCHAR(30) NULL,
    prestasi TEXT NULL, catatan_wali_kelas TEXT NULL, catatan_kepala_sekolah TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_bi_siswa FOREIGN KEY (id_siswa) REFERENCES siswa(id_siswa) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS absensi_siswa (
    id_absensi BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_siswa INT UNSIGNED NOT NULL, id_kelas INT UNSIGNED NOT NULL, id_tahun_ajaran INT UNSIGNED NOT NULL,
    tanggal DATE NOT NULL, status ENUM('Hadir','Sakit','Izin','Alpa') NOT NULL DEFAULT 'Hadir',
    keterangan VARCHAR(255) NULL, jam_masuk TIME NULL, jam_pulang TIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_abs_siswa_tgl (id_siswa,tanggal,id_tahun_ajaran),
    KEY idx_abs_siswa_kelas (id_kelas), KEY idx_abs_siswa_tahun (id_tahun_ajaran),
    CONSTRAINT fk_abs_siswa FOREIGN KEY (id_siswa) REFERENCES siswa(id_siswa) ON DELETE CASCADE,
    CONSTRAINT fk_abs_kelas FOREIGN KEY (id_kelas) REFERENCES kelas(id_kelas) ON DELETE RESTRICT,
    CONSTRAINT fk_abs_tahun FOREIGN KEY (id_tahun_ajaran) REFERENCES tahun_ajaran(id_tahun_ajaran) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS absensi_guru (
    id_absensi_guru BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_guru INT UNSIGNED NOT NULL, id_tahun_ajaran INT UNSIGNED NULL, tanggal DATE NOT NULL,
    status ENUM('Hadir','Sakit','Izin','Alpa','Dinas','Cuti') NOT NULL DEFAULT 'Hadir',
    keterangan VARCHAR(255) NULL, jam_masuk TIME NULL, jam_pulang TIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_abs_guru_tgl (id_guru,tanggal,id_tahun_ajaran),
    KEY idx_abs_guru_tahun (id_tahun_ajaran),
    CONSTRAINT fk_abs_guru FOREIGN KEY (id_guru) REFERENCES guru(id_guru) ON DELETE CASCADE,
    CONSTRAINT fk_abs_guru_tahun FOREIGN KEY (id_tahun_ajaran) REFERENCES tahun_ajaran(id_tahun_ajaran) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS nilai (
    id_nilai BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_siswa INT UNSIGNED NOT NULL, id_kelas INT UNSIGNED NOT NULL, id_mapel INT UNSIGNED NOT NULL,
    id_tahun_ajaran INT UNSIGNED NOT NULL,
    nilai_tugas DECIMAL(5,2) NULL, nilai_uts DECIMAL(5,2) NULL, nilai_uas DECIMAL(5,2) NULL,
    nilai_akhir DECIMAL(5,2) NULL, nilai_harian DECIMAL(5,2) NULL, nilai_rapor DECIMAL(5,2) NULL,
    keterangan VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_nilai (id_siswa,id_mapel,id_tahun_ajaran),
    KEY idx_nilai_kelas (id_kelas), KEY idx_nilai_mapel (id_mapel),
    CONSTRAINT fk_nilai_siswa FOREIGN KEY (id_siswa) REFERENCES siswa(id_siswa) ON DELETE CASCADE,
    CONSTRAINT fk_nilai_kelas FOREIGN KEY (id_kelas) REFERENCES kelas(id_kelas) ON DELETE RESTRICT,
    CONSTRAINT fk_nilai_mapel FOREIGN KEY (id_mapel) REFERENCES mata_pelajaran(id_mapel) ON DELETE RESTRICT,
    CONSTRAINT fk_nilai_tahun FOREIGN KEY (id_tahun_ajaran) REFERENCES tahun_ajaran(id_tahun_ajaran) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

/* Tambahkan kolom nilai yang mungkin belum ada pada database lama. */
$required = [
    'nilai_tugas'=>"DECIMAL(5,2) NULL",
    'nilai_uts'=>"DECIMAL(5,2) NULL",
    'nilai_uas'=>"DECIMAL(5,2) NULL",
    'nilai_akhir'=>"DECIMAL(5,2) NULL",
    'nilai_harian'=>"DECIMAL(5,2) NULL",
    'nilai_rapor'=>"DECIMAL(5,2) NULL",
    'keterangan'=>"VARCHAR(255) NULL"
];
$q=mysqli_query($koneksi,"SHOW COLUMNS FROM nilai");
$existing=[];
if($q) while($r=mysqli_fetch_assoc($q)) $existing[$r['Field']]=true;
foreach($required as $col=>$def){
    if(!isset($existing[$col])) mysqli_query($koneksi,"ALTER TABLE nilai ADD COLUMN `$col` $def");
}

/* Pastikan semester Gasal/Genap untuk tahun yang sama dapat hidup berdampingan. */
$q=mysqli_query($koneksi,"SHOW INDEX FROM tahun_ajaran");
$singleYearIndex=[];
if($q){
    while($r=mysqli_fetch_assoc($q)){
        if($r['Column_name']==='tahun_ajaran' && $r['Non_unique']==='0' && $r['Key_name']!=='PRIMARY') $singleYearIndex[$r['Key_name']]=true;
    }
}
foreach(array_keys($singleYearIndex) as $key){
    $safe=preg_replace('/[^A-Za-z0-9_]/','',$key);
    if($safe) mysqli_query($koneksi,"ALTER TABLE tahun_ajaran DROP INDEX `$safe`");
}
$q=mysqli_query($koneksi,"SHOW INDEX FROM tahun_ajaran WHERE Key_name='uk_tahun_semester'");
$hasComposite=$q && mysqli_num_rows($q)>0;
if(!$hasComposite) mysqli_query($koneksi,"ALTER TABLE tahun_ajaran ADD UNIQUE KEY uk_tahun_semester (tahun_ajaran,semester)");

/* Admin awal hanya dibuat bila tabel users benar-benar kosong. */
$q=mysqli_query($koneksi,"SELECT COUNT(*) AS jml FROM users");
if($q && ($r=mysqli_fetch_assoc($q)) && (int)$r['jml']===0){
    $hash=password_hash('admin123', PASSWORD_DEFAULT);
    $st=mysqli_prepare($koneksi,"INSERT INTO users(username,password,nama,role,status) VALUES(?,?,?,?,?)");
    if($st){$u='admin';$n='Administrator';$role='Admin';$status='Aktif';mysqli_stmt_bind_param($st,'sssss',$u,$hash,$n,$role,$status);mysqli_stmt_execute($st);mysqli_stmt_close($st);}
}
/* EKSTRAKURIKULER - modul pengelolaan kegiatan, anggota, kehadiran dan dokumentasi. */
mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS ekstrakurikuler (
    id_ekskul INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nama_ekskul VARCHAR(120) NOT NULL,
    id_guru_pembina INT UNSIGNED NULL,
    hari VARCHAR(30) NULL,
    jam_mulai TIME NULL,
    jam_selesai TIME NULL,
    tempat VARCHAR(150) NULL,
    keterangan TEXT NULL,
    status ENUM('Aktif','Tidak Aktif') NOT NULL DEFAULT 'Aktif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY idx_ekskul_pembina (id_guru_pembina),
    CONSTRAINT fk_ekskul_pembina FOREIGN KEY (id_guru_pembina) REFERENCES guru(id_guru) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS ekskul_anggota (
    id_anggota BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_ekskul INT UNSIGNED NOT NULL,
    id_siswa INT UNSIGNED NOT NULL,
    id_tahun_ajaran INT UNSIGNED NOT NULL,
    status ENUM('Aktif','Tidak Aktif') NOT NULL DEFAULT 'Aktif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_anggota (id_ekskul,id_siswa,id_tahun_ajaran),
    KEY idx_anggota_siswa (id_siswa), KEY idx_anggota_ta (id_tahun_ajaran),
    CONSTRAINT fk_anggota_ekskul FOREIGN KEY (id_ekskul) REFERENCES ekstrakurikuler(id_ekskul) ON DELETE CASCADE,
    CONSTRAINT fk_anggota_siswa FOREIGN KEY (id_siswa) REFERENCES siswa(id_siswa) ON DELETE CASCADE,
    CONSTRAINT fk_anggota_ta FOREIGN KEY (id_tahun_ajaran) REFERENCES tahun_ajaran(id_tahun_ajaran) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS ekskul_kehadiran (
    id_kehadiran BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_ekskul INT UNSIGNED NOT NULL,
    id_siswa INT UNSIGNED NOT NULL,
    id_tahun_ajaran INT UNSIGNED NOT NULL,
    tanggal DATE NOT NULL,
    status ENUM('Hadir','Sakit','Izin','Alpa') NOT NULL DEFAULT 'Hadir',
    keterangan VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_kehadiran (id_ekskul,id_siswa,tanggal,id_tahun_ajaran),
    KEY idx_kehadiran_tanggal (tanggal),
    CONSTRAINT fk_kehadiran_ekskul FOREIGN KEY (id_ekskul) REFERENCES ekstrakurikuler(id_ekskul) ON DELETE CASCADE,
    CONSTRAINT fk_kehadiran_siswa FOREIGN KEY (id_siswa) REFERENCES siswa(id_siswa) ON DELETE CASCADE,
    CONSTRAINT fk_kehadiran_ta FOREIGN KEY (id_tahun_ajaran) REFERENCES tahun_ajaran(id_tahun_ajaran) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS ekskul_kegiatan (
    id_kegiatan BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_ekskul INT UNSIGNED NOT NULL,
    tanggal DATE NOT NULL,
    judul VARCHAR(180) NOT NULL,
    uraian TEXT NULL,
    hasil TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY idx_kegiatan_ekskul (id_ekskul), KEY idx_kegiatan_tanggal (tanggal),
    CONSTRAINT fk_kegiatan_ekskul FOREIGN KEY (id_ekskul) REFERENCES ekstrakurikuler(id_ekskul) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS ekskul_foto (
    id_foto BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_kegiatan BIGINT UNSIGNED NOT NULL,
    nama_file VARCHAR(255) NOT NULL,
    keterangan VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_foto_kegiatan (id_kegiatan),
    CONSTRAINT fk_foto_kegiatan FOREIGN KEY (id_kegiatan) REFERENCES ekskul_kegiatan(id_kegiatan) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

/* Pengaturan tema aplikasi: tema bawaan + CSS kustom yang diunggah Admin. */
mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS app_theme_settings (
    id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
    theme_name VARCHAR(50) NOT NULL DEFAULT 'navy',
    custom_css VARCHAR(255) NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
mysqli_query($koneksi, "INSERT IGNORE INTO app_theme_settings (id, theme_name) VALUES (1, 'navy')");

?>
