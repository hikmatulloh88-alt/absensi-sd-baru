<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "absensi_sd_ciburayut";

$koneksi = mysqli_connect($host, $user, $password, $database);

if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

mysqli_set_charset($koneksi, "utf8mb4");

// Sinkronisasi skema inti agar database lama tetap kompatibel.
$schema_bootstrap = __DIR__ . "/schema_bootstrap.php";
if (is_file($schema_bootstrap)) { require_once $schema_bootstrap; }
