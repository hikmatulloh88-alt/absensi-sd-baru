<?php
/**
 * Pengelola tema aplikasi.
 * Tema tersimpan di database dan CSS tema kustom berada di uploads/themes.
 */
if (!function_exists('tema_default')) {
    function tema_default() {
        return 'navy';
    }

    function tema_tersedia() {
        return [
            'navy'    => ['label' => 'Navy Profesional', 'icon' => '🔷'],
            'emerald' => ['label' => 'Emerald Sekolah', 'icon' => '🟢'],
            'purple' => ['label' => 'Ungu Elegan', 'icon' => '🟣'],
            'sunset'  => ['label' => 'Sunset Ceria', 'icon' => '🟠'],
            'slate'   => ['label' => 'Slate Minimalis', 'icon' => '⚫'],
        ];
    }

    function tema_setting($koneksi) {
        static $tema = null;
        if ($tema !== null) return $tema;
        $tema = tema_default();
        if (isset($koneksi) && $koneksi instanceof mysqli) {
            $q = @mysqli_query($koneksi, "SELECT theme_name, custom_css FROM app_theme_settings WHERE id=1 LIMIT 1");
            if ($q && ($r = mysqli_fetch_assoc($q))) {
                $candidate = trim((string)($r['theme_name'] ?? ''));
                if ($candidate !== '' && (isset(tema_tersedia()[$candidate]) || $candidate === 'custom')) {
                    $tema = $candidate;
                }
            }
        }
        return $tema;
    }

    function tema_custom_css($koneksi) {
        if (!isset($koneksi) || !($koneksi instanceof mysqli)) return '';
        $q = @mysqli_query($koneksi, "SELECT custom_css FROM app_theme_settings WHERE id=1 LIMIT 1");
        if ($q && ($r = mysqli_fetch_assoc($q))) {
            $path = trim((string)($r['custom_css'] ?? ''));
            if ($path !== '') return $path;
        }
        return '';
    }
}
