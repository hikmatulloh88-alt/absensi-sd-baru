<?php
// STEP 54 - Session + Hak Akses Role - FIX
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Normalisasi role ke nilai standar aplikasi.
 */
function normalisasi_role(string $role): string
{
    $role = strtolower(trim($role));

    if (in_array($role, ['admin', 'administrator', 'administrator sistem'], true)) {
        return 'admin';
    }

    if (in_array($role, ['operator', 'operator sekolah'], true)) {
        return 'operator';
    }

    if (in_array($role, ['guru', 'teacher'], true)) {
        return 'guru';
    }

    return $role;
}

/**
 * Sinkronisasi dan normalisasi role.
 * Session role selalu dinormalisasi terlebih dahulu.
 * Jika kosong, ambil dari database berdasarkan user_id.
 */
function sinkron_role_database(): void
{
    // FIX UTAMA: role session "Administrator" juga dinormalisasi menjadi "admin".
    if (!empty($_SESSION['role'])) {
        $_SESSION['role'] = normalisasi_role((string) $_SESSION['role']);

        if ($_SESSION['role'] !== '') {
            return;
        }
    }

    if (empty($_SESSION['user_id'])) {
        return;
    }

    $db_file = __DIR__ . '/database.php';
    if (!file_exists($db_file)) {
        return;
    }

    require_once $db_file;

    if (!isset($koneksi) || !($koneksi instanceof mysqli)) {
        return;
    }

    $columns = [];
    $q = mysqli_query($koneksi, "SHOW COLUMNS FROM users");

    if ($q) {
        while ($row = mysqli_fetch_assoc($q)) {
            $columns[] = $row['Field'];
        }
    }

    $role_col = null;
    foreach (['role', 'level', 'hak_akses', 'akses'] as $col) {
        if (in_array($col, $columns, true)) {
            $role_col = $col;
            break;
        }
    }

    if (!$role_col || !in_array('id_user', $columns, true)) {
        return;
    }

    $sql = "SELECT `$role_col` AS role_db FROM users WHERE id_user = ? LIMIT 1";
    $stmt = mysqli_prepare($koneksi, $sql);

    if (!$stmt) {
        return;
    }

    $id = (int) $_SESSION['user_id'];
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);
    $row = $result ? mysqli_fetch_assoc($result) : null;

    mysqli_stmt_close($stmt);

    if ($row && isset($row['role_db'])) {
        $_SESSION['role'] = normalisasi_role((string) $row['role_db']);
    }
}

sinkron_role_database();

/**
 * Pastikan user sudah login.
 */
function wajib_login(): void
{
    if (empty($_SESSION['user_id'])) {
        header("Location: /absensi_sd/login.php");
        exit;
    }
}

/**
 * Role user saat ini.
 */
function role_user(): string
{
    return normalisasi_role((string) ($_SESSION['role'] ?? ''));
}

/**
 * Cek apakah user memiliki salah satu role.
 */
function punya_role(string ...$roles): bool
{
    $role = role_user();

    foreach ($roles as $allowed) {
        if ($role === normalisasi_role($allowed)) {
            return true;
        }
    }

    return false;
}

/**
 * Batasi halaman berdasarkan role.
 */
function wajib_role(string ...$roles): void
{
    wajib_login();

    if (!punya_role(...$roles)) {
        http_response_code(403);
        ?>
        <!DOCTYPE html>
        <html lang="id">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Akses Ditolak</title>
            <style>
                body{
                    margin:0;
                    min-height:100vh;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    background:#f4f7fb;
                    font-family:Arial,sans-serif;
                }
                .box{
                    max-width:520px;
                    margin:20px;
                    background:#fff;
                    padding:32px;
                    border-radius:18px;
                    box-shadow:0 12px 35px rgba(0,0,0,.10);
                    text-align:center;
                }
                .icon{font-size:54px}
                h1{margin:10px 0;color:#1e293b}
                p{color:#64748b;line-height:1.6}
                a{
                    display:inline-block;
                    margin-top:12px;
                    padding:11px 18px;
                    border-radius:10px;
                    background:#2563eb;
                    color:#fff;
                    text-decoration:none;
                }
            </style>
        </head>
        <body>
            <div class="box">
                <div class="icon">🔒</div>
                <h1>Akses Ditolak</h1>
                <p>Akun Anda tidak memiliki hak akses untuk membuka halaman ini.</p>
                <a href="/absensi_sd/index.php">Kembali ke Dashboard</a>
            </div>
        </body>
        </html>
        <?php
        exit;
    }
}

/**
 * Data user yang sedang login.
 */
function user_login(): array
{
    return [
        'id'       => $_SESSION['user_id'] ?? null,
        'username' => $_SESSION['username'] ?? '',
        'nama'     => $_SESSION['nama_user'] ?? ($_SESSION['nama'] ?? ''),
        'role'     => role_user(),
    ];
}

/**
 * Daftar izin menu aplikasi.
 */
function izin_menu(string $menu): bool
{
    wajib_login();

    $role = role_user();

    if ($role === 'admin') {
        return true;
    }

    $izin = [
        'pengaturan' => [],
        'operator' => [
            'dashboard',
            'siswa',
            'guru',
            'kelas',
            'buku_induk',
            'mapel',
            'absensi_siswa',
            'absensi_guru',
            'rekap_absensi',
            'kartu_absensi',
            'nilai_siswa',
            'nilai_gasal',
            'nilai_genap',
            'upload_nilai',
            'laporan',
            'buku_induk_masal',
            'pengguna',
            'ekstrakurikuler',
        ],
        'guru' => [
            'dashboard',
            'siswa',
            'kelas',
            'mapel',
            'absensi_siswa',
            'rekap_absensi',
            'kartu_absensi',
            'nilai_siswa',
            'nilai_gasal',
            'nilai_genap',
            'upload_nilai',
            'laporan',
            'ekstrakurikuler',
        ],
    ];

    return in_array($menu, $izin[$role] ?? [], true);
}
?>
