<?php
// STEP 21 - Logout System

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Hapus seluruh data session pengguna
$_SESSION = [];

// Hapus cookie session bila digunakan
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params['path'],
        $params['domain'],
        $params['secure'],
        $params['httponly']
    );
}

// Hancurkan session
session_destroy();

// Kembali ke halaman login
header("Location: /absensi_sd/login.php");
exit;
?>
