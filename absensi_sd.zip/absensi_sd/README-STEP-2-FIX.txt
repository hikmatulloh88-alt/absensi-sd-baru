STEP 2 - FIX DATABASE + RIWAYAT ABSENSI
1. Database aplikasi: absensi_sd_ciburayut.
2. Jalankan database/create_absensi_siswa.sql di database absensi_sd_ciburayut jika tabel absensi_siswa belum ada.
3. File config/database.php sudah diarahkan ke absensi_sd_ciburayut.
4. Riwayat Absensi menggunakan primary key id_absensi sesuai struktur tabel.
5. Menu Riwayat Absensi tersedia untuk Admin, Operator, dan Guru.
6. Tidak ada data lama yang dapat dipulihkan dari SQL struktur ini.
