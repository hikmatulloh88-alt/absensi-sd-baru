STEP 1 - PONDASI DATABASE
==========================

1. Gunakan XAMPP/Laragon dan hidupkan Apache + MySQL.
2. Buka phpMyAdmin.
3. Import file database/absensi_sd.sql.
4. Letakkan folder app ke project PHP baru.
5. Sesuaikan user/password MySQL pada app/config/database.php jika diperlukan.
6. Tahap berikutnya adalah membuat template utama + sidebar.

Relasi awal:
sekolah
tahun_ajaran
guru
kelas -> guru + tahun_ajaran
siswa -> kelas
mata_pelajaran

Semua modul berikutnya akan memakai master ini.
