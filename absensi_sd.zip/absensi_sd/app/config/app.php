<?php
// Konfigurasi dasar aplikasi
define('APP_NAME', 'Aplikasi Absensi SD');
define('SCHOOL_NAME', 'SDN CIBURAYUT 01');
define('APP_VERSION', '1.0.0');

date_default_timezone_set('Asia/Jakarta');
